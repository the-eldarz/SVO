# Bodycam Clone (Android, офлайн)

1. Залей всё содержимое этого архива в корень репозитория (вместе с папкой `.github`).
2. Положи свою модель в `app/src/main/assets/models/ukrainian_soldier.glb`.
3. Actions -> Build APK -> скачай артефакт `bodycam-apk`.

Настройки модели (высота, поворот, оттенки сторон): `app/src/main/java/com/bodycamclone/Config.java`.
