# Bodycam Clone (Android, офлайн)

1. Залей в корень репозитория: `BodycamClone.zip`, `.github/workflows/build.yml` и модели `ukrainian_soldier.glb`, `russian_vdv_paratrooper.glb`.
2. Actions -> Build APK -> скачай артефакт `bodycam-apk`.

Меню: Играть (карта -> сторона -> снаряжение -> в бой) и Настройки (чувствительность, инверсия, режим прицела, расположение кнопок).
Кнопки в игре: ОГОНЬ, R, ОРУЖИЕ, ПРИЦЕЛ, ЗУМ (x1/x2/x4). Кнопка «назад» в игре открывает паузу.

Модели: пути и поворот лица модели - `Config.java` (RU_MODEL, UA_MODEL, RU_YAW_OFFSET_DEG, UA_YAW_OFFSET_DEG).
