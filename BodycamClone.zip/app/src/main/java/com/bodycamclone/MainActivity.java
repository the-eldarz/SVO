package com.bodycamclone;

import android.app.Activity;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int MATCH = -1, WRAP = -2;
    private static final int TXT = 0xFFE8EDE4, TXT2 = 0xFF8FB07F, TXT3 = 0xFF8A948A;

    private FrameLayout root;
    private GLSurfaceView gl;
    private HudView hud;
    private Game game;
    private SoundBank snd;
    private View screen;      // экран меню, лежащий поверх всего
    private Runnable onBack;  // что делает кнопка «назад» на этом экране
    private int selMap = 0, selSide = Config.SIDE_RU;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Settings.init(this);
        snd = new SoundBank(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0E1214);
        setContentView(root);
        showMain();
    }

    // ---------- каркас экранов ----------

    private int dp(float v) { return Ui.dp(this, v); }

    private LinearLayout.LayoutParams lp(int w, int h, float weight, int l, int t, int r, int bt) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(dp(l), dp(t), dp(r), dp(bt));
        return p;
    }

    private void showScreen(View v, Runnable back) {
        if (screen != null) root.removeView(screen);
        screen = v;
        onBack = back;
        root.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    private void hideScreen() {
        if (screen != null) root.removeView(screen);
        screen = null;
        onBack = null;
    }

    /** Вертикальная страница меню с заголовком. */
    private LinearLayout page(String title) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        l.setPadding(dp(28), dp(14), dp(28), dp(14));
        l.setBackground(Ui.background());
        l.setClickable(true);
        if (title != null) {
            TextView t = Ui.text(this, title, 24, TXT, true);
            t.setGravity(Gravity.CENTER);
            l.addView(t, lp(MATCH, WRAP, 0f, 0, 0, 0, 8));
        }
        return l;
    }

    private Button backButton(Runnable action) {
        return Ui.button(this, "Назад", v -> action.run());
    }

    private LinearLayout card(View header, String title, String sub, View.OnClickListener click) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(10), dp(12), dp(10), dp(12));
        c.setBackground(Ui.stateBox(this, 0xFF222E26, 0xFF3F5A3A, 0xFF5E7F55, 12));
        c.setClickable(true);
        c.setOnClickListener(click);
        if (header != null) c.addView(header);
        TextView t = Ui.text(this, title, 18, TXT, true);
        t.setGravity(Gravity.CENTER);
        c.addView(t, lp(MATCH, WRAP, 0f, 0, 8, 0, 2));
        if (sub != null) {
            TextView s = Ui.text(this, sub, 13, TXT2, false);
            s.setGravity(Gravity.CENTER);
            c.addView(s, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        }
        return c;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        return r;
    }

    // ---------- главное меню ----------

    private void showMain() {
        LinearLayout l = page(null);
        l.setGravity(Gravity.CENTER);
        TextView t = Ui.text(this, "BODYCAM", 40, TXT, true);
        t.setGravity(Gravity.CENTER);
        t.setLetterSpacing(0.15f);
        l.addView(t, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        TextView s = Ui.text(this, "СВО  ·  офлайн-шутер", 14, TXT2, false);
        s.setGravity(Gravity.CENTER);
        l.addView(s, lp(MATCH, WRAP, 0f, 0, 0, 0, 18));
        l.addView(Ui.button(this, "ИГРАТЬ", v -> showMaps()), lp(dp(280), dp(52), 0f, 0, 0, 0, 10));
        l.addView(Ui.button(this, "НАСТРОЙКИ", v -> showSettings(this::showMain)), lp(dp(280), dp(52), 0f, 0, 0, 0, 10));
        l.addView(Ui.button(this, "ВЫХОД", v -> finish()), lp(dp(280), dp(52), 0f, 0, 0, 0, 0));
        showScreen(l, null);
    }

    // ---------- играть: карта -> сторона -> снаряжение ----------

    private void showMaps() {
        LinearLayout l = page("Выбор карты");
        LinearLayout r = row();
        for (int i = 0; i < Config.MAP_NAMES.length; i++) {
            final int idx = i;
            r.addView(card(null, Config.MAP_NAMES[i], Config.MAP_DESC[i], v -> { selMap = idx; showSides(); }),
                    lp(0, MATCH, 1f, 6, 0, 6, 0));
        }
        l.addView(r, lp(MATCH, 0, 1f, 0, 6, 0, 10));
        l.addView(backButton(this::showMain), lp(dp(220), dp(46), 0f, 0, 0, 0, 0));
        showScreen(l, this::showMain);
    }

    private View flag(int... colors) {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        for (int col : colors) {
            View st = new View(this);
            st.setBackgroundColor(col);
            f.addView(st, new LinearLayout.LayoutParams(dp(96), dp(60 / colors.length)));
        }
        return f;
    }

    private void showSides() {
        LinearLayout l = page("Сторона конфликта");
        LinearLayout r = row();
        r.addView(card(flag(0xFFFFFFFF, 0xFF0039A6, 0xFFD52B1E), "РОССИЯ", "Бойцы ВДВ", v -> { selSide = Config.SIDE_RU; showLoadout(); }),
                lp(0, MATCH, 1f, 6, 0, 6, 0));
        r.addView(card(flag(0xFF0057B7, 0xFFFFD700), "УКРАИНА", "Бойцы ВСУ", v -> { selSide = Config.SIDE_UA; showLoadout(); }),
                lp(0, MATCH, 1f, 6, 0, 6, 0));
        l.addView(r, lp(MATCH, 0, 1f, 0, 6, 0, 10));
        l.addView(backButton(this::showMaps), lp(dp(220), dp(46), 0f, 0, 0, 0, 0));
        showScreen(l, this::showMaps);
    }

    private void showLoadout() {
        LinearLayout l = page("Снаряжение");
        TextView info = Ui.text(this, "Карта: " + Config.MAP_NAMES[selMap] + "   ·   Сторона: "
                + (selSide == Config.SIDE_RU ? "Россия" : "Украина"), 13, TXT2, false);
        info.setGravity(Gravity.CENTER);
        l.addView(info, lp(MATCH, WRAP, 0f, 0, 0, 0, 6));
        String[] slots = {"Форма", "Оружие", "Броня", "Гранаты", "Расходники"};
        String[] cur = {"Стандартная", "АК-74 + ПМ", "Нет", "Нет", "Нет"};
        LinearLayout r = row();
        for (int i = 0; i < slots.length; i++) {
            r.addView(card(null, slots[i], cur[i] + "\nвыбор появится позже",
                    v -> Toast.makeText(this, "Выбор снаряжения добавим позже", Toast.LENGTH_SHORT).show()),
                    lp(0, MATCH, 1f, 4, 0, 4, 0));
        }
        l.addView(r, lp(MATCH, 0, 1f, 0, 4, 0, 10));
        LinearLayout bt = row();
        bt.addView(backButton(this::showSides), lp(dp(180), dp(46), 0f, 0, 0, 10, 0));
        bt.addView(Ui.button(this, "В БОЙ", v -> startGame()), lp(dp(240), dp(46), 0f, 10, 0, 0, 0));
        l.addView(bt, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        showScreen(l, this::showSides);
    }

    // ---------- настройки ----------

    private void showSettings(Runnable back) {
        final Runnable done = () -> { Settings.save(); back.run(); };
        LinearLayout l = page("Настройки");
        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        sv.addView(body, new FrameLayout.LayoutParams(dp(460), WRAP, Gravity.CENTER_HORIZONTAL));
        l.addView(sv, lp(MATCH, 0, 1f, 0, 0, 0, 8));

        body.addView(Ui.text(this, "Управление", 16, TXT2, true), lp(MATCH, WRAP, 0f, 0, 4, 0, 8));

        final TextView sensText = Ui.text(this, "", 15, TXT, false);
        body.addView(sensText, lp(MATCH, WRAP, 0f, 0, 0, 0, 2));
        SeekBar sb = new SeekBar(this);
        sb.setMax(220);                                  // 0.30 .. 2.50
        sb.setProgress(Math.round(Settings.sens * 100f) - 30);
        sensText.setText(String.format(Locale.US, "Чувствительность камеры: %.2f", Settings.sens));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                Settings.sens = (p + 30) / 100f;
                sensText.setText(String.format(Locale.US, "Чувствительность камеры: %.2f", Settings.sens));
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        body.addView(sb, lp(MATCH, WRAP, 0f, 0, 0, 0, 10));

        Switch inv = new Switch(this);
        inv.setText("Инверсия камеры по вертикали");
        inv.setTextSize(15);
        inv.setTextColor(TXT);
        inv.setChecked(Settings.invertY);
        inv.setOnCheckedChangeListener((cb, on) -> Settings.invertY = on);
        body.addView(inv, lp(MATCH, WRAP, 0f, 0, 0, 0, 10));

        final Button ads = Ui.button(this, "", null);
        ads.setText(adsLabel());
        ads.setOnClickListener(v -> { Settings.adsToggle = !Settings.adsToggle; ads.setText(adsLabel()); });
        body.addView(ads, lp(MATCH, dp(46), 0f, 0, 0, 0, 10));

        body.addView(Ui.button(this, "Расположение кнопок", v -> openEditor(() -> showSettings(back))),
                lp(MATCH, dp(46), 0f, 0, 0, 0, 10));

        l.addView(backButton(done), lp(dp(220), dp(46), 0f, 0, 0, 0, 0));
        showScreen(l, done);
    }

    private String adsLabel() {
        return Settings.adsToggle ? "Прицел: нажал — вкл/выкл" : "Прицел: пока держишь кнопку";
    }

    private void openEditor(Runnable back) {
        FrameLayout f = new FrameLayout(this);
        final ButtonEditorView ev = new ButtonEditorView(this, game != null);
        f.addView(ev, new FrameLayout.LayoutParams(MATCH, MATCH));
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        bar.addView(Ui.button(this, "−", v -> ev.resize(-0.1f)), lp(dp(56), dp(42), 0f, 4, 6, 4, 0));
        bar.addView(Ui.button(this, "+", v -> ev.resize(0.1f)), lp(dp(56), dp(42), 0f, 4, 6, 4, 0));
        bar.addView(Ui.button(this, "Сброс", v -> { Settings.resetLayout(); ev.invalidate(); }), lp(dp(90), dp(42), 0f, 4, 6, 4, 0));
        final Runnable done = () -> { Settings.save(); back.run(); };
        bar.addView(Ui.button(this, "Готово", v -> done.run()), lp(dp(100), dp(42), 0f, 4, 6, 4, 0));
        f.addView(bar, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.CENTER_HORIZONTAL));
        showScreen(f, done);
    }

    // ---------- игра и пауза ----------

    private void startGame() {
        hideScreen();
        game = new Game(Config.MAP_SEEDS[selMap], selSide);
        game.snd = snd;
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(3);
        gl.setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        gl.setRenderer(new GameRenderer(this, game));
        gl.setPreserveEGLContextOnPause(true);
        hud = new HudView(this, game);
        root.addView(gl, new FrameLayout.LayoutParams(MATCH, MATCH));
        root.addView(hud, new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    private void stopGame() {
        if (gl != null) { gl.onPause(); root.removeView(gl); gl = null; }
        if (hud != null) { root.removeView(hud); hud = null; }
        game = null;
    }

    private void showPause() {
        if (game == null) return;
        game.paused = true;
        if (hud != null) hud.releaseInput();
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(0xB0000000);
        l.setClickable(true);
        TextView t = Ui.text(this, "Пауза", 28, TXT, true);
        t.setGravity(Gravity.CENTER);
        l.addView(t, lp(MATCH, WRAP, 0f, 0, 0, 0, 14));
        l.addView(Ui.button(this, "ПРОДОЛЖИТЬ", v -> resumeGame()), lp(dp(280), dp(50), 0f, 0, 0, 0, 10));
        l.addView(Ui.button(this, "НАСТРОЙКИ", v -> showSettings(this::showPause)), lp(dp(280), dp(50), 0f, 0, 0, 0, 10));
        l.addView(Ui.button(this, "В ГЛАВНОЕ МЕНЮ", v -> { stopGame(); showMain(); }), lp(dp(280), dp(50), 0f, 0, 0, 0, 0));
        showScreen(l, this::resumeGame);
    }

    private void resumeGame() {
        hideScreen();
        if (game != null) game.paused = false;
    }

    @Override
    public void onBackPressed() {
        if (onBack != null) onBack.run();
        else if (game != null) showPause();
        else super.onBackPressed();
    }

    @Override protected void onResume() { super.onResume(); if (gl != null) gl.onResume(); }

    @Override
    protected void onPause() {
        Settings.save();
        if (game != null && screen == null) showPause();
        if (gl != null) gl.onPause();
        super.onPause();
    }

    @Override protected void onDestroy() { snd.release(); super.onDestroy(); }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
}
