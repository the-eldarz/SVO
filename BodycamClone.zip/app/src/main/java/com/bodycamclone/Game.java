package com.bodycamclone;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Game {
    public static final class Input {
        public volatile float moveX, moveY;
        public volatile boolean fire;
        public float lookDX, lookDY;
        public volatile boolean ads;
        public boolean reload, sw, restart, zoom;
    }

    public static final class Player {
        public float x, z, yaw, pitch, hp = 100f;
        public boolean alive = true, moving;
        public float hurtT, hitT, fireCd, reloadT, flashT, kick, bob, deadT, aimT;
        public int weapon, zoom;
        public int[] ammo = new int[2], reserve = new int[2];
        boolean firePrev;
        float stepSign = 1f;
    }

    public static final String[] W_NAME = {"АК-74", "ПМ"};
    static final float[] W_DMG = {35f, 28f}, W_CD = {0.10f, 0.30f}, W_RELOAD = {2.2f, 1.6f}, W_SPREAD = {0.012f, 0.008f};
    static final int[] W_MAG = {30, 8};
    static final boolean[] W_AUTO = {true, false};

    public static float[] W_RELOAD_PUBLIC() { return W_RELOAD; }

    public final Input input = new Input();
    public final Player p = new Player();
    public final List<Soldier> soldiers = new ArrayList<>();
    public final WorldMap map;
    /** За кого играет игрок: Config.SIDE_RU / SIDE_UA. */
    public final int side;
    public volatile boolean paused;
    public SoundBank snd;
    public volatile int kills, wave, enemiesLeft, alliesLeft;
    public volatile String status = "";
    public volatile boolean statusError;
    public float time;
    private final Random rnd = new Random();
    private final float[] tmp = new float[2];
    private float waveTimer = -1f, ambT = 3f;

    public Game(long mapSeed, int side) {
        this.map = new WorldMap(mapSeed);
        this.side = side;
        reset();
    }

    /** Текущее вертикальное поле зрения с учётом прицела и зума. */
    public float curFov() {
        return (float) Math.toDegrees(2.0 * Math.atan(tanHalfFov()));
    }

    private float tanHalfFov() {
        float f = Config.BASE_FOV + (Config.ADS_FOV - Config.BASE_FOV) * p.aimT;
        return (float) Math.tan(Math.toRadians(f / 2.0)) / Config.ZOOM_STEPS[p.zoom];
    }

    public void reset() {
        soldiers.clear();
        p.x = map.playerSpawn[0]; p.z = map.playerSpawn[1]; p.yaw = 0f; p.pitch = 0f;
        p.hp = 100f; p.alive = true; p.deadT = 0f; p.weapon = 0; p.reloadT = 0f; p.fireCd = 0f;
        p.ammo[0] = W_MAG[0]; p.ammo[1] = W_MAG[1]; p.reserve[0] = 120; p.reserve[1] = 40;
        kills = 0; wave = 0; waveTimer = -1f;
        p.zoom = 0; p.aimT = 0f; input.ads = false;
        spawnWave();
    }

    private void place(Soldier s) {
        tmp[0] = s.x; tmp[1] = s.z;
        map.resolve(tmp, 0.4f);
        s.x = tmp[0]; s.z = tmp[1];
        soldiers.add(s);
    }

    private void spawnWave() {
        wave++;
        int n = Math.min(3 + wave * 2, 14);
        for (int i = 0; i < n; i++) {
            float[] sp = map.enemySpawns.get(rnd.nextInt(map.enemySpawns.size()));
            place(new Soldier(1, sp[0] + (rnd.nextFloat() - .5f), sp[1], (float) Math.PI));
        }
        int alive = 0;
        for (Soldier s : soldiers) if (s.team == 0 && !s.dead) alive++;
        for (int i = alive; i < Config.ALLIES; i++) {
            float[] sp = map.allySpawns.get(rnd.nextInt(map.allySpawns.size()));
            place(new Soldier(0, sp[0], sp[1], 0f));
        }
        if (wave > 1 && p.alive) {
            p.hp = Math.min(100f, p.hp + 35f);
            p.reserve[0] += 60; p.reserve[1] += 16;
        }
    }

    private void sfx(int id, float vol, float rate) { if (snd != null) snd.play(id, vol, rate); }

    public void update(float dt) {
        if (dt <= 0f || paused) return;
        float ldx, ldy; boolean reload, sw, restart, zoom;
        synchronized (input) {
            ldx = input.lookDX; ldy = input.lookDY; input.lookDX = 0; input.lookDY = 0;
            reload = input.reload; sw = input.sw; restart = input.restart; zoom = input.zoom;
            input.reload = false; input.sw = false; input.restart = false; input.zoom = false;
        }
        time += dt;
        if (p.alive) updatePlayer(dt, ldx, ldy, reload, sw, zoom);
        else { p.deadT += dt; if (restart && p.deadT > 1f) { reset(); return; } }

        for (Soldier s : soldiers) updateSoldier(s, dt);
        int n = soldiers.size();
        for (int i = 0; i < n; i++) {
            Soldier a = soldiers.get(i);
            if (a.dead) continue;
            for (int j = i + 1; j < n; j++) {
                Soldier b = soldiers.get(j);
                if (b.dead) continue;
                float dx = b.x - a.x, dz = b.z - a.z, d2 = dx * dx + dz * dz;
                if (d2 < 0.49f && d2 > 1e-6f) {
                    float d = (float) Math.sqrt(d2), push = (0.7f - d) * 0.5f;
                    a.x -= dx / d * push; a.z -= dz / d * push; b.x += dx / d * push; b.z += dz / d * push;
                }
            }
        }
        Iterator<Soldier> it = soldiers.iterator();
        while (it.hasNext()) { Soldier s = it.next(); if (s.dead && s.deadT > 25f) it.remove(); }
        int e = 0, a = 0;
        for (Soldier s : soldiers) if (!s.dead) { if (s.team == 1) e++; else a++; }
        enemiesLeft = e; alliesLeft = a;
        if (e == 0 && p.alive) {
            if (waveTimer < 0f) waveTimer = 4f;
            waveTimer -= dt;
            if (waveTimer <= 0f) { waveTimer = -1f; spawnWave(); }
        }
        ambT -= dt;
        if (ambT <= 0f) { ambT = 2f + rnd.nextFloat() * 5f; sfx(SoundBank.FAR, 0.2f + rnd.nextFloat() * 0.2f, 0.9f + rnd.nextFloat() * 0.2f); }
    }

    private void updatePlayer(float dt, float ldx, float ldy, boolean reload, boolean sw, boolean zoom) {
        if (zoom) p.zoom = (p.zoom + 1) % Config.ZOOM_STEPS.length;
        float aimTarget = input.ads ? 1f : 0f;
        float aimStep = dt * 7f, aimDiff = aimTarget - p.aimT;
        p.aimT += Math.abs(aimDiff) <= aimStep ? aimDiff : Math.signum(aimDiff) * aimStep;
        // чем сильнее приближение, тем медленнее поворот камеры
        float fovScale = tanHalfFov() / (float) Math.tan(Math.toRadians(Config.BASE_FOV / 2.0));
        float sens = Config.LOOK_SENS * Settings.sens * fovScale;
        float dy = Settings.invertY ? -ldy : ldy;
        p.yaw += ldx * sens;
        p.pitch = Math.max(-1.35f, Math.min(1.35f, p.pitch - dy * sens));
        p.hurtT = Math.max(0f, p.hurtT - dt); p.hitT = Math.max(0f, p.hitT - dt);
        p.flashT = Math.max(0f, p.flashT - dt); p.kick = Math.max(0f, p.kick - dt * 7f);
        p.fireCd -= dt;

        float mx = input.moveX, my = input.moveY;
        float mag = Math.min(1f, (float) Math.hypot(mx, my));
        float sy = (float) Math.sin(p.yaw), cy = (float) Math.cos(p.yaw);
        p.moving = mag > 0.1f;
        if (p.moving) {
            float speed = 4.3f * mag * (1f - 0.35f * p.aimT);
            float vx = (sy * my + cy * mx) / mag * speed, vz = (-cy * my + sy * mx) / mag * speed;
            tmp[0] = p.x + vx * dt; tmp[1] = p.z + vz * dt;
            map.resolve(tmp, 0.35f);
            p.x = tmp[0]; p.z = tmp[1];
            p.bob += dt * speed * 1.9f;
            float sgn = Math.signum((float) Math.sin(p.bob));
            if (sgn != 0f && sgn != p.stepSign) { p.stepSign = sgn; sfx(SoundBank.STEP, 0.35f, 0.9f + rnd.nextFloat() * 0.2f); }
        }
        int w = p.weapon;
        if (p.reloadT > 0f) {
            p.reloadT -= dt;
            if (p.reloadT <= 0f) {
                int take = Math.min(W_MAG[w] - p.ammo[w], p.reserve[w]);
                p.ammo[w] += take; p.reserve[w] -= take;
            }
        } else {
            if (sw) { p.weapon = 1 - p.weapon; p.fireCd = 0.35f; p.kick = 1f; w = p.weapon; }
            else if (reload && p.ammo[w] < W_MAG[w] && p.reserve[w] > 0) startReload();
        }
        boolean fire = input.fire;
        boolean can = fire && p.fireCd <= 0f && p.reloadT <= 0f && (W_AUTO[w] || !p.firePrev);
        if (can) {
            if (p.ammo[w] > 0) { p.ammo[w]--; p.fireCd = W_CD[w]; playerShoot(); }
            else { p.fireCd = 0.3f; sfx(SoundBank.EMPTY, 0.6f, 1f); if (p.reserve[w] > 0) startReload(); }
        }
        p.firePrev = fire;
    }

    private void startReload() { p.reloadT = W_RELOAD[p.weapon]; sfx(SoundBank.RELOAD, 0.7f, 1f); }

    private void playerShoot() {
        int w = p.weapon;
        sfx(w == 0 ? SoundBank.RIFLE : SoundBank.PISTOL, 1f, 0.97f + rnd.nextFloat() * 0.06f);
        p.flashT = 0.05f; p.kick = 1f;
        p.pitch += 0.012f; p.yaw += (rnd.nextFloat() - .5f) * 0.004f;
        float cp = (float) Math.cos(p.pitch), sp = (float) Math.sin(p.pitch);
        float sy = (float) Math.sin(p.yaw), cy = (float) Math.cos(p.yaw);
        float spr = W_SPREAD[w] * (p.moving ? 1.8f : 1f) * (1f - 0.5f * p.aimT);
        float rx = (rnd.nextFloat() - .5f) * 2f * spr, ry = (rnd.nextFloat() - .5f) * 2f * spr;
        float dx = cp * sy + cy * rx - sp * sy * ry;
        float dy = sp + cp * ry;
        float dz = -cp * cy + sy * rx + sp * cy * ry;
        float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= l; dy /= l; dz /= l;
        float ox = p.x, oy = 1.55f, oz = p.z;
        float bestT = map.raycast(ox, oy, oz, dx, dy, dz, 150f);
        Soldier best = null; boolean head = false;
        for (Soldier s : soldiers) {
            if (s.dead || s.team == 0) continue;
            float t = WorldMap.rayAabb(ox, oy, oz, dx, dy, dz, s.x - .32f, 0f, s.z - .32f, s.x + .32f, 1.85f, s.z + .32f);
            if (t >= 0f && t < bestT) { bestT = t; best = s; head = (oy + dy * t) > 1.5f; }
        }
        if (best != null) {
            p.hitT = 0.18f;
            sfx(SoundBank.TICK, 0.7f, head ? 1.4f : 1f);
            if (damage(best, head ? W_DMG[w] * 3f : W_DMG[w])) kills++;
        }
    }

    /** true, если боец убит этим попаданием */
    private boolean damage(Soldier s, float d) {
        if (s.dead) return false;
        s.hp -= d; s.hitFlash = 0.15f;
        sfx(SoundBank.HIT, 0.5f, 0.9f + rnd.nextFloat() * 0.3f);
        if (s.hp <= 0f) { s.dead = true; s.deadT = 0f; sfx(SoundBank.DEATH, 0.5f, 0.9f + rnd.nextFloat() * 0.2f); return true; }
        return false;
    }

    private void damagePlayer(float d) {
        if (!p.alive) return;
        p.hp -= d; p.hurtT = 0.4f;
        sfx(SoundBank.HURT, 0.8f, 1f);
        if (p.hp <= 0f) { p.hp = 0f; p.alive = false; p.deadT = 0f; sfx(SoundBank.DEATH, 0.8f, 0.8f); }
    }

    private static float wrap(float a) {
        while (a > Math.PI) a -= 2 * Math.PI;
        while (a < -Math.PI) a += 2 * Math.PI;
        return a;
    }

    private static float turn(float a, float target, float step) {
        float d = wrap(target - a);
        return Math.abs(d) <= step ? target : a + Math.signum(d) * step;
    }

    private void updateSoldier(Soldier s, float dt) {
        if (s.dead) { s.deadT += dt; return; }
        s.fireCd -= dt; s.flash -= dt; s.hitFlash -= dt; s.strafeT -= dt;
        s.reactT -= dt; s.avoidT -= dt; s.losT -= dt;

        Soldier ts = null; boolean tp = false; float best = 1e18f, tx = 0f, tz = 0f;
        for (Soldier o : soldiers) {
            if (o.dead || o.team == s.team) continue;
            float dx = o.x - s.x, dz = o.z - s.z, d = dx * dx + dz * dz;
            if (d < best) { best = d; ts = o; tx = o.x; tz = o.z; }
        }
        if (s.team == 1 && p.alive) {
            float dx = p.x - s.x, dz = p.z - s.z, d = dx * dx + dz * dz;
            if (d < best) { best = d; ts = null; tp = true; tx = p.x; tz = p.z; }
        }
        boolean has = ts != null || tp;
        float vx = 0f, vz = 0f, desired = s.yaw, dist = 0f;
        if (has) {
            float dx = tx - s.x, dz = tz - s.z;
            dist = (float) Math.sqrt(best);
            desired = (float) Math.atan2(dx, -dz);
            if (s.losT <= 0f) {
                s.losT = 0.2f;
                float inv = 1f / Math.max(dist, 0.01f);
                boolean nl = map.raycast(s.x, 1.4f, s.z, dx * inv, 0f, dz * inv, dist) >= dist - 0.3f;
                if (nl && !s.los) s.reactT = 0.3f + rnd.nextFloat() * 0.5f;
                s.los = nl;
            }
            s.yaw = turn(s.yaw, desired, 4.5f * dt);
            float fx = (float) Math.sin(s.yaw), fz = -(float) Math.cos(s.yaw);
            float rx = (float) Math.cos(s.yaw), rz = (float) Math.sin(s.yaw);
            if (s.avoidT > 0f) {
                vx = rx * s.avoidDir * 2.2f + fx * 0.6f; vz = rz * s.avoidDir * 2.2f + fz * 0.6f;
            } else if (s.los && dist < 24f) {
                if (s.strafeT <= 0f) {
                    s.strafeT = 1f + rnd.nextFloat() * 2f; s.strafeDir = rnd.nextBoolean() ? 1f : -1f;
                    s.pause = rnd.nextFloat() < 0.3f;
                }
                float fw = dist > 14f ? 1.6f : (dist < 6f ? -1.5f : 0f);
                float st = s.pause ? 0f : 1.3f * s.strafeDir;
                vx = fx * fw + rx * st; vz = fz * fw + rz * st;
            } else { vx = fx * 2.6f; vz = fz * 2.6f; }
        } else if (s.team == 0) {
            s.los = false;
            float dx = p.x - s.x, dz = p.z - s.z, d = (float) Math.sqrt(dx * dx + dz * dz);
            if (d > 7f) {
                s.yaw = turn(s.yaw, (float) Math.atan2(dx, -dz), 4f * dt);
                vx = (float) Math.sin(s.yaw) * 2.8f; vz = -(float) Math.cos(s.yaw) * 2.8f;
            }
        }
        float sp = (float) Math.sqrt(vx * vx + vz * vz), ox = s.x, oz = s.z;
        tmp[0] = s.x + vx * dt; tmp[1] = s.z + vz * dt;
        map.resolve(tmp, 0.35f);
        s.x = tmp[0]; s.z = tmp[1];
        float moved = (float) Math.hypot(s.x - ox, s.z - oz);
        if (sp > 0.8f && moved < sp * dt * 0.3f) {
            s.stuckT += dt;
            if (s.stuckT > 0.5f) { s.stuckT = 0f; s.avoidT = 1.2f; s.avoidDir = rnd.nextBoolean() ? 1f : -1f; }
        } else s.stuckT = Math.max(0f, s.stuckT - dt);
        s.moving = moved / dt > 0.4f;
        s.walkPhase += moved * 3.2f;

        if (has && s.los && dist < 35f && s.fireCd <= 0f && s.reactT <= 0f
                && Math.abs(wrap(desired - s.yaw)) < 0.25f) {
            s.fireCd = 0.14f + rnd.nextFloat() * 0.06f;
            if (++s.burst >= 3 + rnd.nextInt(4)) { s.burst = 0; s.fireCd = 0.8f + rnd.nextFloat(); }
            s.flash = 0.06f;
            if (dist > 25f) sfx(SoundBank.FAR, 0.4f, 1f);
            else sfx(SoundBank.RIFLE, Math.max(0.1f, 0.8f - dist / 40f), 0.95f + rnd.nextFloat() * 0.1f);
            float chance = Math.max(0.06f, Math.min(0.4f, 0.5f - dist * 0.012f));
            if (tp) chance *= 0.6f;
            if (rnd.nextFloat() < chance) {
                if (tp) damagePlayer(7f + rnd.nextFloat() * 3f);
                else damage(ts, 12f + rnd.nextFloat() * 6f);
            }
        }
    }
}
