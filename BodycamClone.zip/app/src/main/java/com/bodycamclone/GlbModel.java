package com.bodycamclone;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES30;
import android.opengl.GLUtils;
import android.opengl.Matrix;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Минимальный загрузчик .glb: меши, материалы (цвет + текстура). Поза покоя, без скелетной анимации. */
public class GlbModel {
    public static class Prim {
        public float[] data;   // pos(3) normal(3) uv(2)
        public int[] idx;
        public float[] color = {1f, 1f, 1f, 1f};
        public Bitmap bmp;
        public int vao, vbo, ibo, tex, count;

        public void uploadGeometry() {
            int[] b = new int[1];
            GLES30.glGenVertexArrays(1, b, 0); vao = b[0];
            GLES30.glBindVertexArray(vao);
            GLES30.glGenBuffers(1, b, 0); vbo = b[0];
            FloatBuffer fb = ByteBuffer.allocateDirect(data.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
            fb.put(data); fb.position(0);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo);
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, data.length * 4, fb, GLES30.GL_STATIC_DRAW);
            GLES30.glGenBuffers(1, b, 0); ibo = b[0];
            IntBuffer ib = ByteBuffer.allocateDirect(idx.length * 4).order(ByteOrder.nativeOrder()).asIntBuffer();
            ib.put(idx); ib.position(0);
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo);
            GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, idx.length * 4, ib, GLES30.GL_STATIC_DRAW);
            GLES30.glEnableVertexAttribArray(0);
            GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, 0);
            GLES30.glEnableVertexAttribArray(1);
            GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, 12);
            GLES30.glEnableVertexAttribArray(2);
            GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, 32, 24);
            GLES30.glBindVertexArray(0);
            count = idx.length;
        }

        public void draw() {
            GLES30.glBindVertexArray(vao);
            GLES30.glDrawElements(GLES30.GL_TRIANGLES, count, GLES30.GL_UNSIGNED_INT, 0);
        }
    }

    public final List<Prim> prims = new ArrayList<>();
    public int triangles;

    private ByteBuffer bb;
    private byte[] raw;
    private int binOff = -1;
    private JSONObject root;
    private JSONArray accessors, bufferViews, meshes, nodes, materials, textures, images;
    private final Map<Integer, Bitmap> bmpCache = new HashMap<>();

    public static GlbModel parse(byte[] bytes, float targetHeight) throws Exception {
        GlbModel m = new GlbModel();
        m.read(bytes, targetHeight);
        return m;
    }

    /** Вызывать в GL-потоке (повторно после потери контекста). */
    public void upload() {
        Map<Bitmap, Integer> texMap = new HashMap<>();
        for (Prim p : prims) {
            p.uploadGeometry();
            p.tex = 0;
            if (p.bmp != null) {
                Integer t = texMap.get(p.bmp);
                if (t == null) { t = makeTex(p.bmp); texMap.put(p.bmp, t); }
                p.tex = t;
            }
        }
    }

    public static int makeTex(Bitmap bmp) {
        int[] t = new int[1];
        GLES30.glGenTextures(1, t, 0);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t[0]);
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0);
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT);
        return t[0];
    }

    // ---------------- разбор ----------------
    private JSONArray arr(String n) { JSONArray a = root.optJSONArray(n); return a != null ? a : new JSONArray(); }

    private void read(byte[] bytes, float targetH) throws Exception {
        raw = bytes;
        bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        if (bytes.length < 20 || bb.getInt(0) != 0x46546C67) throw new Exception("это не .glb файл");
        int total = Math.min(bb.getInt(8), bytes.length), pos = 12;
        String json = null;
        while (pos + 8 <= total) {
            int len = bb.getInt(pos), type = bb.getInt(pos + 4), start = pos + 8;
            if (type == 0x4E4F534A) json = new String(bytes, start, len, "UTF-8");
            else if (type == 0x004E4942 && binOff < 0) binOff = start;
            pos = start + ((len + 3) & ~3);
        }
        if (json == null) throw new Exception("в .glb нет JSON-части");
        root = new JSONObject(json);
        JSONArray req = root.optJSONArray("extensionsRequired");
        if (req != null) for (int i = 0; i < req.length(); i++) {
            String e = req.getString(i);
            if (e.contains("draco") || e.contains("meshopt"))
                throw new Exception("GLB сжат (" + e + "). Экспортируй без сжатия.");
        }
        accessors = arr("accessors"); bufferViews = arr("bufferViews"); meshes = arr("meshes");
        nodes = arr("nodes"); materials = arr("materials"); textures = arr("textures"); images = arr("images");

        List<Integer> roots = new ArrayList<>();
        JSONArray scenes = root.optJSONArray("scenes");
        if (scenes != null && scenes.length() > 0) {
            JSONObject sc = scenes.getJSONObject(Math.min(root.optInt("scene", 0), scenes.length() - 1));
            JSONArray ns = sc.optJSONArray("nodes");
            if (ns != null) for (int i = 0; i < ns.length(); i++) roots.add(ns.getInt(i));
        } else {
            boolean[] child = new boolean[nodes.length()];
            for (int i = 0; i < nodes.length(); i++) {
                JSONArray c = nodes.getJSONObject(i).optJSONArray("children");
                if (c != null) for (int j = 0; j < c.length(); j++) child[c.getInt(j)] = true;
            }
            for (int i = 0; i < child.length; i++) if (!child[i]) roots.add(i);
        }
        float[] id = new float[16];
        Matrix.setIdentityM(id, 0);
        for (int r : roots) visit(r, id, 0);
        if (prims.isEmpty()) throw new Exception("в модели нет мешей");
        normalize(targetH);
    }

    private void visit(int ni, float[] parent, int depth) throws Exception {
        if (depth > 64) return;
        JSONObject n = nodes.getJSONObject(ni);
        float[] local = new float[16];
        if (n.has("matrix")) {
            JSONArray m = n.getJSONArray("matrix");
            for (int k = 0; k < 16; k++) local[k] = (float) m.getDouble(k);
        } else {
            float[] t = {0, 0, 0}, r = {0, 0, 0, 1}, s = {1, 1, 1};
            fill(n.optJSONArray("translation"), t); fill(n.optJSONArray("rotation"), r); fill(n.optJSONArray("scale"), s);
            float[] rm = new float[16], tmp = new float[16];
            quat(rm, r);
            Matrix.setIdentityM(local, 0);
            Matrix.translateM(local, 0, t[0], t[1], t[2]);
            Matrix.multiplyMM(tmp, 0, local, 0, rm, 0);
            System.arraycopy(tmp, 0, local, 0, 16);
            Matrix.scaleM(local, 0, s[0], s[1], s[2]);
        }
        float[] world = new float[16];
        Matrix.multiplyMM(world, 0, parent, 0, local, 0);
        if (n.has("mesh")) {
            float[] mw = world;
            if (n.has("skin")) { mw = new float[16]; Matrix.setIdentityM(mw, 0); } // скин: трансформ узла игнорируется
            addMesh(n.getInt("mesh"), mw);
        }
        JSONArray ch = n.optJSONArray("children");
        if (ch != null) for (int i = 0; i < ch.length(); i++) visit(ch.getInt(i), world, depth + 1);
    }

    private static void fill(JSONArray a, float[] out) throws Exception {
        if (a == null) return;
        for (int i = 0; i < out.length && i < a.length(); i++) out[i] = (float) a.getDouble(i);
    }

    private static void quat(float[] m, float[] q) {
        float x = q[0], y = q[1], z = q[2], w = q[3];
        float xx = x * x, yy = y * y, zz = z * z, xy = x * y, xz = x * z, yz = y * z, wx = w * x, wy = w * y, wz = w * z;
        m[0] = 1 - 2 * (yy + zz); m[1] = 2 * (xy + wz); m[2] = 2 * (xz - wy); m[3] = 0;
        m[4] = 2 * (xy - wz); m[5] = 1 - 2 * (xx + zz); m[6] = 2 * (yz + wx); m[7] = 0;
        m[8] = 2 * (xz + wy); m[9] = 2 * (yz - wx); m[10] = 1 - 2 * (xx + yy); m[11] = 0;
        m[12] = 0; m[13] = 0; m[14] = 0; m[15] = 1;
    }

    private void addMesh(int mi, float[] w) throws Exception {
        JSONArray ps = meshes.getJSONObject(mi).getJSONArray("primitives");
        for (int pi = 0; pi < ps.length(); pi++) {
            JSONObject p = ps.getJSONObject(pi);
            if (p.optInt("mode", 4) != 4) continue;
            JSONObject at = p.getJSONObject("attributes");
            if (!at.has("POSITION")) continue;
            float[] pos = readAcc(at.getInt("POSITION"));
            int vc = pos.length / 3;
            float[] nor = at.has("NORMAL") ? readAcc(at.getInt("NORMAL")) : null;
            float[] uv = at.has("TEXCOORD_0") ? readAcc(at.getInt("TEXCOORD_0")) : null;
            int[] idx;
            if (p.has("indices")) {
                float[] f = readAcc(p.getInt("indices"));
                idx = new int[f.length - f.length % 3];
                for (int i = 0; i < idx.length; i++) { int v = (int) f[i]; idx[i] = (v >= 0 && v < vc) ? v : 0; }
            } else {
                idx = new int[vc - vc % 3];
                for (int i = 0; i < idx.length; i++) idx[i] = i;
            }
            if (nor == null || nor.length < vc * 3) nor = computeNormals(pos, idx);
            float[] data = new float[vc * 8];
            for (int v = 0; v < vc; v++) {
                float x = pos[v * 3], y = pos[v * 3 + 1], z = pos[v * 3 + 2];
                float nx = nor[v * 3], ny = nor[v * 3 + 1], nz = nor[v * 3 + 2];
                data[v * 8] = w[0] * x + w[4] * y + w[8] * z + w[12];
                data[v * 8 + 1] = w[1] * x + w[5] * y + w[9] * z + w[13];
                data[v * 8 + 2] = w[2] * x + w[6] * y + w[10] * z + w[14];
                float tx = w[0] * nx + w[4] * ny + w[8] * nz, ty = w[1] * nx + w[5] * ny + w[9] * nz, tz = w[2] * nx + w[6] * ny + w[10] * nz;
                float l = (float) Math.sqrt(tx * tx + ty * ty + tz * tz);
                if (l < 1e-8f) { tx = 0; ty = 1; tz = 0; l = 1; }
                data[v * 8 + 3] = tx / l; data[v * 8 + 4] = ty / l; data[v * 8 + 5] = tz / l;
                if (uv != null && uv.length >= vc * 2) { data[v * 8 + 6] = uv[v * 2]; data[v * 8 + 7] = uv[v * 2 + 1]; }
            }
            Prim pr = new Prim();
            pr.data = data; pr.idx = idx;
            if (p.has("material")) applyMaterial(pr, materials.getJSONObject(p.getInt("material")));
            prims.add(pr);
            triangles += idx.length / 3;
        }
    }

    private void applyMaterial(Prim pr, JSONObject mat) throws Exception {
        JSONObject pbr = mat.optJSONObject("pbrMetallicRoughness");
        if (pbr != null) {
            fill(pbr.optJSONArray("baseColorFactor"), pr.color);
            JSONObject bt = pbr.optJSONObject("baseColorTexture");
            if (bt != null) pr.bmp = image(bt.getInt("index"));
        }
        JSONObject ext = mat.optJSONObject("extensions");
        JSONObject sg = ext != null ? ext.optJSONObject("KHR_materials_pbrSpecularGlossiness") : null;
        if (sg != null && pr.bmp == null) {
            fill(sg.optJSONArray("diffuseFactor"), pr.color);
            JSONObject dt = sg.optJSONObject("diffuseTexture");
            if (dt != null) pr.bmp = image(dt.getInt("index"));
        }
    }

    private Bitmap image(int ti) {
        try {
            JSONObject t = textures.getJSONObject(ti);
            if (!t.has("source")) return null;
            int si = t.getInt("source");
            if (bmpCache.containsKey(si)) return bmpCache.get(si);
            JSONObject im = images.getJSONObject(si);
            Bitmap bm = null;
            if (im.has("bufferView")) {
                JSONObject bv = bufferViews.getJSONObject(im.getInt("bufferView"));
                int off = binOff + bv.optInt("byteOffset", 0), len = bv.getInt("byteLength");
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(raw, off, len, o);
                int ss = 1;
                while (o.outWidth / ss > 2048 || o.outHeight / ss > 2048) ss *= 2;
                o = new BitmapFactory.Options();
                o.inSampleSize = ss;
                bm = BitmapFactory.decodeByteArray(raw, off, len, o);
            }
            bmpCache.put(si, bm);
            return bm;
        } catch (Exception e) { return null; }
    }

    private static float[] computeNormals(float[] pos, int[] idx) {
        float[] n = new float[pos.length];
        for (int i = 0; i + 2 < idx.length; i += 3) {
            int a = idx[i] * 3, b = idx[i + 1] * 3, c = idx[i + 2] * 3;
            float ux = pos[b] - pos[a], uy = pos[b + 1] - pos[a + 1], uz = pos[b + 2] - pos[a + 2];
            float vx = pos[c] - pos[a], vy = pos[c + 1] - pos[a + 1], vz = pos[c + 2] - pos[a + 2];
            float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
            for (int k : new int[]{a, b, c}) { n[k] += nx; n[k + 1] += ny; n[k + 2] += nz; }
        }
        return n;
    }

    private float readComp(int p, int ct, boolean norm) {
        switch (ct) {
            case 5126: return bb.getFloat(p);
            case 5123: { int v = bb.getShort(p) & 0xFFFF; return norm ? v / 65535f : v; }
            case 5125: return (float) (bb.getInt(p) & 0xFFFFFFFFL);
            case 5121: { int v = bb.get(p) & 0xFF; return norm ? v / 255f : v; }
            case 5120: { int v = bb.get(p); return norm ? Math.max(v / 127f, -1f) : v; }
            case 5122: { int v = bb.getShort(p); return norm ? Math.max(v / 32767f, -1f) : v; }
            default: return 0f;
        }
    }

    private float[] readAcc(int ai) throws Exception {
        JSONObject a = accessors.getJSONObject(ai);
        int count = a.getInt("count"), ct = a.getInt("componentType");
        String ty = a.getString("type");
        int comps = ty.equals("SCALAR") ? 1 : ty.equals("VEC2") ? 2 : ty.equals("VEC3") ? 3 : ty.equals("VEC4") ? 4 : ty.equals("MAT4") ? 16 : 1;
        boolean norm = a.optBoolean("normalized", false);
        float[] out = new float[count * comps];
        if (!a.has("bufferView")) return out;
        JSONObject bv = bufferViews.getJSONObject(a.getInt("bufferView"));
        int off = binOff + bv.optInt("byteOffset", 0) + a.optInt("byteOffset", 0);
        int cs = (ct == 5126 || ct == 5125) ? 4 : (ct == 5123 || ct == 5122) ? 2 : 1;
        int stride = bv.optInt("byteStride", 0);
        if (stride == 0) stride = cs * comps;
        for (int i = 0; i < count; i++)
            for (int j = 0; j < comps; j++) out[i * comps + j] = readComp(off + i * stride + j * cs, ct, norm);
        return out;
    }

    /** Масштаб до targetH метров, ноги на y=0, центр по XZ. */
    private void normalize(float targetH) {
        float minX = 1e30f, minY = 1e30f, minZ = 1e30f, maxX = -1e30f, maxY = -1e30f, maxZ = -1e30f;
        for (Prim p : prims) for (int i = 0; i < p.data.length; i += 8) {
            minX = Math.min(minX, p.data[i]); maxX = Math.max(maxX, p.data[i]);
            minY = Math.min(minY, p.data[i + 1]); maxY = Math.max(maxY, p.data[i + 1]);
            minZ = Math.min(minZ, p.data[i + 2]); maxZ = Math.max(maxZ, p.data[i + 2]);
        }
        float h = maxY - minY;
        if (h < 1e-6f) h = 1f;
        float s = targetH / h, cx = (minX + maxX) / 2f, cz = (minZ + maxZ) / 2f;
        for (Prim p : prims) for (int i = 0; i < p.data.length; i += 8) {
            p.data[i] = (p.data[i] - cx) * s;
            p.data[i + 1] = (p.data[i + 1] - minY) * s;
            p.data[i + 2] = (p.data[i + 2] - cz) * s;
        }
    }
}
