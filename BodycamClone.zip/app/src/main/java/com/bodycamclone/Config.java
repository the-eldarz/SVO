package com.bodycamclone;

public final class Config {
    private Config() {}
    /** Модель для наших бойцов. Файл лежит в app/src/main/assets/models/ */
    public static final String ALLY_MODEL = "models/ukrainian_soldier.glb";
    /** Модель противника. Пока тот же файл; позже можно заменить одной строкой. */
    public static final String ENEMY_MODEL = ALLY_MODEL;
    public static final float SOLDIER_HEIGHT = 1.8f;
    /** Если модель смотрит не туда (лицом назад/вбок) - поправь угол: 180, 90, -90 */
    public static final float MODEL_YAW_OFFSET_DEG = 0f;
    public static final float[] ALLY_TINT = {0.92f, 0.98f, 1.12f};
    public static final float[] ENEMY_TINT = {1.15f, 0.88f, 0.82f};
    public static final float MAP_HALF = 50f;
    public static final int ALLIES = 4;
    public static final float LOOK_SENS = 0.0030f;
}
