package com.bodycamclone;

import android.content.Context;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class GameRenderer implements GLSurfaceView.Renderer {
    private static final String TAG = "Bodycam";
    private static final float[] HIT_TINT = {1.8f, 0.6f, 0.6f};
    private static final float[] WHITE = {1f, 1f, 1f};
    private static final float[] SKY = {0.62f, 0.69f, 0.76f};

    private static final String VS = "#version 300 es\n"
            + "layout(location=0) in vec3 aPos; layout(location=1) in vec3 aNormal; layout(location=2) in vec2 aUV;\n"
            + "uniform mat4 uMVP; uniform mat4 uModel;\n"
            + "out vec3 vN; out vec2 vUV; out vec3 vW;\n"
            + "void main(){ vec4 w = uModel*vec4(aPos,1.0); vW=w.xyz; vN=mat3(uModel)*aNormal; vUV=aUV; gl_Position=uMVP*vec4(aPos,1.0); }\n";
    private static final String FS = "#version 300 es\n"
            + "precision highp float;\n"
            + "uniform vec4 uColor; uniform vec3 uTint; uniform sampler2D uTex; uniform int uUseTex; uniform int uMode;\n"
            + "uniform vec3 uSun; uniform vec3 uCam; uniform float uFog; uniform vec3 uFogColor; uniform float uEmissive;\n"
            + "in vec3 vN; in vec2 vUV; in vec3 vW; out vec4 o;\n"
            + "void main(){\n"
            + "  vec4 base = uColor;\n"
            + "  if(uUseTex==1){ vec4 t = texture(uTex, vUV); if(t.a<0.4) discard; base.rgb *= t.rgb; }\n"
            + "  if(uMode==3){ o = vec4(base.rgb*uEmissive,1.0); return; }\n"
            + "  if(uMode==1){ float c = mod(floor(vW.x*0.5)+floor(vW.z*0.5),2.0); base.rgb *= 0.92+0.08*c;\n"
            + "                float n = fract(sin(dot(floor(vW.xz*2.0),vec2(12.9898,78.233)))*43758.5453); base.rgb *= 0.94+0.06*n; }\n"
            + "  if(uMode==2){ float s = step(0.5, fract(vW.y*2.5)); base.rgb *= 0.93+0.07*s; }\n"
            + "  vec3 n = normalize(vN);\n"
            + "  float diff = max(dot(n, normalize(uSun)), 0.0);\n"
            + "  vec3 lit = base.rgb*uTint*(0.45+0.65*diff);\n"
            + "  float d = length(vW-uCam);\n"
            + "  float f = clamp((d-25.0)/(uFog-25.0),0.0,1.0);\n"
            + "  o = vec4(mix(lit,uFogColor,f),1.0);\n"
            + "}\n";

    private final Context ctx;
    private final Game game;
    private int prog, uMVP, uModel, uColor, uTint, uTex, uUseTex, uMode, uSun, uCam, uFog, uFogColor, uEmissive;
    private GlbModel.Prim cube;
    private final Map<String, GlbModel> models = new HashMap<>();
    private GlbModel modelAlly, modelEnemy;
    private boolean loadedOnce;
    private int w = 1, h = 1;
    private long last;
    private final float[] proj = new float[16], view = new float[16], vp = new float[16];
    private final float[] model = new float[16], mvp = new float[16], base = new float[16], tmp = new float[16];

    public GameRenderer(Context ctx, Game game) { this.ctx = ctx; this.game = game; }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        prog = buildProgram();
        uMVP = loc("uMVP"); uModel = loc("uModel"); uColor = loc("uColor"); uTint = loc("uTint");
        uTex = loc("uTex"); uUseTex = loc("uUseTex"); uMode = loc("uMode"); uSun = loc("uSun");
        uCam = loc("uCam"); uFog = loc("uFog"); uFogColor = loc("uFogColor"); uEmissive = loc("uEmissive");
        cube = makeCube();
        cube.uploadGeometry();
        if (!loadedOnce) {
            loadedOnce = true;
            String allyPath = game.side == Config.SIDE_RU ? Config.RU_MODEL : Config.UA_MODEL;
            String enemyPath = game.side == Config.SIDE_RU ? Config.UA_MODEL : Config.RU_MODEL;
            GlbModel ma = loadModel(allyPath), me = loadModel(enemyPath);
            String missing = (ma == null ? allyPath.substring(7) + " " : "") + (me == null ? enemyPath.substring(7) : "");
            if (ma == null) ma = me;
            if (me == null) me = ma;
            modelAlly = ma; modelEnemy = me;
            if (missing.trim().length() > 0) {
                game.status = "Нет модели: " + missing.trim() + (ma != null ? " (пока стоит другая модель)" : " (показаны заглушки)");
                game.statusError = true;
            }
        }
        for (GlbModel m : models.values()) if (m != null) m.upload();
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);
        last = 0;
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        w = Math.max(1, width); h = Math.max(1, height);
        GLES30.glViewport(0, 0, w, h);
    }

    private int loc(String n) { return GLES30.glGetUniformLocation(prog, n); }

    private int buildProgram() {
        int vs = compile(GLES30.GL_VERTEX_SHADER, VS), fs = compile(GLES30.GL_FRAGMENT_SHADER, FS);
        int p = GLES30.glCreateProgram();
        GLES30.glAttachShader(p, vs); GLES30.glAttachShader(p, fs);
        GLES30.glLinkProgram(p);
        int[] ok = new int[1];
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("link: " + GLES30.glGetProgramInfoLog(p));
        return p;
    }

    private int compile(int type, String src) {
        int s = GLES30.glCreateShader(type);
        GLES30.glShaderSource(s, src);
        GLES30.glCompileShader(s);
        int[] ok = new int[1];
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("shader: " + GLES30.glGetShaderInfoLog(s));
        return s;
    }

    private GlbModel loadModel(String path) {
        if (models.containsKey(path)) return models.get(path);
        GlbModel m = null;
        try (InputStream in = ctx.getAssets().open(path)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 20);
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            m = GlbModel.parse(bo.toByteArray(), Config.SOLDIER_HEIGHT);
            game.status = "Модель загружена: " + m.triangles + " треугольников";
            game.statusError = false;
        } catch (FileNotFoundException e) {
            game.status = "Не найден " + path + " (положи в app/src/main/assets/models/). Показаны заглушки";
            game.statusError = true;
        } catch (Throwable e) {
            Log.e(TAG, "model " + path, e);
            game.status = "Ошибка модели: " + e.getMessage() + ". Показаны заглушки";
            game.statusError = true;
        }
        models.put(path, m);
        return m;
    }

    private static GlbModel.Prim makeCube() {
        float[][] f = {
                {0, 0, 1, 1, 0, 0, 0, 1, 0}, {0, 0, -1, -1, 0, 0, 0, 1, 0},
                {1, 0, 0, 0, 0, -1, 0, 1, 0}, {-1, 0, 0, 0, 0, 1, 0, 1, 0},
                {0, 1, 0, 1, 0, 0, 0, 0, -1}, {0, -1, 0, 1, 0, 0, 0, 0, 1}};
        float[] sa = {-1, 1, 1, -1}, sb = {-1, -1, 1, 1};
        float[] d = new float[24 * 8];
        int[] idx = new int[36];
        for (int i = 0; i < 6; i++) {
            float[] q = f[i];
            for (int k = 0; k < 4; k++) {
                int o = (i * 4 + k) * 8;
                d[o] = 0.5f * (q[0] + sa[k] * q[3] + sb[k] * q[6]);
                d[o + 1] = 0.5f * (q[1] + sa[k] * q[4] + sb[k] * q[7]);
                d[o + 2] = 0.5f * (q[2] + sa[k] * q[5] + sb[k] * q[8]);
                d[o + 3] = q[0]; d[o + 4] = q[1]; d[o + 5] = q[2];
                d[o + 6] = (sa[k] + 1) / 2; d[o + 7] = (sb[k] + 1) / 2;
            }
            int b = i * 4, o = i * 6;
            idx[o] = b; idx[o + 1] = b + 1; idx[o + 2] = b + 2; idx[o + 3] = b; idx[o + 4] = b + 2; idx[o + 5] = b + 3;
        }
        GlbModel.Prim p = new GlbModel.Prim();
        p.data = d; p.idx = idx;
        return p;
    }

    private void setU(float[] mvpM, float[] modelM, float r, float g, float b, float[] tint, int mode, float emis, int useTex) {
        GLES30.glUniformMatrix4fv(uMVP, 1, false, mvpM, 0);
        GLES30.glUniformMatrix4fv(uModel, 1, false, modelM, 0);
        GLES30.glUniform4f(uColor, r, g, b, 1f);
        GLES30.glUniform3f(uTint, tint[0], tint[1], tint[2]);
        GLES30.glUniform1i(uMode, mode);
        GLES30.glUniform1f(uEmissive, emis);
        GLES30.glUniform1i(uUseTex, useTex);
    }

    /** Бокс: parent * T(cx,cy,cz) * S(sx,sy,sz); parent может быть null. */
    private void box(float[] vpM, float[] parent, float cx, float cy, float cz, float sx, float sy, float sz,
                     float r, float g, float b, float[] tint, int mode, float emis) {
        if (parent == null) Matrix.setIdentityM(tmp, 0);
        else System.arraycopy(parent, 0, tmp, 0, 16);
        Matrix.translateM(tmp, 0, cx, cy, cz);
        Matrix.scaleM(tmp, 0, sx, sy, sz);
        Matrix.multiplyMM(mvp, 0, vpM, 0, tmp, 0);
        setU(mvp, tmp, r, g, b, tint, mode, emis, 0);
        cube.draw();
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        game.update(dt);
        Game.Player p = game.p;

        GLES30.glClearColor(SKY[0], SKY[1], SKY[2], 1f);
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);
        GLES30.glUseProgram(prog);
        GLES30.glUniform1i(uTex, 0);
        GLES30.glUniform3f(uSun, 0.4f, 0.9f, 0.3f);
        GLES30.glUniform1f(uFog, 110f);
        GLES30.glUniform3f(uFogColor, SKY[0], SKY[1], SKY[2]);

        float aspect = (float) w / h;
        float sy = (float) Math.sin(p.yaw), cy = (float) Math.cos(p.yaw);
        float cp = (float) Math.cos(p.pitch), sp = (float) Math.sin(p.pitch);
        float bobY = p.moving ? Math.abs((float) Math.sin(p.bob)) * 0.035f : 0f;
        float eyeY = p.alive ? 1.6f + bobY : 1.6f - Math.min(1f, p.deadT * 2f) * 1.25f;
        float roll = p.moving ? (float) Math.sin(p.bob) * 0.012f : 0f;
        float ex = p.x, ez = p.z;
        Matrix.perspectiveM(proj, 0, game.curFov(), aspect, 0.1f, 200f);
        Matrix.setLookAtM(view, 0, ex, eyeY, ez, ex + cp * sy, eyeY + sp, ez - cp * cy,
                (float) Math.sin(roll), (float) Math.cos(roll), 0f);
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0);
        GLES30.glUniform3f(uCam, ex, eyeY, ez);

        float fx = sy, fz = -cy;
        for (WorldMap.Box b : game.map.boxes) {
            float cx = (b.x0 + b.x1) / 2f, cyy = (b.y0 + b.y1) / 2f, cz = (b.z0 + b.z1) / 2f;
            float sx = b.x1 - b.x0, sh = b.y1 - b.y0, sz = b.z1 - b.z0;
            float rad = (float) Math.hypot(sx, sz) / 2f;
            float dx = cx - ex, dz = cz - ez;
            if (dx * fx + dz * fz < -rad) continue;
            if (dx * dx + dz * dz > (130f + rad) * (130f + rad)) continue;
            box(vp, null, cx, cyy, cz, sx, sh, sz, b.r, b.g, b.b, WHITE, b.mode, 0f);
        }
        for (Soldier s : game.soldiers) {
            float dx = s.x - ex, dz = s.z - ez;
            if (dx * dx + dz * dz > 120f * 120f) continue;
            drawSoldier(s);
        }
        drawViewmodel(aspect);
    }

    private void drawSoldier(Soldier s) {
        float[] tint = s.team == 0 ? Config.ALLY_TINT : Config.ENEMY_TINT;
        if (s.hitFlash > 0f) tint = HIT_TINT;
        if (s.dead) tint = new float[]{tint[0] * 0.65f, tint[1] * 0.65f, tint[2] * 0.65f};
        Matrix.setIdentityM(base, 0);
        Matrix.translateM(base, 0, s.x, 0f, s.z);
        float yawOff = ((s.team == 0) == (game.side == Config.SIDE_RU)) ? Config.RU_YAW_OFFSET_DEG : Config.UA_YAW_OFFSET_DEG;
        Matrix.rotateM(base, 0, 180f - (float) Math.toDegrees(s.yaw) + yawOff, 0f, 1f, 0f);
        if (s.dead) {
            float f = Math.min(1f, s.deadT / 0.5f);
            Matrix.translateM(base, 0, 0f, 0.2f * f, 0f);
            Matrix.rotateM(base, 0, -90f * f, 1f, 0f, 0f);
        } else if (s.moving) {
            float ph = s.walkPhase;
            Matrix.translateM(base, 0, 0f, Math.abs((float) Math.sin(ph)) * 0.04f, 0f);
            Matrix.rotateM(base, 0, (float) Math.sin(ph) * 3f, 0f, 0f, 1f);
        }
        GlbModel m = s.team == 0 ? modelAlly : modelEnemy;
        if (m != null) {
            Matrix.multiplyMM(mvp, 0, vp, 0, base, 0);
            for (GlbModel.Prim p : m.prims) {
                setU(mvp, base, p.color[0], p.color[1], p.color[2], tint, 0, 0f, p.tex != 0 ? 1 : 0);
                if (p.tex != 0) { GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, p.tex); }
                p.draw();
            }
        } else {
            float[][] parts = {
                    {-.12f, .42f, 0, .2f, .84f, .22f, .30f, .35f, .22f}, {.12f, .42f, 0, .2f, .84f, .22f, .30f, .35f, .22f},
                    {0, 1.12f, 0, .46f, .6f, .26f, .33f, .38f, .24f},
                    {-.3f, 1.1f, .05f, .14f, .55f, .16f, .33f, .38f, .24f}, {.3f, 1.1f, .05f, .14f, .55f, .16f, .33f, .38f, .24f},
                    {0, 1.6f, 0, .22f, .24f, .24f, .8f, .62f, .5f}, {0, 1.74f, 0, .28f, .12f, .3f, .25f, .3f, .2f},
                    {.18f, 1.2f, .3f, .06f, .08f, .7f, .1f, .1f, .1f}};
            for (float[] q : parts) box(vp, base, q[0], q[1], q[2], q[3], q[4], q[5], q[6], q[7], q[8], tint, 0, 0f);
        }
        if (s.flash > 0f && !s.dead) box(vp, base, 0.18f, 1.25f, 0.8f, .16f, .16f, .16f, 1f, .85f, .35f, WHITE, 3, 1.5f);
    }

    private void drawViewmodel(float aspect) {
        Game.Player p = game.p;
        if (!p.alive) return;
        GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT);
        Matrix.perspectiveM(proj, 0, 60f, aspect, 0.02f, 5f);
        GLES30.glUniform3f(uCam, 0f, 0f, 0f);
        float sway = p.moving ? (float) Math.sin(p.bob) * 0.012f : 0f;
        float bob = p.moving ? Math.abs((float) Math.cos(p.bob)) * 0.012f : 0f;
        float dip = 0f;
        float[] wdef = Game.W_RELOAD_PUBLIC();
        if (p.reloadT > 0f) dip = (float) Math.sin(Math.PI * (1f - p.reloadT / wdef[p.weapon]));
        Matrix.setIdentityM(base, 0);
        float a = p.aimT;
        float px = (0.16f + sway) * (1f - a);
        float py = (-0.17f + bob - 0.2f * dip) * (1f - a) + (-0.095f - 0.2f * dip) * a;
        float pz = -0.38f * (1f - a) - 0.30f * a + p.kick * 0.05f * (1f - 0.5f * a);
        Matrix.translateM(base, 0, px, py, pz);
        Matrix.rotateM(base, 0, p.kick * 4f - 28f * dip, 1f, 0f, 0f);
        float[] sleeve = {.26f, .3f, .2f}, dark = {.12f, .12f, .13f}, wood = {.35f, .2f, .1f};
        if (p.weapon == 0) {
            vm(.0f, .0f, .0f, .06f, .09f, .55f, dark);
            vm(.0f, .02f, -.45f, .025f, .025f, .4f, new float[]{.2f, .2f, .22f});
            vm(.0f, -.005f, -.22f, .07f, .07f, .25f, wood);
            vm(.0f, -.03f, .38f, .05f, .12f, .25f, wood);
            vm(.0f, -.15f, -.03f, .04f, .16f, .07f, dark);
            vm(.0f, .06f, -.62f, .01f, .04f, .01f, dark);
            vm(.04f, -.14f, .25f, .07f, .07f, .4f, sleeve);
            vm(-.07f, -.07f, -.25f, .07f, .07f, .4f, sleeve);
            if (p.flashT > 0f) box(proj, base, 0f, .02f, -.7f, .09f, .09f, .06f, 1f, .85f, .3f, WHITE, 3, 1.6f);
        } else {
            vm(0f, 0f, 0f, .04f, .06f, .2f, dark);
            vm(0f, -.07f, .07f, .035f, .11f, .05f, wood);
            vm(.02f, -.1f, .15f, .07f, .07f, .35f, sleeve);
            vm(-.03f, -.1f, .1f, .07f, .07f, .3f, sleeve);
            if (p.flashT > 0f) box(proj, base, 0f, 0f, -.14f, .06f, .06f, .05f, 1f, .85f, .3f, WHITE, 3, 1.6f);
        }
    }

    private void vm(float x, float y, float z, float sx, float sy, float sz, float[] c) {
        box(proj, base, x, y, z, sx, sy, sz, c[0], c[1], c[2], WHITE, 0, 0f);
    }
}
