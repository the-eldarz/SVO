package com.bodycamclone;

public class Soldier {
    public final int team; // 0 = Украина (наши), 1 = противник
    public float x, z, yaw, hp = 100f;
    public boolean dead, moving, los, pause;
    public float deadT, walkPhase, fireCd, flash, hitFlash, strafeT, strafeDir = 1f,
            losT, reactT, stuckT, avoidT, avoidDir = 1f;
    public int burst;

    public Soldier(int team, float x, float z, float yaw) {
        this.team = team; this.x = x; this.z = z; this.yaw = yaw;
    }
}
