package com.bodycamclone;

import android.content.Context;
import android.content.res.AssetManager;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Finds loose animation files copied by the GitHub Actions workflow into assets/user_files and loads their clips. */
public final class AnimationLibrary {
    private static final String ROOT = "user_files";
    private AnimationLibrary() {}

    /** Результат загрузки: клипы + счётчики для строки статуса в игре. */
    public static final class Result {
        public final List<GlbModel.Clip> clips = new ArrayList<>();
        public int glbFiles, fbxFiles, badFiles;
    }

    /** Метки клипа смерти, выведенные из имени файла (см. tagOf). T_CROUCH - боец умирает из приседа. */
    public static final int T_FRONT = 1, T_BACK = 2, T_SIDE = 4, T_HEAD = 8, T_CROUCH = 16;

    /** Направления движения относительно взгляда бойца и «походки» (шаг / бег / спринт / шаг в приседе). */
    public static final int D_F = 0, D_FL = 1, D_FR = 2, D_L = 3, D_R = 4, D_B = 5, D_BL = 6, D_BR = 7;
    public static final int G_WALK = 0, G_RUN = 1, G_SPRINT = 2, G_CWALK = 3;

    /** Клипы, выбранные для состояний бойца. null = для состояния нет подходящего клипа (используется запасной вариант). */
    public static final class Set {
        public GlbModel.Clip idle, idleAim, idleCrouch, idleCrouchAim;
        public GlbModel.Clip fire, reload, hit, grenade, jumpUp, jumpLoop, jumpDown, jumpAny;
        /** loco[походка][направление]. */
        public final GlbModel.Clip[][] loco = new GlbModel.Clip[4][8];
        /** Любой клип бега вперёд (для строки статуса и старого кода). */
        public GlbModel.Clip move;
        /** Первый клип смерти (для совместимости) и полный список. */
        public GlbModel.Clip death;
        public final List<GlbModel.Clip> deaths = new ArrayList<>();
        final Map<GlbModel.Clip, Integer> tags = new IdentityHashMap<>();
        final Map<GlbModel.Clip, Integer> rank = new IdentityHashMap<>();
        /** Клипы, которые нашлись, но пока нигде не используются (повороты на месте). */
        public final List<GlbModel.Clip> unused = new ArrayList<>();

        public boolean any() {
            return idle != null || idleAim != null || move != null || fire != null || !deaths.isEmpty() || locoCount() > 0;
        }
        public int tag(GlbModel.Clip c) { Integer t = tags.get(c); return t == null ? 0 : t; }
        public int locoCount() {
            int n = 0;
            for (GlbModel.Clip[] g : loco) for (GlbModel.Clip c : g) if (c != null) n++;
            return n;
        }
        /** Убирает клип смерти (например, не подошёл к скелету). */
        public void removeDeath(GlbModel.Clip c) {
            deaths.remove(c); tags.remove(c);
            death = deaths.isEmpty() ? null : deaths.get(0);
        }

        /** Фильтр для prune(). */
        public interface Keep { boolean ok(GlbModel.Clip c); }

        /** Выбрасывает клипы, которые Keep не принял (не совпали кости). Возвращает, сколько выброшено. */
        public int prune(Keep k) {
            int bad = 0;
            GlbModel.Clip[] f = {idle, idleAim, idleCrouch, idleCrouchAim, fire, reload, hit, grenade, jumpUp, jumpLoop, jumpDown, jumpAny};
            for (int i = 0; i < f.length; i++) if (f[i] != null && !k.ok(f[i])) { f[i] = null; bad++; }
            idle = f[0]; idleAim = f[1]; idleCrouch = f[2]; idleCrouchAim = f[3]; fire = f[4]; reload = f[5]; hit = f[6];
            grenade = f[7]; jumpUp = f[8]; jumpLoop = f[9]; jumpDown = f[10]; jumpAny = f[11];
            for (GlbModel.Clip[] g : loco) for (int i = 0; i < g.length; i++) if (g[i] != null && !k.ok(g[i])) { g[i] = null; bad++; }
            for (GlbModel.Clip dc : new ArrayList<>(deaths)) if (!k.ok(dc)) { removeDeath(dc); bad++; }
            if (move != null && !k.ok(move)) move = null;
            fixMove();
            return bad;
        }

        void fixMove() {
            move = null;
            for (int g : new int[]{G_RUN, G_WALK, G_SPRINT, G_CWALK}) if (loco[g][D_F] != null) { move = loco[g][D_F]; break; }
        }

        /**
         * Клип походки: ближайшее доступное направление, затем соседние походки
         * (спринт -> бег -> шаг, бег -> шаг -> спринт, шаг -> бег, присед -> шаг).
         */
        public GlbModel.Clip locoClip(int gait, int dir) {
            int[][] gaits = {{G_WALK, G_RUN, G_SPRINT}, {G_RUN, G_WALK, G_SPRINT}, {G_SPRINT, G_RUN, G_WALK}, {G_CWALK, G_WALK, G_RUN}};
            int[][] dirs = {{D_F}, {D_FL, D_L, D_F}, {D_FR, D_R, D_F}, {D_L, D_FL, D_BL, D_F}, {D_R, D_FR, D_BR, D_F},
                    {D_B, D_BL, D_BR}, {D_BL, D_B, D_L}, {D_BR, D_B, D_R}};
            for (int g : gaits[gait]) for (int d : dirs[dir]) if (loco[g][d] != null) return loco[g][d];
            return null;
        }

        void put(GlbModel.Clip[] slot, int idx, GlbModel.Clip c, int r) {
            GlbModel.Clip old = slot[idx];
            if (old == null || r > rank.get(old)) { slot[idx] = c; rank.put(c, r); }
        }
    }

    /** Returns FBX/GLB animation asset paths, including files in nested folders. */
    public static List<String> find(Context context) throws IOException {
        List<String> result = new ArrayList<>();
        scan(context.getAssets(), ROOT, result);
        Collections.sort(result, String.CASE_INSENSITIVE_ORDER);
        return result;
    }

    private static void scan(AssetManager assets, String path, List<String> out) throws IOException {
        String[] entries = assets.list(path);
        if (entries == null || entries.length == 0) return;
        for (String entry : entries) {
            String child = path + "/" + entry;
            String[] nested = assets.list(child);
            if (nested != null && nested.length > 0) {
                scan(assets, child, out);
            } else {
                String lower = entry.toLowerCase(Locale.ROOT);
                if (lower.endsWith(".fbx") || lower.endsWith(".glb") || (lower.endsWith(".zip") && !lower.startsWith("svo"))) out.add(child);   // zip с анимациями (но не архив самого проекта)
            }
        }
    }

    /** Читает клипы из всех .glb, .fbx и из .zip с ними в user_files. */
    public static Result loadClips(Context context) {
        Result r = new Result();
        List<String> files;
        try { files = find(context); } catch (IOException e) { return r; }
        for (String path : files) {
            String lower = path.toLowerCase(Locale.ROOT);
            String fileName = path.substring(path.lastIndexOf('/') + 1);
            try (InputStream in = context.getAssets().open(path)) {
                if (lower.endsWith(".zip")) {
                    String zipBase = fileName.substring(0, fileName.length() - 4);
                    try (ZipInputStream zin = new ZipInputStream(in)) {
                        ZipEntry e;
                        while ((e = zin.getNextEntry()) != null) {
                            String en = e.getName().toLowerCase(Locale.ROOT);
                            if (e.isDirectory() || en.contains("__macosx") || !(en.endsWith(".fbx") || en.endsWith(".glb"))) continue;
                            addClips(r, readAll(zin), e.getName().substring(e.getName().lastIndexOf('/') + 1), zipBase);
                        }
                    }
                } else {
                    String folder = path.substring(0, path.lastIndexOf('/'));
                    addClips(r, readAll(in), fileName, folder.substring(folder.lastIndexOf('/') + 1));
                }
            } catch (Throwable e) {
                r.badFiles++;
            }
        }
        return r;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 20);
        byte[] buf = new byte[1 << 16];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toByteArray();
    }

    /** Добавляет клипы одного файла (.fbx или .glb); folder - папка или имя zip (по слову «pro» выбирается более полный пак). */
    private static void addClips(Result r, byte[] bytes, String fileName, String folder) {
        boolean fbx = fileName.toLowerCase(Locale.ROOT).endsWith(".fbx");
        if (fbx) r.fbxFiles++; else r.glbFiles++;
        try {
            String base = fileName.contains(".") ? fileName.substring(0, fileName.lastIndexOf('.')) : fileName;
            if (fbx) {
                GlbModel.Clip c = fbxClip(bytes, base + "|" + folder);
                if (c != null) r.clips.add(c); else r.badFiles++;
            } else {
                List<GlbModel.Clip> cl = GlbModel.readClips(bytes);
                // Mixamo и многие экспортёры называют клип «mixamo.com»/«Take 001», поэтому имя файла важнее
                for (GlbModel.Clip c : cl) { c.name = base + " " + c.name; r.clips.add(c); }
                if (cl.isEmpty()) r.badFiles++;
            }
        } catch (Throwable e) {
            r.badFiles++;
        }
    }

    /** Один .fbx -> один клип (берётся самый длинный take). Имя клипа: «имя файла|папка». */
    static GlbModel.Clip fbxClip(byte[] bytes, String name) throws IOException {
        FbxReader.Take best = null;
        for (FbxReader.Take t : FbxReader.read(bytes)) if (best == null || t.duration > best.duration) best = t;
        if (best == null) return null;
        GlbModel.Clip c = new GlbModel.Clip();
        c.name = name;
        c.duration = best.duration;
        for (FbxReader.Track t : best.tracks) {
            if (t.path == 0 && !isRootName(GlbModel.norm(t.bone))) continue;   // перемещение нужно только бёдрам (высота), остальное - от скелета модели
            GlbModel.Chan x = new GlbModel.Chan();
            x.key = GlbModel.norm(t.bone); x.path = t.path; x.times = t.times; x.vals = t.vals; x.step = false;
            if (t.path == 0) {
                x.first = new float[]{t.vals[0], t.vals[1], t.vals[2]};
                x.refLen = (float) Math.sqrt(t.vals[0] * t.vals[0] + t.vals[1] * t.vals[1] + t.vals[2] * t.vals[2]);
                int ax = 0;
                for (int j = 1; j < 3; j++) if (Math.abs(x.first[j]) > Math.abs(x.first[ax])) ax = j;
                x.vertAxis = ax;
            }
            c.chans.add(x);
        }
        return c.chans.isEmpty() ? null : c;
    }

    private static boolean isRootName(String k) { return k.equals("hips") || k.equals("pelvis"); }

    /** Слова имени (латиница/кириллица), всё остальное - разделители: «Standing_React Death-Forward.glb» -> [standing, react, death, forward, glb]. */
    private static List<String> words(String name) {
        List<String> w = new ArrayList<>();
        for (String t : name.toLowerCase(Locale.ROOT).split("[^a-zа-я]+")) if (!t.isEmpty()) w.add(t);
        return w;
    }

    /** Клип смерти? Ищем целые слова (а не кусочки: в «soldier» есть «die»). */
    static boolean isDeath(String name) {
        for (String t : words(name)) {
            if (t.startsWith("death") || t.startsWith("dying") || t.startsWith("dead") || t.startsWith("kill")
                    || t.equals("die") || t.equals("dies") || t.equals("died")) return true;
        }
        return false;
    }

    /**
     * Метки по имени. FRONT - стреляли спереди, боец падает назад («Death From Front», «Backward», «Falling Back»);
     * BACK - стреляли сзади, падает вперёд («Death From Back», «Forward», «Behind»); SIDE - «Left»/«Right»; HEAD - «Headshot».
     */
    static int tagOf(String name) {
        StringBuilder sb = new StringBuilder(" ");
        for (String t : words(name)) sb.append(t).append(' ');
        String n = sb.toString();
        boolean back = n.contains("backward") || n.contains("front") || n.contains("falling back") || n.contains("fall back");
        boolean fwd = n.contains("forward") || n.contains("behind") || n.contains("faceplant") || (n.contains(" back ") && !back);
        int t = 0;
        if (back && !fwd) t |= T_FRONT;
        if (fwd && !back) t |= T_BACK;
        if (n.contains(" left ") || n.contains(" right ")) t |= T_SIDE;
        if (n.contains("headshot") || n.contains(" head ")) t |= T_HEAD;
        return t;
    }

    private static final int R_IDLE = 0, R_IDLE_AIM = 1, R_IDLE_C = 2, R_IDLE_CAIM = 3, R_FIRE = 4, R_RELOAD = 5, R_HIT = 6,
            R_GREN = 7, R_JUP = 8, R_JLOOP = 9, R_JDOWN = 10, R_JANY = 11;

    private static boolean has(List<String> w, String... starts) {
        for (String t : w) for (String s : starts) if (t.startsWith(s)) return true;
        return false;
    }

    /**
     * Подбирает клипы по словам в имени файла (латиница/кириллица, регистр и разделители не важны):
     * idle / idle aiming / idle crouching, walk / run / sprint (+ forward, backward, left, right и их сочетания),
     * walk crouching, firing, reload, hit reaction, grenade/toss, jump up/loop/down, death ... (клипов смерти несколько).
     * Одинаковые роли из разных паков: побеждает файл из папки со словом «pro», иначе первый найденный.
     */
    public static Set classify(List<GlbModel.Clip> clips) {
        Set s = new Set();
        GlbModel.Clip[] one = new GlbModel.Clip[12];
        for (GlbModel.Clip c : clips) {
            String full = c.name, folder = "";
            int bar = full.indexOf('|');
            if (bar >= 0) { folder = full.substring(bar + 1).toLowerCase(Locale.ROOT); full = full.substring(0, bar); }
            int rk = 1;
            if (isDeath(full)) {
                s.deaths.add(c);
                int tg = tagOf(full);
                if (has(words(full), "crouch")) tg |= T_CROUCH;
                s.tags.put(c, tg);
                continue;
            }
            List<String> w = words(full);
            rk = (folder.contains("pro") ? 4 : 0) + (has(w, "forward") ? 1 : 0) + 1;   // Pro-пак и явные имена с «forward» главнее
            boolean crouch = has(w, "crouch"), aim = has(w, "aim");
            if (has(w, "turn")) { s.unused.add(c); continue; }                          // повороты на месте: поворачивают бёдра и спорят с yaw игры
            if (has(w, "idle", "stand", "breath")) {
                s.put(one, crouch ? (aim ? R_IDLE_CAIM : R_IDLE_C) : (aim ? R_IDLE_AIM : R_IDLE), c, rk);
                continue;
            }
            if (has(w, "reload")) { s.put(one, R_RELOAD, c, rk); continue; }
            if (has(w, "grenade", "toss", "throw")) { s.put(one, R_GREN, c, rk); continue; }
            if (has(w, "hit", "react", "flinch", "damage")) { s.put(one, R_HIT, c, rk); continue; }
            if (has(w, "fire", "firing", "shoot")) { s.put(one, R_FIRE, c, rk); continue; }
            if (has(w, "jump")) {
                int slot = has(w, "up", "start", "begin") ? R_JUP : has(w, "down", "land", "end") ? R_JDOWN : has(w, "loop", "air", "fall") ? R_JLOOP : R_JANY;
                s.put(one, slot, c, rk);
                continue;
            }
            boolean sprint = has(w, "sprint"), run = has(w, "run", "jog"), walk = has(w, "walk"), strafe = has(w, "strafe");
            if (!sprint && !run && !walk && !strafe) continue;
            boolean back = has(w, "back"), left = has(w, "left"), right = has(w, "right");
            if (strafe && !left && !right) continue;                                    // «strafe» без стороны: неизвестно, куда
            if (left && right) continue;
            int dir = back ? (left ? D_BL : right ? D_BR : D_B) : (left ? (has(w, "forward") ? D_FL : D_L) : right ? (has(w, "forward") ? D_FR : D_R) : D_F);
            int gait = crouch ? G_CWALK : sprint ? G_SPRINT : (run || strafe) ? G_RUN : G_WALK;
            if (crouch && !walk && !run) continue;
            s.put(s.loco[gait], dir, c, rk);
        }
        s.idle = one[R_IDLE]; s.idleAim = one[R_IDLE_AIM]; s.idleCrouch = one[R_IDLE_C]; s.idleCrouchAim = one[R_IDLE_CAIM];
        s.fire = one[R_FIRE]; s.reload = one[R_RELOAD]; s.hit = one[R_HIT]; s.grenade = one[R_GREN];
        s.jumpUp = one[R_JUP]; s.jumpLoop = one[R_JLOOP]; s.jumpDown = one[R_JDOWN]; s.jumpAny = one[R_JANY];
        if (s.jumpLoop == null) s.jumpLoop = s.jumpAny;
        if (!s.deaths.isEmpty()) s.death = s.deaths.get(0);
        s.fixMove();
        return s;
    }

    /**
     * Выбирает клип смерти.
     * (fx, fz) - куда смотрел боец, (hx, hz) - куда летела пуля (0,0 = неизвестно), head - убит выстрелом в голову.
     * Пуля навстречу взгляду -> падение назад (FRONT), по взгляду -> вперёд (BACK), сбоку -> SIDE.
     * Подходящие по направлению и клипы без меток смешиваются, из них берётся случайный.
     */
    public static GlbModel.Clip pickDeath(Set s, float fx, float fz, float hx, float hz, boolean head, boolean crouch, Random rnd) {
        if (s == null || s.deaths.isEmpty()) return null;
        // у присевшего берём клипы «crouching» (если они есть), у стоящего - обычные
        List<GlbModel.Clip> all = new ArrayList<>();
        for (GlbModel.Clip c : s.deaths) if (((s.tag(c) & T_CROUCH) != 0) == crouch) all.add(c);
        if (all.isEmpty()) all.addAll(s.deaths);
        return pickDeathFrom(s, all, fx, fz, hx, hz, head, rnd);
    }

    private static GlbModel.Clip pickDeathFrom(Set s, List<GlbModel.Clip> deaths, float fx, float fz, float hx, float hz, boolean head, Random rnd) {
        int want = 0;
        double hl = Math.hypot(hx, hz);
        if (hl > 1e-3) {
            double dot = (hx * fx + hz * fz) / (hl * Math.max(1e-6, Math.hypot(fx, fz)));
            want = dot <= -0.5 ? T_FRONT : (dot >= 0.5 ? T_BACK : T_SIDE);
        }
        final int dirBits = T_FRONT | T_BACK | T_SIDE;
        List<GlbModel.Clip> pool = new ArrayList<>();
        if (head) {
            for (GlbModel.Clip c : deaths) {
                int t = s.tag(c);
                if ((t & T_HEAD) != 0 && ((t & dirBits) == 0 || want == 0 || (t & want) != 0)) pool.add(c);
            }
            if (pool.isEmpty()) for (GlbModel.Clip c : deaths) if ((s.tag(c) & T_HEAD) != 0) pool.add(c);
        }
        if (pool.isEmpty()) {
            for (GlbModel.Clip c : deaths) {
                int t = s.tag(c);
                if ((t & T_HEAD) != 0) continue;
                if (want == 0 || (t & dirBits) == 0 || (t & want) != 0) pool.add(c);
            }
        }
        if (pool.isEmpty()) for (GlbModel.Clip c : deaths) if ((s.tag(c) & T_HEAD) == 0) pool.add(c);
        if (pool.isEmpty()) pool.addAll(deaths);
        return pool.get(rnd.nextInt(pool.size()));
    }
}
