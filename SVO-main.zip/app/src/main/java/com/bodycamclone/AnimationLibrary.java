package com.bodycamclone;

import android.content.Context;
import android.content.res.AssetManager;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/** Finds loose animation files copied by the GitHub Actions workflow into assets/user_files and loads their clips. */
public final class AnimationLibrary {
    private static final String ROOT = "user_files";
    private AnimationLibrary() {}

    /** Результат загрузки: клипы + счётчики для строки статуса в игре. */
    public static final class Result {
        public final List<GlbModel.Clip> clips = new ArrayList<>();
        public int glbFiles, fbxFiles, badFiles;
    }

    /** Метки клипа смерти, выведенные из имени файла (см. tagOf). */
    public static final int T_FRONT = 1, T_BACK = 2, T_SIDE = 4, T_HEAD = 8;

    /**
     * Клипы, выбранные для состояний бойца. null = для состояния нет подходящего клипа (остаётся старая процедурная анимация).
     * Клипов смерти может быть много: при гибели бойца выбирается подходящий по направлению выстрела (pickDeath).
     */
    public static final class Set {
        public GlbModel.Clip idle, move;
        /** Первый клип смерти (для совместимости) и полный список. */
        public GlbModel.Clip death;
        public final List<GlbModel.Clip> deaths = new ArrayList<>();
        final Map<GlbModel.Clip, Integer> tags = new IdentityHashMap<>();
        public boolean any() { return idle != null || move != null || !deaths.isEmpty(); }
        public int tag(GlbModel.Clip c) { Integer t = tags.get(c); return t == null ? 0 : t; }
        /** Убирает клип смерти (например, не подошёл к скелету). */
        public void removeDeath(GlbModel.Clip c) {
            deaths.remove(c); tags.remove(c);
            death = deaths.isEmpty() ? null : deaths.get(0);
        }
    }

    /** Returns FBX/GLB animation asset paths, including files in nested folders. */
    public static List<String> find(Context context) throws IOException {
        List<String> result = new ArrayList<>();
        scan(context.getAssets(), ROOT, result);
        Collections.sort(result, String.CASE_INSENSITIVE_ORDER);
        return result;
    }

    private static void scan(AssetManager assets, String path, List<String> out) throws IOException {
        String[] entries = assets.list(path);
        if (entries == null || entries.length == 0) return;
        for (String entry : entries) {
            String child = path + "/" + entry;
            String[] nested = assets.list(child);
            if (nested != null && nested.length > 0) {
                scan(assets, child, out);
            } else {
                String lower = entry.toLowerCase(Locale.ROOT);
                if (lower.endsWith(".fbx") || lower.endsWith(".glb")) out.add(child);
            }
        }
    }

    /** Читает клипы из всех .glb в user_files. .fbx только считаются: игра их пока не умеет читать. */
    public static Result loadClips(Context context) {
        Result r = new Result();
        List<String> files;
        try { files = find(context); } catch (IOException e) { return r; }
        for (String path : files) {
            String lower = path.toLowerCase(Locale.ROOT);
            if (lower.endsWith(".fbx")) { r.fbxFiles++; continue; }
            r.glbFiles++;
            try (InputStream in = context.getAssets().open(path)) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 20);
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                List<GlbModel.Clip> cl = GlbModel.readClips(bo.toByteArray());
                String base = path.substring(path.lastIndexOf('/') + 1);
                if (base.contains(".")) base = base.substring(0, base.lastIndexOf('.'));
                // Mixamo и многие экспортёры называют клип «mixamo.com»/«Take 001», поэтому имя файла важнее
                for (GlbModel.Clip c : cl) { c.name = base + " " + c.name; r.clips.add(c); }
                if (cl.isEmpty()) r.badFiles++;
            } catch (Throwable e) {
                r.badFiles++;
            }
        }
        return r;
    }

    /** Слова имени (латиница/кириллица), всё остальное - разделители: «Standing_React Death-Forward.glb» -> [standing, react, death, forward, glb]. */
    private static List<String> words(String name) {
        List<String> w = new ArrayList<>();
        for (String t : name.toLowerCase(Locale.ROOT).split("[^a-zа-я]+")) if (!t.isEmpty()) w.add(t);
        return w;
    }

    /** Клип смерти? Ищем целые слова (а не кусочки: в «soldier» есть «die»). */
    static boolean isDeath(String name) {
        for (String t : words(name)) {
            if (t.startsWith("death") || t.startsWith("dying") || t.startsWith("dead") || t.startsWith("kill")
                    || t.equals("die") || t.equals("dies") || t.equals("died")) return true;
        }
        return false;
    }

    /**
     * Метки по имени. FRONT - стреляли спереди, боец падает назад («Death From Front», «Backward», «Falling Back»);
     * BACK - стреляли сзади, падает вперёд («Death From Back», «Forward», «Behind»); SIDE - «Left»/«Right»; HEAD - «Headshot».
     */
    static int tagOf(String name) {
        StringBuilder sb = new StringBuilder(" ");
        for (String t : words(name)) sb.append(t).append(' ');
        String n = sb.toString();
        boolean back = n.contains("backward") || n.contains("front") || n.contains("falling back") || n.contains("fall back");
        boolean fwd = n.contains("forward") || n.contains("behind") || n.contains("faceplant") || (n.contains(" back ") && !back);
        int t = 0;
        if (back && !fwd) t |= T_FRONT;
        if (fwd && !back) t |= T_BACK;
        if (n.contains(" left ") || n.contains(" right ")) t |= T_SIDE;
        if (n.contains("headshot") || n.contains(" head ")) t |= T_HEAD;
        return t;
    }

    /** Подбирает клипы по словам в имени файла/клипа: idle/stand, run/walk, death/die (клипов смерти может быть несколько). */
    public static Set classify(List<GlbModel.Clip> clips) {
        Set s = new Set();
        for (GlbModel.Clip c : clips) {
            if (isDeath(c.name)) { s.deaths.add(c); s.tags.put(c, tagOf(c.name)); continue; }
            String n = c.name.toLowerCase(Locale.ROOT);
            if (s.idle == null && (n.contains("idle") || n.contains("stand") || n.contains("breath"))) s.idle = c;
        }
        if (!s.deaths.isEmpty()) s.death = s.deaths.get(0);
        for (GlbModel.Clip c : clips) { // бег предпочтительнее ходьбы: бойцы двигаются со скоростью ~2.7 м/с
            String n = c.name.toLowerCase(Locale.ROOT);
            if (c == s.idle || s.deaths.contains(c)) continue;
            if (n.contains("run") || n.contains("jog") || n.contains("sprint")) { s.move = c; break; }
        }
        if (s.move == null) for (GlbModel.Clip c : clips) {
            String n = c.name.toLowerCase(Locale.ROOT);
            if (c == s.idle || s.deaths.contains(c)) continue;
            if (n.contains("walk") || n.contains("move")) { s.move = c; break; }
        }
        return s;
    }

    /**
     * Выбирает клип смерти.
     * (fx, fz) - куда смотрел боец, (hx, hz) - куда летела пуля (0,0 = неизвестно), head - убит выстрелом в голову.
     * Пуля навстречу взгляду -> падение назад (FRONT), по взгляду -> вперёд (BACK), сбоку -> SIDE.
     * Подходящие по направлению и клипы без меток смешиваются, из них берётся случайный.
     */
    public static GlbModel.Clip pickDeath(Set s, float fx, float fz, float hx, float hz, boolean head, Random rnd) {
        if (s == null || s.deaths.isEmpty()) return null;
        int want = 0;
        double hl = Math.hypot(hx, hz);
        if (hl > 1e-3) {
            double dot = (hx * fx + hz * fz) / (hl * Math.max(1e-6, Math.hypot(fx, fz)));
            want = dot <= -0.5 ? T_FRONT : (dot >= 0.5 ? T_BACK : T_SIDE);
        }
        final int dirBits = T_FRONT | T_BACK | T_SIDE;
        List<GlbModel.Clip> pool = new ArrayList<>();
        if (head) {
            for (GlbModel.Clip c : s.deaths) {
                int t = s.tag(c);
                if ((t & T_HEAD) != 0 && ((t & dirBits) == 0 || want == 0 || (t & want) != 0)) pool.add(c);
            }
            if (pool.isEmpty()) for (GlbModel.Clip c : s.deaths) if ((s.tag(c) & T_HEAD) != 0) pool.add(c);
        }
        if (pool.isEmpty()) {
            for (GlbModel.Clip c : s.deaths) {
                int t = s.tag(c);
                if ((t & T_HEAD) != 0) continue;
                if (want == 0 || (t & dirBits) == 0 || (t & want) != 0) pool.add(c);
            }
        }
        if (pool.isEmpty()) for (GlbModel.Clip c : s.deaths) if ((s.tag(c) & T_HEAD) == 0) pool.add(c);
        if (pool.isEmpty()) pool.addAll(s.deaths);
        return pool.get(rnd.nextInt(pool.size()));
    }
}
