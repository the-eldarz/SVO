package com.bodycamclone;

import android.content.Context;
import android.content.res.AssetManager;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Finds loose animation files copied by the GitHub Actions workflow into assets/user_files and loads their clips. */
public final class AnimationLibrary {
    private static final String ROOT = "user_files";
    private AnimationLibrary() {}

    /** Результат загрузки: клипы + счётчики для строки статуса в игре. */
    public static final class Result {
        public final List<GlbModel.Clip> clips = new ArrayList<>();
        public int glbFiles, fbxFiles, badFiles;
    }

    /** Клипы, выбранные для состояний бойца. null = для состояния нет подходящего клипа (остаётся старая процедурная анимация). */
    public static final class Set {
        public GlbModel.Clip idle, move, death;
        public boolean any() { return idle != null || move != null || death != null; }
    }

    /** Returns FBX/GLB animation asset paths, including files in nested folders. */
    public static List<String> find(Context context) throws IOException {
        List<String> result = new ArrayList<>();
        scan(context.getAssets(), ROOT, result);
        Collections.sort(result, String.CASE_INSENSITIVE_ORDER);
        return result;
    }

    private static void scan(AssetManager assets, String path, List<String> out) throws IOException {
        String[] entries = assets.list(path);
        if (entries == null || entries.length == 0) return;
        for (String entry : entries) {
            String child = path + "/" + entry;
            String[] nested = assets.list(child);
            if (nested != null && nested.length > 0) {
                scan(assets, child, out);
            } else {
                String lower = entry.toLowerCase(Locale.ROOT);
                if (lower.endsWith(".fbx") || lower.endsWith(".glb")) out.add(child);
            }
        }
    }

    /** Читает клипы из всех .glb в user_files. .fbx только считаются: игра их пока не умеет читать. */
    public static Result loadClips(Context context) {
        Result r = new Result();
        List<String> files;
        try { files = find(context); } catch (IOException e) { return r; }
        for (String path : files) {
            String lower = path.toLowerCase(Locale.ROOT);
            if (lower.endsWith(".fbx")) { r.fbxFiles++; continue; }
            r.glbFiles++;
            try (InputStream in = context.getAssets().open(path)) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 20);
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                List<GlbModel.Clip> cl = GlbModel.readClips(bo.toByteArray());
                String base = path.substring(path.lastIndexOf('/') + 1);
                if (base.contains(".")) base = base.substring(0, base.lastIndexOf('.'));
                // Mixamo и многие экспортёры называют клип «mixamo.com»/«Take 001», поэтому имя файла важнее
                for (GlbModel.Clip c : cl) { c.name = base + " " + c.name; r.clips.add(c); }
                if (cl.isEmpty()) r.badFiles++;
            } catch (Throwable e) {
                r.badFiles++;
            }
        }
        return r;
    }

    /** Подбирает клипы по словам в имени файла/клипа: idle/stand, run/walk, death/die. */
    public static Set classify(List<GlbModel.Clip> clips) {
        Set s = new Set();
        for (GlbModel.Clip c : clips) {
            String n = c.name.toLowerCase(Locale.ROOT);
            if (s.death == null && (n.contains("death") || n.contains("dying") || n.contains("dead") || n.contains("die") || n.contains("kill"))) s.death = c;
            else if (s.idle == null && (n.contains("idle") || n.contains("stand") || n.contains("breath"))) s.idle = c;
        }
        for (GlbModel.Clip c : clips) { // бег предпочтительнее ходьбы: бойцы двигаются со скоростью ~2.7 м/с
            String n = c.name.toLowerCase(Locale.ROOT);
            if (c == s.death || c == s.idle) continue;
            if (n.contains("run") || n.contains("jog") || n.contains("sprint")) { s.move = c; break; }
        }
        if (s.move == null) for (GlbModel.Clip c : clips) {
            String n = c.name.toLowerCase(Locale.ROOT);
            if (c == s.death || c == s.idle) continue;
            if (n.contains("walk") || n.contains("move")) { s.move = c; break; }
        }
        return s;
    }
}
