package com.bodycamclone;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/** Рисование кнопок управления в стиле Standoff 2 и перекрестия. Используется и в игре, и в редакторе раскладки. */
final class ControlsUi {
    private ControlsUi() {}

    private static final int ICON = 0xE6C9CCD6, BASE = 0x99303440, BASE_ON = 0xCC4C5678, BASE_PRESS = 0xCC5A6288;
    private static final int RED = 0xFFEE3A4C, RED_FILL = 0x88A02A38, RED_PRESS = 0xBBC8384A, BULLET = 0xFFC8404E;
    private static final Path path = new Path();
    private static final RectF rf = new RectF();

    static int mulA(int col, float m) {
        int a = Math.max(0, Math.min(255, Math.round(Color.alpha(col) * m)));
        return (col & 0x00FFFFFF) | (a << 24);
    }

    /**
     * Рисует кнопку i с центром в (cx, cy). pl может быть null (редактор) - тогда показываются примерные цифры.
     * fade: 1 - обычная, меньше - приглушённая (например кнопка выключена режимом стрельбы).
     */
    static void drawButton(Canvas c, Paint p, int i, float cx, float cy, float d, boolean active, boolean pressed, float fade, Game.Player pl) {
        float hw = Settings.hw(i, d), hh = Settings.hh(i, d);
        float r = hw;
        p.setStyle(Paint.Style.FILL);
        switch (i) {
            case Settings.B_FIRE: {
                p.setColor(mulA(pressed ? RED_PRESS : RED_FILL, fade)); c.drawCircle(cx, cy, r, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.6f * d); p.setColor(mulA(RED, fade)); c.drawCircle(cx, cy, r - 1.3f * d, p);
                // «прицельное» кольцо с разрывами и пуля по диагонали
                p.setStrokeWidth(1.8f * d); p.setColor(mulA(0xAAD05060, fade));
                c.drawCircle(cx, cy, r * 0.6f, p);
                for (int k = 0; k < 4; k++) {
                    double a = k * Math.PI / 2;
                    float ux = (float) Math.cos(a), uy = (float) Math.sin(a);
                    c.drawLine(cx + ux * r * 0.38f, cy + uy * r * 0.38f, cx + ux * r * 0.82f, cy + uy * r * 0.82f, p);
                }
                bullet(c, p, cx, cy, r * 1.0f, r * 0.30f, 30f, mulA(BULLET, fade));
                break;
            }
            case Settings.B_FIRE2: {
                p.setColor(mulA(pressed ? RED_PRESS : RED_FILL, fade)); c.drawCircle(cx, cy, r, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.4f * d); p.setColor(mulA(RED, fade)); c.drawCircle(cx, cy, r - 1.2f * d, p);
                bullet(c, p, cx, cy, r * 1.15f, r * 0.34f, 30f, mulA(BULLET, fade));
                break;
            }
            case Settings.B_WEAPON: {
                rf.set(cx - hw, cy - hh, cx + hw, cy + hh);
                p.setColor(mulA(pressed ? BASE_PRESS : BASE, fade));
                c.drawRoundRect(rf, 7 * d, 7 * d, p);
                p.setColor(mulA(0x66FFFFFF, fade));
                c.drawRect(cx + hw - 3 * d, cy - hh + 5 * d, cx + hw - 1 * d, cy + hh - 5 * d, p);   // тонкая «полоска» справа
                int w = pl == null ? 0 : pl.weapon;
                p.setColor(mulA(ICON, fade));
                if (w == 0) rifle(c, p, cx, cy, hw * 0.70f); else pistol(c, p, cx, cy, hw * 0.50f);
                if (pl != null && pl.reloadT > 0f) {            // полоска перезарядки внизу кнопки
                    float prog = 1f - pl.reloadT / Game.W_RELOAD_PUBLIC()[pl.weapon];
                    p.setColor(mulA(0xFFEE3A4C, fade));
                    c.drawRect(cx - hw + 6 * d, cy + hh - 5 * d, cx - hw + 6 * d + (2 * hw - 12 * d) * Math.max(0f, Math.min(1f, prog)), cy + hh - 2.5f * d, p);
                }
                // патроны под кнопкой: «12 ||| 36»
                int cur = pl == null ? 30 : pl.ammo[pl.weapon], res = pl == null ? 90 : pl.reserve[pl.weapon];
                float ty = cy + hh + 21f * d * Math.max(0.8f, Settings.sc[i]);
                p.setTextAlign(Paint.Align.RIGHT); p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                p.setTextSize(24f * d * Math.max(0.8f, Settings.sc[i]));
                p.setColor(mulA(cur == 0 ? 0xFFEE3A4C : 0xFFFFFFFF, fade));
                c.drawText(String.valueOf(cur), cx - 6 * d, ty, p);
                p.setColor(mulA(ICON, fade));
                for (int k = 0; k < 3; k++) c.drawRect(cx + (-1 + k * 4) * d, ty - 11 * d, cx + (1 + k * 4) * d, ty, p);
                p.setTextAlign(Paint.Align.LEFT);
                p.setTextSize(18f * d * Math.max(0.8f, Settings.sc[i]));
                p.setColor(mulA(0x99C9CCD6, fade));
                c.drawText(String.valueOf(res), cx + 14 * d, ty, p);
                p.setTypeface(android.graphics.Typeface.DEFAULT);
                return;
            }
            case Settings.B_AIM: {
                p.setColor(mulA(active ? BASE_ON : (pressed ? BASE_PRESS : BASE), fade)); c.drawCircle(cx, cy, r, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.4f * d); p.setColor(mulA(ICON, fade));
                c.drawCircle(cx, cy, r * 0.58f, p);
                for (int k = 0; k < 4; k++) {
                    double a = k * Math.PI / 2;
                    float ux = (float) Math.cos(a), uy = (float) Math.sin(a);
                    c.drawLine(cx + ux * r * 0.40f, cy + uy * r * 0.40f, cx + ux * r * 0.88f, cy + uy * r * 0.88f, p);
                }
                break;
            }
            case Settings.B_ZOOM: {
                p.setColor(mulA(active ? BASE_ON : (pressed ? BASE_PRESS : BASE), fade)); c.drawCircle(cx, cy, r, p);
                p.setColor(mulA(ICON, fade)); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                int z = pl == null ? 0 : pl.zoom;
                p.setTextSize(r * 0.78f);
                c.drawText("x" + (int) Config.ZOOM_STEPS[z], cx, cy + r * 0.27f, p);
                p.setTypeface(android.graphics.Typeface.DEFAULT); p.setTextAlign(Paint.Align.LEFT);
                return;
            }
            case Settings.B_CROUCH: {
                p.setColor(mulA(active ? BASE_ON : (pressed ? BASE_PRESS : BASE), fade)); c.drawCircle(cx, cy, r, p);
                figureCrouch(c, p, cx, cy, r, mulA(ICON, fade));
                return;
            }
            case Settings.B_PRONE: {
                p.setColor(mulA(active ? BASE_ON : (pressed ? BASE_PRESS : BASE), fade)); c.drawCircle(cx, cy, r, p);
                figureProne(c, p, cx, cy, r, mulA(ICON, fade));
                return;
            }
        }
        p.setStyle(Paint.Style.FILL);
    }

    // ---------- значки ----------

    private static void bullet(Canvas c, Paint p, float cx, float cy, float len, float w, float angle, int col) {
        c.save();
        c.translate(cx, cy);
        c.rotate(angle);
        p.setStyle(Paint.Style.FILL); p.setColor(col);
        path.reset();
        path.moveTo(-w / 2, len / 2);
        path.lineTo(-w / 2, -len * 0.10f);
        path.quadTo(-w / 2, -len * 0.34f, 0, -len / 2);
        path.quadTo(w / 2, -len * 0.34f, w / 2, -len * 0.10f);
        path.lineTo(w / 2, len / 2);
        path.close();
        c.drawPath(path, p);
        p.setColor(mulA(0xFFFFFFFF, 0.28f * Color.alpha(col) / 255f));
        c.drawRect(-w / 2, len * 0.30f, w / 2, len * 0.34f, p);   // проточка гильзы
        c.restore();
    }

    private static void poly(Canvas c, Paint p, float ox, float oy, float sx, float sy, float... pts) {
        path.reset();
        for (int k = 0; k < pts.length; k += 2) {
            float x = ox + pts[k] * sx, y = oy + pts[k + 1] * sy;
            if (k == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        path.close();
        c.drawPath(path, p);
    }

    /** Силуэт автомата (дуло слева). s - половина длины. Цвет берётся из p. */
    private static void rifle(Canvas c, Paint p, float cx, float cy, float s) {
        p.setStyle(Paint.Style.FILL);
        float oy = cy - 0.12f * s;
        poly(c, p, cx, oy, s, s, -1.0f, -0.10f, -0.55f, -0.10f, -0.55f, -0.03f, -1.0f, -0.03f);
        poly(c, p, cx, oy, s, s, -0.98f, -0.16f, -0.90f, -0.16f, -0.90f, -0.10f, -0.98f, -0.10f);
        poly(c, p, cx, oy, s, s, -0.62f, -0.15f, -0.20f, -0.15f, -0.20f, 0.04f, -0.62f, 0.04f);
        poly(c, p, cx, oy, s, s, -0.55f, -0.19f, -0.20f, -0.19f, -0.20f, -0.15f, -0.55f, -0.15f);
        poly(c, p, cx, oy, s, s, -0.20f, -0.19f, 0.32f, -0.19f, 0.32f, 0.05f, -0.20f, 0.05f);
        poly(c, p, cx, oy, s, s, 0.32f, -0.15f, 0.95f, -0.05f, 1.0f, 0.16f, 0.32f, 0.03f);
        poly(c, p, cx, oy, s, s, -0.12f, 0.05f, 0.10f, 0.05f, 0.02f, 0.44f, -0.20f, 0.34f);
        poly(c, p, cx, oy, s, s, 0.20f, 0.05f, 0.32f, 0.05f, 0.36f, 0.30f, 0.26f, 0.30f);
    }

    /** Силуэт пистолета с глушителем (дуло слева). */
    private static void pistol(Canvas c, Paint p, float cx, float cy, float s) {
        p.setStyle(Paint.Style.FILL);
        float oy = cy - 0.08f * s;
        poly(c, p, cx, oy, s, s, -1.0f, -0.26f, -0.50f, -0.26f, -0.50f, -0.08f, -1.0f, -0.08f);
        poly(c, p, cx, oy, s, s, -0.50f, -0.30f, 0.70f, -0.30f, 0.70f, -0.02f, -0.50f, -0.02f);
        poly(c, p, cx, oy, s, s, 0.05f, -0.02f, 0.70f, -0.02f, 0.78f, 0.46f, 0.40f, 0.46f);
        poly(c, p, cx, oy, s, s, -0.15f, -0.02f, 0.05f, -0.02f, 0.05f, 0.20f, -0.10f, 0.20f, -0.20f, 0.08f);
    }

    private static void figureCrouch(Canvas c, Paint p, float cx, float cy, float r, int col) {
        p.setColor(col); p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx + 0.08f * r, cy - 0.52f * r, 0.13f * r, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(r * 0.17f);
        c.drawLine(cx + 0.06f * r, cy - 0.34f * r, cx - 0.08f * r, cy + 0.04f * r, p);        // торс
        c.drawLine(cx - 0.08f * r, cy + 0.04f * r, cx + 0.30f * r, cy + 0.06f * r, p);        // бедро
        c.drawLine(cx + 0.30f * r, cy + 0.06f * r, cx + 0.30f * r, cy + 0.50f * r, p);        // голень
        c.drawLine(cx - 0.08f * r, cy + 0.04f * r, cx - 0.36f * r, cy + 0.50f * r, p);        // задняя нога
        c.drawLine(cx + 0.04f * r, cy - 0.24f * r, cx + 0.46f * r, cy - 0.18f * r, p);        // руки с оружием
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private static void figureProne(Canvas c, Paint p, float cx, float cy, float r, int col) {
        p.setColor(col); p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx + 0.42f * r, cy - 0.02f * r, 0.13f * r, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(r * 0.17f);
        c.drawLine(cx + 0.28f * r, cy + 0.06f * r, cx - 0.30f * r, cy + 0.14f * r, p);        // торс
        c.drawLine(cx - 0.30f * r, cy + 0.14f * r, cx - 0.62f * r, cy + 0.20f * r, p);        // ноги
        c.drawLine(cx + 0.24f * r, cy + 0.10f * r, cx + 0.66f * r, cy + 0.16f * r, p);        // руки с оружием
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    // ---------- перекрестие ----------

    /** Рисует перекрестие k (0 - от бедра, 1 - в прицеле) с центром в (cx, cy). */
    static void drawCrosshair(Canvas c, Paint p, float cx, float cy, float d, int k) {
        drawCrosshair(c, p, cx, cy, d, Settings.chStyle[k], Settings.CH_COLORS[Settings.chColor[k]],
                Settings.chSize[k], Settings.chThick[k], Settings.chGap[k]);
    }

    static void drawCrosshair(Canvas c, Paint p, float cx, float cy, float d, int style, int color, float size, float thick, float gap) {
        float s = size * d, t = thick * d, g = gap * d;
        p.setColor(color);
        switch (style) {
            case 0:    // точка
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy, Math.max(t, s / 2f), p);
                break;
            case 1:    // круг
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(t);
                c.drawCircle(cx, cy, s, p);
                break;
            case 3:    // крест + точка
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy, Math.max(t * 0.8f, 1.2f * d), p);
                // fallthrough
            case 2:    // крест
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(t);
                c.drawLine(cx - g - s, cy, cx - g, cy, p);
                c.drawLine(cx + g, cy, cx + g + s, cy, p);
                c.drawLine(cx, cy - g - s, cx, cy - g, p);
                c.drawLine(cx, cy + g, cx, cy + g + s, p);
                break;
            default:   // квадрат
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(t);
                c.drawRect(cx - s / 2f, cy - s / 2f, cx + s / 2f, cy + s / 2f, p);
                break;
        }
        p.setStyle(Paint.Style.FILL);
    }
}
