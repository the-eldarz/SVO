package com.bodycamclone;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES30;
import android.opengl.GLUtils;
import android.opengl.Matrix;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Загрузчик .glb: меши, материалы (цвет + текстура), скелет (skin), анимационные клипы glTF и расчёт матриц костей. */
public class GlbModel {
    public static class Prim {
        public float[] data;   // pos(3) normal(3) uv(2)
        public int[] idx;
        public float[] color = {1f, 1f, 1f, 1f};
        public Bitmap bmp;
        /** joints(4) + weights(4) на вершину; null = статичный меш без скиннинга. */
        public float[] skinData;
        public int vao, vbo, ibo, skinVbo, tex, count;

        public void uploadGeometry() {
            int[] b = new int[1];
            GLES30.glGenVertexArrays(1, b, 0); vao = b[0];
            GLES30.glBindVertexArray(vao);
            GLES30.glGenBuffers(1, b, 0); vbo = b[0];
            FloatBuffer fb = ByteBuffer.allocateDirect(data.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
            fb.put(data); fb.position(0);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo);
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, data.length * 4, fb, GLES30.GL_STATIC_DRAW);
            GLES30.glGenBuffers(1, b, 0); ibo = b[0];
            IntBuffer ib = ByteBuffer.allocateDirect(idx.length * 4).order(ByteOrder.nativeOrder()).asIntBuffer();
            ib.put(idx); ib.position(0);
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo);
            GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, idx.length * 4, ib, GLES30.GL_STATIC_DRAW);
            GLES30.glEnableVertexAttribArray(0);
            GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, 0);
            GLES30.glEnableVertexAttribArray(1);
            GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, 12);
            GLES30.glEnableVertexAttribArray(2);
            GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, 32, 24);
            if (skinData != null) {
                GLES30.glGenBuffers(1, b, 0); skinVbo = b[0];
                FloatBuffer sb = ByteBuffer.allocateDirect(skinData.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
                sb.put(skinData); sb.position(0);
                GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, skinVbo);
                GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, skinData.length * 4, sb, GLES30.GL_STATIC_DRAW);
                GLES30.glEnableVertexAttribArray(3);
                GLES30.glVertexAttribPointer(3, 4, GLES30.GL_FLOAT, false, 32, 0);
                GLES30.glEnableVertexAttribArray(4);
                GLES30.glVertexAttribPointer(4, 4, GLES30.GL_FLOAT, false, 32, 16);
            }
            GLES30.glBindVertexArray(0);
            count = idx.length;
        }

        public void draw() {
            GLES30.glBindVertexArray(vao);
            GLES30.glDrawElements(GLES30.GL_TRIANGLES, count, GLES30.GL_UNSIGNED_INT, 0);
        }
    }


    /** Один канал анимации (поворот или перемещение одного узла). Масштаб не используется. */
    static final class Chan {
        String key;          // нормализованное имя узла (для переноса анимации между файлами)
        int path;            // 0 = translation, 1 = rotation
        float[] times, vals;
        boolean step;
        float[] first;       // для translation: значение в первом кадре
        float refLen;        // длина first (высота бёдер в исходном файле)
        int vertAxis;        // ось «вверх» в локальных координатах корневой кости
    }

    /** Анимационный клип. Привязывается к костям по именам узлов, поэтому клип из другого .glb подходит, если скелет такой же. */
    public static final class Clip {
        public String name;
        public float duration;
        final List<Chan> chans = new ArrayList<>();
        final Map<GlbModel, int[]> maps = new IdentityHashMap<>();
    }

    public static final int MAX_BONES = 80;

    public final List<Prim> prims = new ArrayList<>();
    public final List<Clip> clips = new ArrayList<>();   // клипы, встроенные в сам файл модели
    public int triangles;
    /** Число костей скина (0 = у модели нет пригодного скелета, рисуется статично). */
    public int boneCount;
    /** Индексы костей кистей (RightHand / LeftHand) или -1: к ним привязывается оружие. */
    public int boneRHand = -1, boneLHand = -1;
    /** Почему скелет не подключился (для строки статуса). */
    public String skinInfo = "";
    /** Для skin №1, №2...: индекс кости в skin №0 по имени (если в файле несколько одинаковых скелетов). */
    private final java.util.Map<Integer, int[]> skinRemap = new java.util.HashMap<>();

    // --- скелет / узлы ---
    private String[] nodeName;
    private int[] nodeParent, jointOfNode, skinJoints, order;
    private float[] restT, restR, restS, ibm;
    private float[][] nodeMat;
    private final Map<String, Integer> nameIndex = new HashMap<>();
    private final List<Integer> sceneRoots = new ArrayList<>();
    private float[] pT, pR, qT, qR, world;
    private final float[] loc = new float[16], tmpA = new float[16], tmpB = new float[16], scratch = new float[4];
    private final float[] normM = new float[16], normInv = new float[16];
    /** Обратная к (поза покоя сустава * inverseBind): переводит единицы/оси экспортёра (у этой модели см, масштаб 0.01) к исходным вершинам меша. */
    private final float[] meshInv = new float[16];
    /** Кость, которая получает вертикальное смещение клипа: бёдра (Hips/Pelvis), иначе первая кость без родителя-кости. */
    private int rootMotionNode = -1;
    { Matrix.setIdentityM(meshInv, 0); }


    private ByteBuffer bb;
    private byte[] raw;
    private int binOff = -1;
    private JSONObject root;
    private JSONArray accessors, bufferViews, meshes, nodes, materials, textures, images;
    private final Map<Integer, Bitmap> bmpCache = new HashMap<>();

    public static GlbModel parse(byte[] bytes, float targetHeight) throws Exception {
        GlbModel m = new GlbModel();
        m.read(bytes, targetHeight);
        return m;
    }

    /** Вызывать в GL-потоке (повторно после потери контекста). */
    public void upload() {
        Map<Bitmap, Integer> texMap = new HashMap<>();
        for (Prim p : prims) {
            p.uploadGeometry();
            p.tex = 0;
            if (p.bmp != null) {
                Integer t = texMap.get(p.bmp);
                if (t == null) { t = makeTex(p.bmp); texMap.put(p.bmp, t); }
                p.tex = t;
            }
        }
    }

    public static int makeTex(Bitmap bmp) {
        int[] t = new int[1];
        GLES30.glGenTextures(1, t, 0);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t[0]);
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0);
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT);
        return t[0];
    }

    // ---------------- разбор ----------------
    private JSONArray arr(String n) { JSONArray a = root.optJSONArray(n); return a != null ? a : new JSONArray(); }

    /** Открывает контейнер: JSON, акцессоры, узлы, скин. Меши не трогает (нужно и для файлов «только анимация»). */
    private void open(byte[] bytes) throws Exception {
        raw = bytes;
        bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        if (bytes.length < 20 || bb.getInt(0) != 0x46546C67) throw new Exception("это не .glb файл");
        int total = Math.min(bb.getInt(8), bytes.length), pos = 12;
        String json = null;
        while (pos + 8 <= total) {
            int len = bb.getInt(pos), type = bb.getInt(pos + 4), start = pos + 8;
            if (type == 0x4E4F534A) json = new String(bytes, start, len, "UTF-8");
            else if (type == 0x004E4942 && binOff < 0) binOff = start;
            pos = start + ((len + 3) & ~3);
        }
        if (json == null) throw new Exception("в .glb нет JSON-части");
        root = new JSONObject(json);
        JSONArray req = root.optJSONArray("extensionsRequired");
        if (req != null) for (int i = 0; i < req.length(); i++) {
            String e = req.getString(i);
            if (e.contains("draco") || e.contains("meshopt"))
                throw new Exception("GLB сжат (" + e + "). Экспортируй без сжатия.");
        }
        accessors = arr("accessors"); bufferViews = arr("bufferViews"); meshes = arr("meshes");
        nodes = arr("nodes"); materials = arr("materials"); textures = arr("textures"); images = arr("images");

        JSONArray scenes = root.optJSONArray("scenes");
        if (scenes != null && scenes.length() > 0) {
            JSONObject sc = scenes.getJSONObject(Math.min(root.optInt("scene", 0), scenes.length() - 1));
            JSONArray ns = sc.optJSONArray("nodes");
            if (ns != null) for (int i = 0; i < ns.length(); i++) sceneRoots.add(ns.getInt(i));
        } else {
            boolean[] child = new boolean[nodes.length()];
            for (int i = 0; i < nodes.length(); i++) {
                JSONArray c = nodes.getJSONObject(i).optJSONArray("children");
                if (c != null) for (int j = 0; j < c.length(); j++) child[c.getInt(j)] = true;
            }
            for (int i = 0; i < child.length; i++) if (!child[i]) sceneRoots.add(i);
        }
        parseNodes();
        parseSkin();
    }

    private void read(byte[] bytes, float targetH) throws Exception {
        open(bytes);
        computeMeshInv();
        float[] id = new float[16];
        Matrix.setIdentityM(id, 0);
        for (int r : sceneRoots) visit(r, id, 0, -1);
        if (prims.isEmpty()) throw new Exception("в модели нет мешей");
        normalize(targetH);
        try { clips.addAll(parseClips()); } catch (Exception ignored) { /* клипы в самой модели необязательны */ }
    }

    /** Достаёт анимационные клипы из .glb (меши и текстуры не декодируются). */
    public static List<Clip> readClips(byte[] bytes) throws Exception {
        GlbModel m = new GlbModel();
        m.open(bytes);
        return m.parseClips();
    }

    // ---------------- узлы и скелет ----------------
    /** Имя кости без префиксов и числовых хвостов экспортёров: «mixamorig:Hips_01», «mixamorig_Hips», «Hips.001» -> «hips». */
    static String norm(String s) {
        if (s == null) return "";
        int c = Math.max(s.lastIndexOf(':'), s.lastIndexOf('|'));
        if (c >= 0) s = s.substring(c + 1);
        String prev;
        do { prev = s; s = s.replaceAll("[_.]\\d+$", ""); } while (!s.equals(prev)); // хвосты экспортёров: «Hips_01», «Hips.001», «Hips_01_56»
        String l = s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (l.startsWith("mixamorig") && l.length() > 9) l = l.substring(9);
        return l;
    }

    private void parseNodes() throws Exception {
        int n = nodes.length();
        nodeName = new String[n];
        nodeParent = new int[n];
        jointOfNode = new int[n];
        restT = new float[n * 3]; restR = new float[n * 4]; restS = new float[n * 3];
        nodeMat = new float[n][];
        for (int i = 0; i < n; i++) { nodeParent[i] = -1; jointOfNode[i] = -1; }
        for (int i = 0; i < n; i++) {
            JSONObject o = nodes.getJSONObject(i);
            nodeName[i] = o.optString("name", "node" + i);
            String key = norm(nodeName[i]);
            if (!nameIndex.containsKey(key)) nameIndex.put(key, i);
            JSONArray ch = o.optJSONArray("children");
            if (ch != null) for (int j = 0; j < ch.length(); j++) {
                int c = ch.getInt(j);
                if (c >= 0 && c < n) nodeParent[c] = i;
            }
            float[] t = {0, 0, 0}, r = {0, 0, 0, 1}, s = {1, 1, 1};
            if (o.has("matrix")) {
                JSONArray m = o.getJSONArray("matrix");
                nodeMat[i] = new float[16];
                for (int k = 0; k < 16; k++) nodeMat[i][k] = (float) m.getDouble(k);
            } else {
                fill(o.optJSONArray("translation"), t); fill(o.optJSONArray("rotation"), r); fill(o.optJSONArray("scale"), s);
            }
            System.arraycopy(t, 0, restT, i * 3, 3);
            System.arraycopy(r, 0, restR, i * 4, 4);
            System.arraycopy(s, 0, restS, i * 3, 3);
        }
        // порядок обхода: родитель всегда раньше потомка
        List<Integer> ord = new ArrayList<>();
        boolean[] seen = new boolean[n];
        List<Integer> stack = new ArrayList<>(sceneRoots);
        while (!stack.isEmpty()) {
            int ni = stack.remove(stack.size() - 1);
            if (ni < 0 || ni >= n || seen[ni]) continue;
            seen[ni] = true;
            ord.add(ni);
            JSONArray ch = nodes.getJSONObject(ni).optJSONArray("children");
            if (ch != null) for (int j = ch.length() - 1; j >= 0; j--) stack.add(ch.getInt(j));
        }
        order = new int[ord.size()];
        for (int i = 0; i < order.length; i++) order[i] = ord.get(i);
        pT = new float[n * 3]; pR = new float[n * 4]; qT = new float[n * 3]; qR = new float[n * 4];
        world = new float[n * 16];
    }

    private void parseSkin() throws Exception {
        JSONArray skins = root.optJSONArray("skins");
        if (skins == null || skins.length() == 0) { skinInfo = "в файле нет skins - модель экспортирована без арматуры"; return; }
        JSONObject sk = skins.getJSONObject(0);
        JSONArray js = sk.optJSONArray("joints");
        if (js == null || js.length() == 0) { skinInfo = "у skin пустой список костей"; return; }
        if (js.length() > MAX_BONES) { skinInfo = "костей " + js.length() + ", а максимум " + MAX_BONES; return; }
        int n = js.length();
        int[] sj = new int[n];
        float[] ib = new float[n * 16];
        for (int i = 0; i < n; i++) {
            sj[i] = js.getInt(i);
            Matrix.setIdentityM(ib, i * 16);
        }
        if (sk.has("inverseBindMatrices")) {
            float[] f = readAcc(sk.getInt("inverseBindMatrices"));
            System.arraycopy(f, 0, ib, 0, Math.min(f.length, ib.length));
        }
        for (int i = 0; i < n; i++) if (sj[i] >= 0 && sj[i] < jointOfNode.length) jointOfNode[sj[i]] = i;
        skinJoints = sj; ibm = ib; boneCount = n;
        for (int i = 0; i < n; i++) {
            String hk = norm(nodeName[sj[i]]);
            if (hk.equals("righthand") && boneRHand < 0) boneRHand = i;
            else if (hk.equals("lefthand") && boneLHand < 0) boneLHand = i;
        }
        java.util.Map<String, Integer> boneByName = new java.util.HashMap<>();
        for (int i = 0; i < n; i++) {
            String k0 = norm(nodeName[sj[i]]);
            if (!boneByName.containsKey(k0)) boneByName.put(k0, i);
        }
        for (int si = 1; si < skins.length(); si++) {
            JSONArray js2 = skins.getJSONObject(si).optJSONArray("joints");
            if (js2 == null) continue;
            int[] rm = new int[js2.length()];
            for (int i = 0; i < rm.length; i++) {
                int node = js2.getInt(i);
                Integer b = (node >= 0 && node < nodeName.length) ? boneByName.get(norm(nodeName[node])) : null;
                rm[i] = b != null ? b : 0;
            }
            skinRemap.put(si, rm);
        }
        for (int i = 0; i < n && rootMotionNode < 0; i++) {
            String k = norm(nodeName[sj[i]]);
            if (k.equals("hips") || k.equals("pelvis")) rootMotionNode = sj[i];
        }
        for (int i = 0; i < n && rootMotionNode < 0; i++) {
            int p = nodeParent[sj[i]];
            if (p < 0 || jointOfNode[p] < 0) rootMotionNode = sj[i];
        }
    }

    // ---------------- клипы ----------------
    private List<Clip> parseClips() throws Exception {
        List<Clip> out = new ArrayList<>();
        JSONArray an = root.optJSONArray("animations");
        if (an == null) return out;
        for (int i = 0; i < an.length(); i++) {
            JSONObject a = an.getJSONObject(i);
            JSONArray samplers = a.optJSONArray("samplers"), channels = a.optJSONArray("channels");
            if (samplers == null || channels == null) continue;
            Clip c = new Clip();
            c.name = a.optString("name", "clip" + i);
            for (int k = 0; k < channels.length(); k++) {
                JSONObject ch = channels.getJSONObject(k), tg = ch.getJSONObject("target");
                if (!tg.has("node")) continue;
                String path = tg.optString("path", "");
                int p = path.equals("translation") ? 0 : path.equals("rotation") ? 1 : -1;
                if (p < 0) continue; // масштаб и morph-targets не используем
                int node = tg.getInt("node");
                if (node < 0 || node >= nodeName.length) continue;
                JSONObject sm = samplers.getJSONObject(ch.getInt("sampler"));
                float[] times = readAcc(sm.getInt("input")), vals = readAcc(sm.getInt("output"));
                String interp = sm.optString("interpolation", "LINEAR");
                int comps = p == 1 ? 4 : 3;
                if (interp.equals("CUBICSPLINE")) {
                    if (vals.length < times.length * comps * 3) continue;
                    float[] v2 = new float[times.length * comps];
                    for (int j = 0; j < times.length; j++) System.arraycopy(vals, (j * 3 + 1) * comps, v2, j * comps, comps);
                    vals = v2;
                }
                if (times.length == 0 || vals.length < times.length * comps) continue;
                Chan x = new Chan();
                x.key = norm(nodeName[node]); x.path = p; x.times = times; x.vals = vals; x.step = interp.equals("STEP");
                if (p == 0) {
                    x.first = new float[]{vals[0], vals[1], vals[2]};
                    x.refLen = (float) Math.sqrt(vals[0] * vals[0] + vals[1] * vals[1] + vals[2] * vals[2]);
                    int ax = 0;
                    for (int j = 1; j < 3; j++) if (Math.abs(x.first[j]) > Math.abs(x.first[ax])) ax = j;
                    x.vertAxis = ax;
                }
                c.duration = Math.max(c.duration, times[times.length - 1]);
                c.chans.add(x);
            }
            if (!c.chans.isEmpty() && c.duration > 0f) out.add(c);
        }
        return out;
    }

    private int[] mapFor(Clip c) {
        int[] m = c.maps.get(this);
        if (m == null) {
            m = new int[c.chans.size()];
            for (int i = 0; i < m.length; i++) {
                Integer v = nameIndex.get(c.chans.get(i).key);
                m[i] = v == null ? -1 : v;
            }
            c.maps.put(this, m);
        }
        return m;
    }

    /** Сколько каналов клипа нашли свою кость в этой модели (0 = скелет не совпадает). */
    public int matchCount(Clip c) {
        if (boneCount == 0 || c == null) return 0;
        int[] m = mapFor(c);
        int cnt = 0;
        for (int ni : m) if (ni >= 0 && jointOfNode[ni] >= 0) cnt++;
        return cnt;
    }

    private final float[] jv = new float[4], jw = new float[4];

    /** Положение кости в координатах модели (как у вершин после normalize) в позе последнего вызова pose(). */
    public boolean jointPos(int bone, float[] out) {
        if (bone < 0 || bone >= boneCount) return false;
        int o = skinJoints[bone] * 16;
        jv[0] = world[o + 12]; jv[1] = world[o + 13]; jv[2] = world[o + 14]; jv[3] = 1f;
        Matrix.multiplyMV(jw, 0, meshInv, 0, jv, 0);
        Matrix.multiplyMV(jv, 0, normM, 0, jw, 0);
        out[0] = jv[0]; out[1] = jv[1]; out[2] = jv[2];
        return true;
    }

    private boolean isRootJoint(int ni) { return ni == rootMotionNode; }

    private static int findKey(float[] times, float t) {
        int hi = times.length - 1;
        if (t <= times[0]) return 0;
        if (t >= times[hi]) return hi;
        int lo = 0;
        while (hi - lo > 1) { int mid = (lo + hi) >> 1; if (times[mid] <= t) lo = mid; else hi = mid; }
        return lo;
    }

    /** Ставит позу клипа в массивы локальных T/R. Поворот берётся как есть; перемещение - только у корневой кости (по вертикали). */
    private void sampleInto(Clip c, float t, float[] T, float[] R) {
        int[] map = mapFor(c);
        for (int ci = 0; ci < map.length; ci++) {
            int ni = map[ci];
            if (ni < 0 || jointOfNode[ni] < 0) continue;
            Chan ch = c.chans.get(ci);
            int comps = ch.path == 1 ? 4 : 3;
            if (ch.path == 0 && !isRootJoint(ni)) continue;
            int i = findKey(ch.times, t);
            float f = 0f;
            if (!ch.step && i < ch.times.length - 1) {
                float dt = ch.times[i + 1] - ch.times[i];
                f = dt > 1e-6f ? Math.max(0f, Math.min(1f, (t - ch.times[i]) / dt)) : 0f;
            }
            int j = Math.min(i + 1, ch.times.length - 1);
            for (int k = 0; k < comps; k++) {
                float a = ch.vals[i * comps + k], b = ch.vals[j * comps + k];
                scratch[k] = a;
                if (f > 0f) {
                    if (ch.path == 1) {
                        float dot = ch.vals[i * 4] * ch.vals[j * 4] + ch.vals[i * 4 + 1] * ch.vals[j * 4 + 1]
                                + ch.vals[i * 4 + 2] * ch.vals[j * 4 + 2] + ch.vals[i * 4 + 3] * ch.vals[j * 4 + 3];
                        if (dot < 0f) b = -b;
                    }
                    scratch[k] = a + (b - a) * f;
                }
            }
            if (ch.path == 1) {
                float l = (float) Math.sqrt(scratch[0] * scratch[0] + scratch[1] * scratch[1] + scratch[2] * scratch[2] + scratch[3] * scratch[3]);
                if (l < 1e-8f) l = 1f;
                for (int k = 0; k < 4; k++) R[ni * 4 + k] = scratch[k] / l;
            } else {
                float rl = (float) Math.sqrt(restT[ni * 3] * restT[ni * 3] + restT[ni * 3 + 1] * restT[ni * 3 + 1] + restT[ni * 3 + 2] * restT[ni * 3 + 2]);
                float ratio = (ch.refLen > 1e-6f && rl > 1e-6f) ? Math.max(0.001f, Math.min(1000f, rl / ch.refLen)) : 1f;
                int ax = ch.vertAxis;
                // горизонтальное смещение бёдер убираем: по карте солдата двигает игра, а не анимация
                T[ni * 3 + ax] = restT[ni * 3 + ax] + (scratch[ax] - ch.first[ax]) * ratio;
            }
        }
    }

    private static void compose(float[] m, float tx, float ty, float tz, float qx, float qy, float qz, float qw, float sx, float sy, float sz) {
        float xx = qx * qx, yy = qy * qy, zz = qz * qz, xy = qx * qy, xz = qx * qz, yz = qy * qz, wx = qw * qx, wy = qw * qy, wz = qw * qz;
        m[0] = (1 - 2 * (yy + zz)) * sx; m[1] = 2 * (xy + wz) * sx; m[2] = 2 * (xz - wy) * sx; m[3] = 0;
        m[4] = 2 * (xy - wz) * sy; m[5] = (1 - 2 * (xx + zz)) * sy; m[6] = 2 * (yz + wx) * sy; m[7] = 0;
        m[8] = 2 * (xz + wy) * sz; m[9] = 2 * (yz - wx) * sz; m[10] = (1 - 2 * (xx + yy)) * sz; m[11] = 0;
        m[12] = tx; m[13] = ty; m[14] = tz; m[15] = 1;
    }

    /**
     * Считает матрицы костей для шейдера (boneCount * 16 float) в нормализованном пространстве модели.
     * a/ta - текущий клип и его время, b/tb - предыдущий (для плавного перехода), wA - вес текущего 0..1.
     * Вызывать только из GL-потока.
     */
    public void pose(Clip a, float ta, Clip b, float tb, float wA, float[] out) {
        if (boneCount == 0) return;
        System.arraycopy(restT, 0, pT, 0, pT.length);
        System.arraycopy(restR, 0, pR, 0, pR.length);
        if (a != null) sampleInto(a, ta, pT, pR);
        if (b != null && wA < 1f) {
            System.arraycopy(restT, 0, qT, 0, qT.length);
            System.arraycopy(restR, 0, qR, 0, qR.length);
            sampleInto(b, tb, qT, qR);
            float w = Math.max(0f, wA);
            for (int i = 0; i < pT.length; i++) pT[i] = qT[i] * (1f - w) + pT[i] * w;
            for (int i = 0; i + 3 < pR.length; i += 4) {
                float dot = qR[i] * pR[i] + qR[i + 1] * pR[i + 1] + qR[i + 2] * pR[i + 2] + qR[i + 3] * pR[i + 3];
                float sg = dot < 0f ? -1f : 1f, l = 0f;
                for (int k = 0; k < 4; k++) { pR[i + k] = qR[i + k] * sg * (1f - w) + pR[i + k] * w; l += pR[i + k] * pR[i + k]; }
                l = (float) Math.sqrt(l);
                if (l < 1e-8f) l = 1f;
                for (int k = 0; k < 4; k++) pR[i + k] /= l;
            }
        }
        buildWorld();
        for (int i = 0; i < boneCount; i++) {
            Matrix.multiplyMM(tmpA, 0, world, skinJoints[i] * 16, ibm, i * 16);
            Matrix.multiplyMM(tmpB, 0, meshInv, 0, tmpA, 0);
            Matrix.multiplyMM(tmpA, 0, normM, 0, tmpB, 0);
            Matrix.multiplyMM(out, i * 16, tmpA, 0, normInv, 0);
        }
    }

    /** Мировые матрицы всех узлов из локальных поз pT/pR (родитель всегда раньше потомка). */
    private void buildWorld() {
        for (int k = 0; k < order.length; k++) {
            int ni = order[k];
            if (nodeMat[ni] != null) System.arraycopy(nodeMat[ni], 0, loc, 0, 16);
            else compose(loc, pT[ni * 3], pT[ni * 3 + 1], pT[ni * 3 + 2],
                    pR[ni * 4], pR[ni * 4 + 1], pR[ni * 4 + 2], pR[ni * 4 + 3],
                    restS[ni * 3], restS[ni * 3 + 1], restS[ni * 3 + 2]);
            int p = nodeParent[ni];
            if (p < 0) System.arraycopy(loc, 0, world, ni * 16, 16);
            else Matrix.multiplyMM(world, ni * 16, world, p * 16, loc, 0);
        }
    }

    private void computeMeshInv() {
        if (boneCount == 0) return;
        System.arraycopy(restT, 0, pT, 0, pT.length);
        System.arraycopy(restR, 0, pR, 0, pR.length);
        buildWorld();
        // Опорная кость - бёдра, а не нулевая: у некоторых моделей (например, русской) служебный корень
        // GLTF_created_0_rootJoint имеет единичную IBM-матрицу при масштабе 0.01 в мировой, и это раздувало бойца в 100 раз.
        int ref = 0;
        for (int i = 0; i < boneCount; i++) if (skinJoints[i] == rootMotionNode) { ref = i; break; }
        Matrix.multiplyMM(tmpA, 0, world, skinJoints[ref] * 16, ibm, ref * 16);
        if (!Matrix.invertM(meshInv, 0, tmpA, 0)) Matrix.setIdentityM(meshInv, 0);
    }

    private void visit(int ni, float[] parent, int depth, int nearJoint) throws Exception {
        if (depth > 64) return;
        JSONObject n = nodes.getJSONObject(ni);
        float[] local = new float[16];
        if (n.has("matrix")) {
            JSONArray m = n.getJSONArray("matrix");
            for (int k = 0; k < 16; k++) local[k] = (float) m.getDouble(k);
        } else {
            float[] t = {0, 0, 0}, r = {0, 0, 0, 1}, s = {1, 1, 1};
            fill(n.optJSONArray("translation"), t); fill(n.optJSONArray("rotation"), r); fill(n.optJSONArray("scale"), s);
            float[] rm = new float[16], tmp = new float[16];
            quat(rm, r);
            Matrix.setIdentityM(local, 0);
            Matrix.translateM(local, 0, t[0], t[1], t[2]);
            Matrix.multiplyMM(tmp, 0, local, 0, rm, 0);
            System.arraycopy(tmp, 0, local, 0, 16);
            Matrix.scaleM(local, 0, s[0], s[1], s[2]);
        }
        float[] world = new float[16];
        Matrix.multiplyMM(world, 0, parent, 0, local, 0);
        int bi = jointOfNode[ni] >= 0 ? jointOfNode[ni] : nearJoint;
        if (n.has("mesh")) {
            float[] mw = world;
            int mode = 0;
            int[] remap = null;
            if (n.has("skin")) {
                mw = new float[16]; Matrix.setIdentityM(mw, 0); // скин: трансформ узла игнорируется
                int si = n.getInt("skin");
                if (boneCount > 0 && si == 0) mode = 1;
                else if (boneCount > 0 && skinRemap.containsKey(si)) { mode = 1; remap = skinRemap.get(si); }
            }
            addMesh(n.getInt("mesh"), mw, mode, bi, remap);
        }
        JSONArray ch = n.optJSONArray("children");
        if (ch != null) for (int i = 0; i < ch.length(); i++) visit(ch.getInt(i), world, depth + 1, bi);
    }

    private static void fill(JSONArray a, float[] out) throws Exception {
        if (a == null) return;
        for (int i = 0; i < out.length && i < a.length(); i++) out[i] = (float) a.getDouble(i);
    }

    private static void quat(float[] m, float[] q) {
        float x = q[0], y = q[1], z = q[2], w = q[3];
        float xx = x * x, yy = y * y, zz = z * z, xy = x * y, xz = x * z, yz = y * z, wx = w * x, wy = w * y, wz = w * z;
        m[0] = 1 - 2 * (yy + zz); m[1] = 2 * (xy + wz); m[2] = 2 * (xz - wy); m[3] = 0;
        m[4] = 2 * (xy - wz); m[5] = 1 - 2 * (xx + zz); m[6] = 2 * (yz + wx); m[7] = 0;
        m[8] = 2 * (xz + wy); m[9] = 2 * (yz - wx); m[10] = 1 - 2 * (xx + yy); m[11] = 0;
        m[12] = 0; m[13] = 0; m[14] = 0; m[15] = 1;
    }

    private void addMesh(int mi, float[] w, int skinMode, int rigidBone, int[] remap) throws Exception {
        JSONArray ps = meshes.getJSONObject(mi).getJSONArray("primitives");
        for (int pi = 0; pi < ps.length(); pi++) {
            JSONObject p = ps.getJSONObject(pi);
            if (p.optInt("mode", 4) != 4) continue;
            JSONObject at = p.getJSONObject("attributes");
            if (!at.has("POSITION")) continue;
            float[] pos = readAcc(at.getInt("POSITION"));
            int vc = pos.length / 3;
            float[] nor = at.has("NORMAL") ? readAcc(at.getInt("NORMAL")) : null;
            float[] uv = at.has("TEXCOORD_0") ? readAcc(at.getInt("TEXCOORD_0")) : null;
            int[] idx;
            if (p.has("indices")) {
                float[] f = readAcc(p.getInt("indices"));
                idx = new int[f.length - f.length % 3];
                for (int i = 0; i < idx.length; i++) { int v = (int) f[i]; idx[i] = (v >= 0 && v < vc) ? v : 0; }
            } else {
                idx = new int[vc - vc % 3];
                for (int i = 0; i < idx.length; i++) idx[i] = i;
            }
            if (nor == null || nor.length < vc * 3) nor = computeNormals(pos, idx);
            float[] data = new float[vc * 8];
            for (int v = 0; v < vc; v++) {
                float x = pos[v * 3], y = pos[v * 3 + 1], z = pos[v * 3 + 2];
                float nx = nor[v * 3], ny = nor[v * 3 + 1], nz = nor[v * 3 + 2];
                data[v * 8] = w[0] * x + w[4] * y + w[8] * z + w[12];
                data[v * 8 + 1] = w[1] * x + w[5] * y + w[9] * z + w[13];
                data[v * 8 + 2] = w[2] * x + w[6] * y + w[10] * z + w[14];
                float tx = w[0] * nx + w[4] * ny + w[8] * nz, ty = w[1] * nx + w[5] * ny + w[9] * nz, tz = w[2] * nx + w[6] * ny + w[10] * nz;
                float l = (float) Math.sqrt(tx * tx + ty * ty + tz * tz);
                if (l < 1e-8f) { tx = 0; ty = 1; tz = 0; l = 1; }
                data[v * 8 + 3] = tx / l; data[v * 8 + 4] = ty / l; data[v * 8 + 5] = tz / l;
                if (uv != null && uv.length >= vc * 2) { data[v * 8 + 6] = uv[v * 2]; data[v * 8 + 7] = uv[v * 2 + 1]; }
            }
            Prim pr = new Prim();
            pr.data = data; pr.idx = idx;
            if (skinMode == 1 && at.has("JOINTS_0") && at.has("WEIGHTS_0")) {
                float[] jn = readAcc(at.getInt("JOINTS_0")), wt = readAcc(at.getInt("WEIGHTS_0"));
                if (jn.length >= vc * 4 && wt.length >= vc * 4) {
                    float[] sd = new float[vc * 8];
                    for (int v = 0; v < vc; v++) {
                        float sum = wt[v * 4] + wt[v * 4 + 1] + wt[v * 4 + 2] + wt[v * 4 + 3];
                        for (int k = 0; k < 4; k++) {
                            int j = (int) jn[v * 4 + k];
                            if (remap != null) j = (j >= 0 && j < remap.length) ? remap[j] : 0;
                            j = Math.max(0, Math.min(boneCount - 1, j));
                            sd[v * 8 + k] = j;
                            sd[v * 8 + 4 + k] = sum > 1e-6f ? wt[v * 4 + k] / sum : (k == 0 ? 1f : 0f);
                        }
                    }
                    pr.skinData = sd;
                }
            } else if (skinMode == 2 && rigidBone >= 0) {
                float[] sd = new float[vc * 8];
                for (int v = 0; v < vc; v++) { sd[v * 8] = rigidBone; sd[v * 8 + 4] = 1f; }
                pr.skinData = sd;
            }
            if (p.has("material")) applyMaterial(pr, materials.getJSONObject(p.getInt("material")));
            prims.add(pr);
            triangles += idx.length / 3;
        }
    }

    private void applyMaterial(Prim pr, JSONObject mat) throws Exception {
        JSONObject pbr = mat.optJSONObject("pbrMetallicRoughness");
        if (pbr != null) {
            fill(pbr.optJSONArray("baseColorFactor"), pr.color);
            JSONObject bt = pbr.optJSONObject("baseColorTexture");
            if (bt != null) pr.bmp = image(bt.getInt("index"));
        }
        JSONObject ext = mat.optJSONObject("extensions");
        JSONObject sg = ext != null ? ext.optJSONObject("KHR_materials_pbrSpecularGlossiness") : null;
        if (sg != null && pr.bmp == null) {
            fill(sg.optJSONArray("diffuseFactor"), pr.color);
            JSONObject dt = sg.optJSONObject("diffuseTexture");
            if (dt != null) pr.bmp = image(dt.getInt("index"));
        }
    }

    private Bitmap image(int ti) {
        try {
            JSONObject t = textures.getJSONObject(ti);
            if (!t.has("source")) return null;
            int si = t.getInt("source");
            if (bmpCache.containsKey(si)) return bmpCache.get(si);
            JSONObject im = images.getJSONObject(si);
            Bitmap bm = null;
            if (im.has("bufferView")) {
                JSONObject bv = bufferViews.getJSONObject(im.getInt("bufferView"));
                int off = binOff + bv.optInt("byteOffset", 0), len = bv.getInt("byteLength");
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(raw, off, len, o);
                int ss = 1;
                while (o.outWidth / ss > 2048 || o.outHeight / ss > 2048) ss *= 2;
                o = new BitmapFactory.Options();
                o.inSampleSize = ss;
                bm = BitmapFactory.decodeByteArray(raw, off, len, o);
            }
            bmpCache.put(si, bm);
            return bm;
        } catch (Exception e) { return null; }
    }

    private static float[] computeNormals(float[] pos, int[] idx) {
        float[] n = new float[pos.length];
        for (int i = 0; i + 2 < idx.length; i += 3) {
            int a = idx[i] * 3, b = idx[i + 1] * 3, c = idx[i + 2] * 3;
            float ux = pos[b] - pos[a], uy = pos[b + 1] - pos[a + 1], uz = pos[b + 2] - pos[a + 2];
            float vx = pos[c] - pos[a], vy = pos[c + 1] - pos[a + 1], vz = pos[c + 2] - pos[a + 2];
            float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
            for (int k : new int[]{a, b, c}) { n[k] += nx; n[k + 1] += ny; n[k + 2] += nz; }
        }
        return n;
    }

    private float readComp(int p, int ct, boolean norm) {
        switch (ct) {
            case 5126: return bb.getFloat(p);
            case 5123: { int v = bb.getShort(p) & 0xFFFF; return norm ? v / 65535f : v; }
            case 5125: return (float) (bb.getInt(p) & 0xFFFFFFFFL);
            case 5121: { int v = bb.get(p) & 0xFF; return norm ? v / 255f : v; }
            case 5120: { int v = bb.get(p); return norm ? Math.max(v / 127f, -1f) : v; }
            case 5122: { int v = bb.getShort(p); return norm ? Math.max(v / 32767f, -1f) : v; }
            default: return 0f;
        }
    }

    private float[] readAcc(int ai) throws Exception {
        JSONObject a = accessors.getJSONObject(ai);
        int count = a.getInt("count"), ct = a.getInt("componentType");
        String ty = a.getString("type");
        int comps = ty.equals("SCALAR") ? 1 : ty.equals("VEC2") ? 2 : ty.equals("VEC3") ? 3 : ty.equals("VEC4") ? 4 : ty.equals("MAT4") ? 16 : 1;
        boolean norm = a.optBoolean("normalized", false);
        float[] out = new float[count * comps];
        if (!a.has("bufferView")) return out;
        JSONObject bv = bufferViews.getJSONObject(a.getInt("bufferView"));
        int off = binOff + bv.optInt("byteOffset", 0) + a.optInt("byteOffset", 0);
        int cs = (ct == 5126 || ct == 5125) ? 4 : (ct == 5123 || ct == 5122) ? 2 : 1;
        int stride = bv.optInt("byteStride", 0);
        if (stride == 0) stride = cs * comps;
        for (int i = 0; i < count; i++)
            for (int j = 0; j < comps; j++) out[i * comps + j] = readComp(off + i * stride + j * cs, ct, norm);
        return out;
    }

    /** Масштаб до targetH метров, ноги на y=0, центр по XZ. */
    private void normalize(float targetH) {
        float minX = 1e30f, minY = 1e30f, minZ = 1e30f, maxX = -1e30f, maxY = -1e30f, maxZ = -1e30f;
        for (Prim p : prims) for (int i = 0; i < p.data.length; i += 8) {
            minX = Math.min(minX, p.data[i]); maxX = Math.max(maxX, p.data[i]);
            minY = Math.min(minY, p.data[i + 1]); maxY = Math.max(maxY, p.data[i + 1]);
            minZ = Math.min(minZ, p.data[i + 2]); maxZ = Math.max(maxZ, p.data[i + 2]);
        }
        float h = maxY - minY;
        if (h < 1e-6f) h = 1f;
        float s = targetH / h, cx = (minX + maxX) / 2f, cz = (minZ + maxZ) / 2f;
        Matrix.setIdentityM(normM, 0);
        Matrix.scaleM(normM, 0, s, s, s);
        Matrix.translateM(normM, 0, -cx, -minY, -cz);
        Matrix.invertM(normInv, 0, normM, 0);
        for (Prim p : prims) for (int i = 0; i < p.data.length; i += 8) {
            p.data[i] = (p.data[i] - cx) * s;
            p.data[i + 1] = (p.data[i + 1] - minY) * s;
            p.data[i + 2] = (p.data[i + 2] - cz) * s;
        }
    }
}
