package com.bodycamclone;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Random;

/** Все звуки синтезируются в коде при первом запуске (файлов не нужно). */
public class SoundBank {
    public static final int RIFLE = 0, PISTOL = 1, FAR = 2, RELOAD = 3, HIT = 4,
            HURT = 5, TICK = 6, EMPTY = 7, STEP = 8, DEATH = 9, THROW = 10, EXPLODE = 11, CLINK = 12, SMOKE = 13, COUNT = 14;
    private static final int SR = 22050;
    private final SoundPool pool;
    private final int[] ids = new int[COUNT];

    public SoundBank(Context c) {
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        pool = new SoundPool.Builder().setMaxStreams(12).setAudioAttributes(aa).build();
        for (int i = 0; i < COUNT; i++) {
            try {
                File f = new File(c.getCacheDir(), "snd_v1_" + i + ".wav");
                if (!f.exists()) writeWav(f, synth(i));
                ids[i] = pool.load(f.getAbsolutePath(), 1);
            } catch (Exception e) { ids[i] = 0; }
        }
    }

    public void play(int id, float vol, float rate) {
        if (id < 0 || id >= COUNT || ids[id] == 0) return;
        vol = Math.max(0f, Math.min(1f, vol));
        rate = Math.max(0.5f, Math.min(2f, rate));
        pool.play(ids[id], vol, vol, 1, 0, rate);
    }

    public void release() { pool.release(); }

    // ---------- синтез ----------
    private static short[] synth(int id) {
        Random r = new Random(100 + id);
        float[] b;
        switch (id) {
            case RIFLE:  b = new float[(int) (SR * 0.4f)];  shot(b, r, 16f, 0.25f); break;
            case PISTOL: b = new float[(int) (SR * 0.28f)]; shot(b, r, 24f, 0.4f); break;
            case FAR:    b = new float[(int) (SR * 0.7f)];  shot(b, r, 7f, 0.05f); break;
            case RELOAD:
                b = new float[(int) (SR * 0.95f)];
                noise(b, r, 0.02f, 0.04f, 0.8f, 80f, 0.9f);
                noise(b, r, 0.35f, 0.10f, 0.5f, 18f, 0.25f);
                noise(b, r, 0.75f, 0.05f, 0.9f, 60f, 0.7f);
                break;
            case HIT:
                b = new float[(int) (SR * 0.18f)];
                noise(b, r, 0f, 0.15f, 0.6f, 25f, 0.2f);
                tone(b, 0f, 0.15f, 120f, 70f, 0.6f, 18f);
                break;
            case HURT:
                b = new float[(int) (SR * 0.3f)];
                tone(b, 0f, 0.28f, 230f, 120f, 0.6f, 6f);
                noise(b, r, 0f, 0.1f, 0.3f, 20f, 0.3f);
                break;
            case TICK:
                b = new float[(int) (SR * 0.06f)];
                tone(b, 0f, 0.05f, 1400f, 1400f, 0.5f, 40f);
                break;
            case EMPTY:
                b = new float[(int) (SR * 0.06f)];
                noise(b, r, 0f, 0.04f, 0.7f, 80f, 0.9f);
                break;
            case STEP:
                b = new float[(int) (SR * 0.14f)];
                noise(b, r, 0f, 0.12f, 0.5f, 30f, 0.08f);
                break;
            case THROW:     // щелчок чеки и взмах
                b = new float[(int) (SR * 0.3f)];
                noise(b, r, 0f, 0.03f, 0.8f, 120f, 0.9f);
                noise(b, r, 0.04f, 0.25f, 0.5f, 9f, 0.12f);
                break;
            case EXPLODE:   // глухой удар, раскат и треск осколков
                b = new float[(int) (SR * 1.6f)];
                tone(b, 0f, 1.2f, 90f, 28f, 1.0f, 2.8f);
                noise(b, r, 0f, 1.3f, 1.2f, 3.5f, 0.08f);
                noise(b, r, 0f, 0.15f, 1.0f, 18f, 0.6f);
                break;
            case CLINK:     // звон металла об землю
                b = new float[(int) (SR * 0.12f)];
                tone(b, 0f, 0.1f, 2400f, 1700f, 0.4f, 40f);
                noise(b, r, 0f, 0.02f, 0.4f, 150f, 0.9f);
                break;
            case SMOKE:     // хлопок и долгое шипение дыма
                b = new float[(int) (SR * 1.6f)];
                noise(b, r, 0f, 0.05f, 0.9f, 60f, 0.7f);
                noise(b, r, 0.03f, 1.5f, 0.55f, 2.2f, 0.35f);
                break;
            default:
                b = new float[(int) (SR * 0.6f)];
                tone(b, 0f, 0.5f, 180f, 60f, 0.6f, 5f);
                noise(b, r, 0f, 0.2f, 0.4f, 15f, 0.15f);
                break;
        }
        short[] out = new short[b.length];
        for (int i = 0; i < b.length; i++) {
            float v = Math.max(-1f, Math.min(1f, b[i]));
            out[i] = (short) (v * 30000f);
        }
        return out;
    }

    private static void shot(float[] b, Random r, float decay, float lpAlpha) {
        float y = 0f;
        for (int i = 0; i < b.length; i++) {
            float t = i / (float) SR;
            float n = r.nextFloat() * 2f - 1f;
            y += lpAlpha * (n - y);
            float v = y * 1.6f * (float) Math.exp(-decay * t);
            v += n * 0.5f * (float) Math.exp(-500f * t);
            v += 0.6f * (float) (Math.sin(2 * Math.PI * (55 + 90 * Math.exp(-35 * t)) * t) * Math.exp(-12 * t));
            b[i] += v;
        }
    }

    private static void noise(float[] b, Random r, float start, float dur, float amp, float decay, float alpha) {
        int s = (int) (start * SR), n = (int) (dur * SR);
        float y = 0f;
        for (int i = 0; i < n && s + i < b.length; i++) {
            float t = i / (float) SR;
            y += alpha * ((r.nextFloat() * 2f - 1f) - y);
            b[s + i] += y * amp * (float) Math.exp(-decay * t);
        }
    }

    private static void tone(float[] b, float start, float dur, float f0, float f1, float amp, float decay) {
        int s = (int) (start * SR), n = (int) (dur * SR);
        double ph = 0;
        for (int i = 0; i < n && s + i < b.length; i++) {
            float t = i / (float) SR;
            float f = f0 + (f1 - f0) * (t / dur);
            ph += 2 * Math.PI * f / SR;
            b[s + i] += (float) (Math.sin(ph) * amp * Math.exp(-decay * t));
        }
    }

    private static void writeWav(File f, short[] pcm) throws Exception {
        int dataLen = pcm.length * 2;
        byte[] h = new byte[44 + dataLen];
        put(h, 0, "RIFF"); le32(h, 4, 36 + dataLen); put(h, 8, "WAVE"); put(h, 12, "fmt ");
        le32(h, 16, 16); le16(h, 20, 1); le16(h, 22, 1); le32(h, 24, SR); le32(h, 28, SR * 2);
        le16(h, 32, 2); le16(h, 34, 16); put(h, 36, "data"); le32(h, 40, dataLen);
        for (int i = 0; i < pcm.length; i++) { h[44 + i * 2] = (byte) (pcm[i] & 0xFF); h[45 + i * 2] = (byte) ((pcm[i] >> 8) & 0xFF); }
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(h); }
    }
    private static void put(byte[] b, int o, String s) { for (int i = 0; i < s.length(); i++) b[o + i] = (byte) s.charAt(i); }
    private static void le32(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24); }
    private static void le16(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); }
}
