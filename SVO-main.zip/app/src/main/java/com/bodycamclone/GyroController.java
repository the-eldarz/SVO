package com.bodycamclone;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Display;
import android.view.Surface;

/**
 * Гироскоп телефона для прицеливания. Копит повороты (в радианах) в Game.Input.gyroDX / gyroDY:
 * DX &gt; 0 - повернуться вправо, DY &gt; 0 - посмотреть вниз. Учитывает поворот экрана (sensorLandscape в обе стороны).
 * Режим (выкл / только в прицеле / включен) и чувствительность применяет Game.
 */
final class GyroController implements SensorEventListener {
    private final Activity act;
    private final SensorManager sm;
    private final Sensor gyro;
    private Game.Input in;
    private long lastNs;
    private boolean running;

    GyroController(Activity a) {
        act = a;
        sm = (SensorManager) a.getSystemService(Context.SENSOR_SERVICE);
        gyro = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
    }

    static boolean available(Context c) {
        SensorManager m = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        return m != null && m.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null;
    }

    void start(Game.Input input) {
        stop();
        if (gyro == null || input == null || Settings.gyroMode == Settings.GYRO_OFF) return;
        in = input;
        synchronized (in) { in.gyroDX = 0f; in.gyroDY = 0f; }
        lastNs = 0L;
        int periodUs = 1_000_000 / Settings.GYRO_HZ[Settings.gyroHzIdx];
        running = sm.registerListener(this, gyro, periodUs);
    }

    void stop() {
        if (running) { sm.unregisterListener(this); running = false; }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onSensorChanged(SensorEvent e) {
        if (in == null) return;
        long t = e.timestamp;
        if (lastNs == 0L) { lastNs = t; return; }
        float dt = (t - lastNs) / 1e9f;
        lastNs = t;
        if (dt <= 0f || dt > 0.25f) return;
        float gx = e.values[0], gy = e.values[1];       // рад/с в осях устройства (портрет)
        float sx, sy;                                    // в осях экрана: sx - вокруг горизонтали экрана, sy - вокруг вертикали
        Display disp = act.getWindowManager().getDefaultDisplay();
        switch (disp.getRotation()) {
            case Surface.ROTATION_90:  sx = -gy; sy = gx;  break;
            case Surface.ROTATION_270: sx = gy;  sy = -gx; break;
            case Surface.ROTATION_180: sx = -gx; sy = -gy; break;
            default:                   sx = gx;  sy = gy;  break;
        }
        // sy > 0 - поворот влево (против часовой сверху), sx > 0 - экран наклоняется вниз
        synchronized (in) {
            in.gyroDX += -sy * dt;
            in.gyroDY += sx * dt;
        }
    }

    @Override public void onAccuracyChanged(Sensor s, int accuracy) {}
}
