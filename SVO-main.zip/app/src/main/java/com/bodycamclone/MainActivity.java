package com.bodycamclone;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int MATCH = -1, WRAP = -2;
    private static final int TXT = 0xFFE8EDE4, TXT2 = 0xFF8FB07F, TXT3 = 0xFF8A948A;

    private FrameLayout root;
    private GLSurfaceView gl;
    private HudView hud;
    private Game game;
    private SoundBank snd;
    private GyroController gyro;
    private View screen;      // экран меню, лежащий поверх всего
    private Runnable onBack;  // что делает кнопка «назад» на этом экране
    private int selMap = 0, selSide = Config.SIDE_RU;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Settings.init(this);
        snd = new SoundBank(this);
        gyro = new GyroController(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0E1214);
        setContentView(root);
        showMain();
    }

    // ---------- каркас экранов ----------

    private int dp(float v) { return Ui.dp(this, v); }

    private LinearLayout.LayoutParams lp(int w, int h, float weight, int l, int t, int r, int bt) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(dp(l), dp(t), dp(r), dp(bt));
        return p;
    }

    private void showScreen(View v, Runnable back) {
        if (screen != null) root.removeView(screen);
        screen = v;
        onBack = back;
        root.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    private void hideScreen() {
        if (screen != null) root.removeView(screen);
        screen = null;
        onBack = null;
    }

    /** Вертикальная страница меню с заголовком. */
    private LinearLayout page(String title) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        l.setPadding(dp(28), dp(14), dp(28), dp(14));
        l.setBackground(Ui.background());
        l.setClickable(true);
        if (title != null) {
            TextView t = Ui.text(this, title, 24, TXT, true);
            t.setGravity(Gravity.CENTER);
            l.addView(t, lp(MATCH, WRAP, 0f, 0, 0, 0, 8));
        }
        return l;
    }

    private Button backButton(Runnable action) {
        return Ui.button(this, "Назад", v -> action.run());
    }

    private LinearLayout card(View header, String title, String sub, View.OnClickListener click) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(10), dp(12), dp(10), dp(12));
        c.setBackground(Ui.stateBox(this, 0xFF222E26, 0xFF3F5A3A, 0xFF5E7F55, 12));
        c.setClickable(true);
        c.setOnClickListener(click);
        if (header != null) c.addView(header);
        TextView t = Ui.text(this, title, 18, TXT, true);
        t.setGravity(Gravity.CENTER);
        c.addView(t, lp(MATCH, WRAP, 0f, 0, 8, 0, 2));
        if (sub != null) {
            TextView s = Ui.text(this, sub, 13, TXT2, false);
            s.setGravity(Gravity.CENTER);
            c.addView(s, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        }
        return c;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        return r;
    }

    // ---------- главное меню ----------

    private void showMain() {
        LinearLayout l = page(null);
        l.setGravity(Gravity.CENTER);
        TextView t = Ui.text(this, "BODYCAM", 40, TXT, true);
        t.setGravity(Gravity.CENTER);
        t.setLetterSpacing(0.15f);
        l.addView(t, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        TextView s = Ui.text(this, "СВО  ·  офлайн-шутер", 14, TXT2, false);
        s.setGravity(Gravity.CENTER);
        l.addView(s, lp(MATCH, WRAP, 0f, 0, 0, 0, 18));
        l.addView(Ui.button(this, "ИГРАТЬ", v -> showMaps()), lp(dp(280), dp(52), 0f, 0, 0, 0, 10));
        l.addView(Ui.button(this, "НАСТРОЙКИ", v -> showSettings(this::showMain)), lp(dp(280), dp(52), 0f, 0, 0, 0, 10));
        l.addView(Ui.button(this, "ВЫХОД", v -> finish()), lp(dp(280), dp(52), 0f, 0, 0, 0, 0));
        showScreen(l, null);
    }

    // ---------- играть: карта -> сторона -> снаряжение ----------

    private void showMaps() {
        LinearLayout l = page("Выбор карты");
        LinearLayout r = row();
        for (int i = 0; i < Config.MAP_NAMES.length; i++) {
            final int idx = i;
            r.addView(card(null, Config.MAP_NAMES[i], Config.MAP_DESC[i], v -> { selMap = idx; showSides(); }),
                    lp(0, MATCH, 1f, 6, 0, 6, 0));
        }
        l.addView(r, lp(MATCH, 0, 1f, 0, 6, 0, 10));
        l.addView(backButton(this::showMain), lp(dp(220), dp(46), 0f, 0, 0, 0, 0));
        showScreen(l, this::showMain);
    }

    private View flag(int... colors) {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        for (int col : colors) {
            View st = new View(this);
            st.setBackgroundColor(col);
            f.addView(st, new LinearLayout.LayoutParams(dp(96), dp(60 / colors.length)));
        }
        return f;
    }

    private void showSides() {
        LinearLayout l = page("Сторона конфликта");
        LinearLayout r = row();
        r.addView(card(flag(0xFFFFFFFF, 0xFF0039A6, 0xFFD52B1E), "РОССИЯ", "Бойцы ВДВ", v -> { selSide = Config.SIDE_RU; showLoadout(); }),
                lp(0, MATCH, 1f, 6, 0, 6, 0));
        r.addView(card(flag(0xFF0057B7, 0xFFFFD700), "УКРАИНА", "Бойцы ВСУ", v -> { selSide = Config.SIDE_UA; showLoadout(); }),
                lp(0, MATCH, 1f, 6, 0, 6, 0));
        l.addView(r, lp(MATCH, 0, 1f, 0, 6, 0, 10));
        l.addView(backButton(this::showMaps), lp(dp(220), dp(46), 0f, 0, 0, 0, 0));
        showScreen(l, this::showMaps);
    }

    private void showLoadout() {
        LinearLayout l = page("Снаряжение");
        TextView info = Ui.text(this, "Карта: " + Config.MAP_NAMES[selMap] + "   ·   Сторона: "
                + (selSide == Config.SIDE_RU ? "Россия" : "Украина"), 13, TXT2, false);
        info.setGravity(Gravity.CENTER);
        l.addView(info, lp(MATCH, WRAP, 0f, 0, 0, 0, 6));
        String[] slots = {"Форма", "Оружие", "Броня", "Гранаты", "Расходники"};
        String[] cur = {"Стандартная", rifleName() + " + ПМ", "Нет", "Нет", "Нет"};
        LinearLayout r = row();
        for (int i = 0; i < slots.length; i++) {
            if (i == 1) {
                String hint = "\nнажми, чтобы сменить" + (Settings.rifle == 1 && !rifleFileExists() ? "\n(нет файла ak-74m.glb)" : "");
                r.addView(card(null, slots[i], cur[i] + hint, v -> {
                    Settings.rifle = 1 - Settings.rifle;
                    Settings.save();
                    showLoadout();
                }), lp(0, MATCH, 1f, 4, 0, 4, 0));
                continue;
            }
            r.addView(card(null, slots[i], cur[i] + "\nвыбор появится позже",
                    v -> Toast.makeText(this, "Выбор снаряжения добавим позже", Toast.LENGTH_SHORT).show()),
                    lp(0, MATCH, 1f, 4, 0, 4, 0));
        }
        l.addView(r, lp(MATCH, 0, 1f, 0, 4, 0, 10));
        LinearLayout bt = row();
        bt.addView(backButton(this::showSides), lp(dp(180), dp(46), 0f, 0, 0, 10, 0));
        bt.addView(Ui.button(this, "В БОЙ", v -> startGame()), lp(dp(240), dp(46), 0f, 10, 0, 0, 0));
        l.addView(bt, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        showScreen(l, this::showSides);
    }

    // ---------- настройки ----------

    private static final int ACC = 0xFF8FA6DE, ACC_TXT = 0xFF10141C, ROW_LINE = 0x33FFFFFF;
    private int setTab = 1, setSub = 0;   // вкладка настроек (0 игра, 1 управление) и подвкладка (0 общее, 1 гироскоп)

    private interface FloatSetter { void set(float v); }
    private interface BoolSetter { void set(boolean v); }

    private Button tabButton(String text, boolean on, float sp, View.OnClickListener l) {
        Button b = Ui.button(this, text, l);
        b.setTextSize(sp);
        b.setBackground(Ui.box(this, on ? ACC : 0xFF1E2630, on ? ACC : 0xFF2E3846, 6));
        b.setTextColor(on ? ACC_TXT : TXT);
        return b;
    }

    private void showSettings(Runnable back) {
        final Runnable done = () -> { Settings.save(); back.run(); };
        LinearLayout l = page(null);
        l.setPadding(dp(20), dp(8), dp(20), dp(8));

        LinearLayout tabs = row();
        tabs.addView(tabButton("ИГРА", setTab == 0, 16, v -> { setTab = 0; showSettings(back); }), lp(0, dp(42), 1f, 0, 0, 4, 0));
        tabs.addView(tabButton("УПРАВЛЕНИЕ", setTab == 1, 16, v -> { setTab = 1; showSettings(back); }), lp(0, dp(42), 1f, 4, 0, 0, 0));
        l.addView(tabs, lp(MATCH, WRAP, 0f, 0, 0, 0, 4));

        if (setTab == 1) {
            LinearLayout sub = row();
            sub.addView(tabButton("ОБЩЕЕ", setSub == 0, 14, v -> { setSub = 0; showSettings(back); }), lp(0, dp(36), 1f, 0, 0, 4, 0));
            sub.addView(tabButton("ГИРОСКОП", setSub == 1, 14, v -> { setSub = 1; showSettings(back); }), lp(0, dp(36), 1f, 4, 0, 0, 0));
            l.addView(sub, lp(MATCH, WRAP, 0f, 0, 0, 0, 4));
        }

        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        sv.addView(body, new FrameLayout.LayoutParams(MATCH, WRAP));
        l.addView(sv, lp(MATCH, 0, 1f, 0, 0, 0, 6));

        if (setTab == 0) buildGameTab(body);
        else if (setSub == 0) buildControlsGeneral(body, back);
        else buildControlsGyro(body, back);

        LinearLayout bar = row();
        bar.addView(Ui.button(this, "ПО УМОЛЧАНИЮ", v -> {
            if (setTab == 0) Settings.resetGame();
            else if (setSub == 0) Settings.resetGeneral();
            else Settings.resetGyro();
            showSettings(back);
        }), lp(0, dp(42), 1f, 0, 0, 6, 0));
        bar.addView(backButton(done), lp(0, dp(42), 1f, 6, 0, 6, 0));
        bar.addView(Ui.button(this, "ПРИМЕНИТЬ", v -> {
            Settings.save();
            Toast.makeText(this, "Настройки применены", Toast.LENGTH_SHORT).show();
        }), lp(0, dp(42), 1f, 6, 0, 0, 0));
        l.addView(bar, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        showScreen(l, done);
    }

    // ----- строки настроек -----

    private LinearLayout settingRow(LinearLayout parent, String title, String subtitle) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(6), dp(8), dp(6), dp(8));
        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.addView(Ui.text(this, title, 16, TXT, false));
        if (subtitle != null) txt.addView(Ui.text(this, subtitle, 12, TXT3, false));
        r.addView(txt, lp(0, WRAP, 1f, 0, 0, 8, 0));
        parent.addView(r, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        View line = new View(this);
        line.setBackgroundColor(ROW_LINE);
        parent.addView(line, lp(MATCH, 1, 0f, 0, 0, 0, 0));
        return r;
    }

    private void sliderRow(LinearLayout parent, String title, String subtitle, float min, float max, float cur, FloatSetter set) {
        LinearLayout r = settingRow(parent, title, subtitle);
        final TextView val = Ui.text(this, String.format(Locale.US, "%.2f", cur), 16, TXT, true);
        val.setGravity(Gravity.CENTER);
        val.setBackgroundColor(0xFF1B222B);
        r.addView(val, lp(dp(64), dp(34), 0f, 0, 0, 10, 0));
        SeekBar sb = new SeekBar(this);
        final int steps = Math.round((max - min) * 100f);
        sb.setMax(steps);
        sb.setProgress(Math.round((cur - min) * 100f));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                float v = min + p / 100f;
                set.set(v);
                val.setText(String.format(Locale.US, "%.2f", v));
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        r.addView(sb, lp(dp(230), WRAP, 0f, 0, 0, 0, 0));
    }

    private void switchRow(LinearLayout parent, String title, String subtitle, boolean cur, BoolSetter set) {
        LinearLayout r = settingRow(parent, title, subtitle);
        Switch sw = new Switch(this);
        sw.setChecked(cur);
        sw.setOnCheckedChangeListener((cb, on) -> set.set(on));
        r.addView(sw, lp(WRAP, WRAP, 0f, 0, 0, 4, 0));
    }

    // ----- вкладки -----

    private void buildGameTab(LinearLayout body) {
        switchRow(body, "Дружественный огонь", "Урон по бойцам своей команды", Settings.friendlyFire, on -> Settings.friendlyFire = on);
        switchRow(body, "Инверсия камеры по вертикали", null, Settings.invertY, on -> Settings.invertY = on);
        LinearLayout r = settingRow(body, "Прицеливание", "Как работает кнопка прицела");
        final Button ads = Ui.button(this, "", null);
        ads.setText(adsLabel());
        ads.setOnClickListener(v -> { Settings.adsToggle = !Settings.adsToggle; ads.setText(adsLabel()); });
        r.addView(ads, lp(dp(260), dp(40), 0f, 0, 0, 0, 0));
    }

    private void buildControlsGeneral(LinearLayout body, Runnable back) {
        LinearLayout r = settingRow(body, "Расположение кнопок", "Кнопки, зона стрельбы и их размеры");
        r.addView(tabButton("КАСТОМИЗАЦИЯ", true, 15, v -> openEditor(() -> showSettings(back))), lp(dp(190), dp(40), 0f, 0, 0, 0, 0));

        sliderRow(body, "Чувствительность", null, Settings.SENS_MIN, Settings.SENS_MAX, Settings.sens, v -> Settings.sens = v);
        sliderRow(body, "Чувствительность с прицелом", null, Settings.SENS_MIN, Settings.SENS_MAX, Settings.adsSens, v -> Settings.adsSens = v);
        sliderRow(body, "Ускорение", "Быстрый свайп поворачивает камеру сильнее", 0f, 1f, Settings.accel, v -> Settings.accel = v);
        sliderRow(body, "Сглаживание прицела", "Плавное перемещение прицела (1.00 - без сглаживания)", 0.05f, 1f, Settings.smooth, v -> Settings.smooth = v);

        LinearLayout ch = settingRow(body, "Перекрестие", null);
        for (int k = 0; k < 2; k++) {
            final int kk = k;
            CrosshairPreview pv = new CrosshairPreview(this, k);
            ch.addView(pv, lp(dp(64), dp(40), 0f, 0, 0, 6, 0));
            ch.addView(tabButton("ИЗМ", true, 13, v -> showCrosshairEditor(kk, () -> showSettings(back))), lp(dp(44), dp(40), 0f, 0, 0, 14, 0));
        }
        switchRow(body, "Точный отклик", "Уменьшает резкие скачки при движении прицела. Может увеличить нагрев устройства и расход заряда.",
                Settings.precise, on -> Settings.precise = on);
    }

    private void buildControlsGyro(LinearLayout body, Runnable back) {
        if (!GyroController.available(this)) {
            body.addView(Ui.text(this, "На этом устройстве гироскоп не найден", 14, 0xFFE0C060, false), lp(MATCH, WRAP, 0f, 6, 6, 6, 6));
        }
        LinearLayout m = settingRow(body, "Режим гироскопа", null);
        String[] names = {"ВЫКЛЮЧЕН", "ТОЛЬКО В ПРИЦЕЛЕ", "ВКЛЮЧЕН"};
        for (int i = 0; i < 3; i++) {
            final int mode = i;
            m.addView(tabButton(names[i], Settings.gyroMode == i, 13, v -> { Settings.gyroMode = mode; showSettings(back); }),
                    lp(dp(i == 1 ? 170 : 120), dp(40), 0f, 0, 0, 6, 0));
        }
        switchRow(body, "Вертикальная инверсия", null, Settings.gyroInvY, on -> Settings.gyroInvY = on);
        switchRow(body, "Горизонтальная инверсия", null, Settings.gyroInvX, on -> Settings.gyroInvX = on);
        sliderRow(body, "Чувствительность", null, Settings.SENS_MIN, Settings.SENS_MAX, Settings.gyroSens, v -> Settings.gyroSens = v);
        sliderRow(body, "Чувствительность с прицелом", null, Settings.SENS_MIN, Settings.SENS_MAX, Settings.gyroAdsSens, v -> Settings.gyroAdsSens = v);

        LinearLayout hz = settingRow(body, "Целевая частота", "Влияет на количество обновлений данных гироскопа в секунду. Может нагружать устройство.");
        final TextView hzText = Ui.text(this, Settings.GYRO_HZ[Settings.gyroHzIdx] + " HZ", 18, TXT, true);
        hzText.setGravity(Gravity.CENTER);
        hz.addView(tabButton("‹", false, 20, v -> {
            Settings.gyroHzIdx = (Settings.gyroHzIdx + Settings.GYRO_HZ.length - 1) % Settings.GYRO_HZ.length;
            hzText.setText(Settings.GYRO_HZ[Settings.gyroHzIdx] + " HZ");
        }), lp(dp(44), dp(40), 0f, 0, 0, 4, 0));
        hz.addView(hzText, lp(dp(90), WRAP, 0f, 0, 0, 4, 0));
        hz.addView(tabButton("›", false, 20, v -> {
            Settings.gyroHzIdx = (Settings.gyroHzIdx + 1) % Settings.GYRO_HZ.length;
            hzText.setText(Settings.GYRO_HZ[Settings.gyroHzIdx] + " HZ");
        }), lp(dp(44), dp(40), 0f, 0, 0, 0, 0));
    }

    private String adsLabel() {
        return Settings.adsToggle ? "Прицел: нажал — вкл/выкл" : "Прицел: пока держишь кнопку";
    }

    // ----- перекрестие -----

    /** Маленькое превью перекрестия для строки настроек и редактора. */
    private static final class CrosshairPreview extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int k;
        private final float d;
        CrosshairPreview(Context c, int kind) {
            super(c);
            k = kind;
            d = c.getResources().getDisplayMetrics().density;
            setBackgroundColor(0xFF1B222B);
        }
        @Override protected void onDraw(Canvas c) {
            ControlsUi.drawCrosshair(c, p, getWidth() / 2f, getHeight() / 2f, d * Math.min(1f, 18f * d / Math.max(1f, (Settings.chSize[k] + Settings.chGap[k]) * d)), k);
        }
    }

    private void showCrosshairEditor(int k, Runnable back) {
        LinearLayout l = page(k == 0 ? "Перекрестие" : "Перекрестие в прицеле");
        l.setPadding(dp(20), dp(8), dp(20), dp(8));
        final CrosshairPreview big = new CrosshairPreview(this, k);
        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        sv.addView(body, new FrameLayout.LayoutParams(MATCH, WRAP));
        l.addView(sv, lp(MATCH, 0, 1f, 0, 0, 0, 6));
        body.addView(big, lp(MATCH, dp(90), 0f, 0, 0, 0, 6));

        LinearLayout st = settingRow(body, "Вид", null);
        for (int i = 0; i < Settings.CH_STYLE_NAME.length; i++) {
            final int style = i;
            final Button b = tabButton(Settings.CH_STYLE_NAME[i], Settings.chStyle[k] == i, 12, null);
            b.setOnClickListener(v -> { Settings.chStyle[k] = style; showCrosshairEditor(k, back); });
            st.addView(b, lp(0, dp(38), 1f, 0, 0, 4, 0));
        }
        LinearLayout co = settingRow(body, "Цвет", null);
        for (int i = 0; i < Settings.CH_COLORS.length; i++) {
            final int ci = i;
            View sw = new View(this);
            sw.setBackground(Ui.box(this, Settings.CH_COLORS[i], Settings.chColor[k] == i ? 0xFFFFFFFF : 0xFF2E3846, 6));
            sw.setOnClickListener(v -> { Settings.chColor[k] = ci; showCrosshairEditor(k, back); });
            co.addView(sw, lp(dp(40), dp(34), 0f, 0, 0, 8, 0));
        }
        sliderRow(body, "Размер", null, 2f, 30f, Settings.chSize[k], v -> { Settings.chSize[k] = v; big.invalidate(); });
        sliderRow(body, "Толщина", null, 1f, 6f, Settings.chThick[k], v -> { Settings.chThick[k] = v; big.invalidate(); });
        sliderRow(body, "Просвет в центре", "Для креста", 0f, 20f, Settings.chGap[k], v -> { Settings.chGap[k] = v; big.invalidate(); });

        final Runnable done = () -> { Settings.save(); back.run(); };
        l.addView(backButton(done), lp(dp(220), dp(42), 0f, 0, 0, 0, 0));
        showScreen(l, done);
    }

    // ----- кастомизация раскладки -----

    private void openEditor(Runnable back) {
        FrameLayout f = new FrameLayout(this);
        final ButtonEditorView ev = new ButtonEditorView(this, game != null);
        f.addView(ev, new FrameLayout.LayoutParams(MATCH, MATCH));
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackgroundColor(0xE61B1F2B);
        bar.setPadding(dp(6), dp(6), dp(6), dp(6));
        final Runnable[] modeSync = new Runnable[1];
        LinearLayout r1 = row();
        r1.addView(Ui.button(this, "−", v -> ev.resize(-0.1f)), lp(dp(50), dp(40), 0f, 3, 0, 3, 0));
        r1.addView(Ui.button(this, "+", v -> ev.resize(0.1f)), lp(dp(50), dp(40), 0f, 3, 0, 3, 0));
        r1.addView(Ui.button(this, "Сброс", v -> { Settings.resetLayout(); ev.refresh(); if (modeSync[0] != null) modeSync[0].run(); }), lp(dp(84), dp(40), 0f, 3, 0, 3, 0));
        final Runnable done = () -> { Settings.clampZone(); Settings.save(); back.run(); };
        r1.addView(Ui.button(this, "Готово", v -> done.run()), lp(dp(92), dp(40), 0f, 3, 0, 3, 0));
        bar.addView(r1, lp(WRAP, WRAP, 0f, 0, 0, 0, 4));
        LinearLayout r2 = row();
        final String[] modes = {"КНОПКА + ЗОНА", "ТОЛЬКО КНОПКА", "ТОЛЬКО ЗОНА"};
        final Button[] mb = new Button[3];
        final Runnable syncModes = () -> {
            for (int j = 0; j < 3; j++) {
                boolean on = Settings.fireMode == j;
                mb[j].setBackground(Ui.box(this, on ? ACC : 0xFF1E2630, on ? ACC : 0xFF2E3846, 6));
                mb[j].setTextColor(on ? ACC_TXT : TXT);
            }
        };
        for (int i = 0; i < 3; i++) {
            final int mode = i;
            mb[i] = tabButton(modes[i], Settings.fireMode == i, 11, null);
            mb[i].setOnClickListener(v -> {
                Settings.fireMode = mode;
                syncModes.run();
                ev.refresh();
            });
            r2.addView(mb[i], lp(dp(i == 0 ? 112 : 106), dp(34), 0f, 3, 0, 3, 0));
        }
        modeSync[0] = syncModes;
        bar.addView(r2, lp(WRAP, WRAP, 0f, 0, 0, 0, 0));
        f.addView(bar, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.LEFT));
        showScreen(f, done);
    }

    // ---------- игра и пауза ----------

    private String rifleName() { return Settings.rifle == 1 ? "АК-74М" : "АК-74"; }

    private boolean rifleFileExists() {
        try (java.io.InputStream in = getAssets().open(Config.AK_MODEL)) { return true; } catch (Exception e) { return false; }
    }

    private void startGame() {
        hideScreen();
        Game.W_NAME[0] = rifleName();
        game = new Game(Config.MAP_SEEDS[selMap], selSide);
        game.snd = snd;
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(3);
        gl.setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        gl.setRenderer(new GameRenderer(this, game));
        gl.setPreserveEGLContextOnPause(true);
        hud = new HudView(this, game);
        root.addView(gl, new FrameLayout.LayoutParams(MATCH, MATCH));
        root.addView(hud, new FrameLayout.LayoutParams(MATCH, MATCH));
        gyro.start(game.input);
    }

    private void stopGame() {
        gyro.stop();
        if (gl != null) { gl.onPause(); root.removeView(gl); gl = null; }
        if (hud != null) { root.removeView(hud); hud = null; }
        game = null;
    }

    private void showPause() {
        if (game == null) return;
        game.paused = true;
        gyro.stop();
        if (hud != null) hud.releaseInput();
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(0xB0000000);
        l.setClickable(true);
        TextView t = Ui.text(this, "Пауза", 28, TXT, true);
        t.setGravity(Gravity.CENTER);
        l.addView(t, lp(MATCH, WRAP, 0f, 0, 0, 0, 14));
        l.addView(Ui.button(this, "ПРОДОЛЖИТЬ", v -> resumeGame()), lp(dp(280), dp(50), 0f, 0, 0, 0, 10));
        l.addView(Ui.button(this, "НАСТРОЙКИ", v -> showSettings(this::showPause)), lp(dp(280), dp(50), 0f, 0, 0, 0, 10));
        l.addView(Ui.button(this, "В ГЛАВНОЕ МЕНЮ", v -> { stopGame(); showMain(); }), lp(dp(280), dp(50), 0f, 0, 0, 0, 0));
        showScreen(l, this::resumeGame);
    }

    private void resumeGame() {
        hideScreen();
        if (game != null) { game.paused = false; gyro.start(game.input); }
    }

    @Override
    public void onBackPressed() {
        if (onBack != null) onBack.run();
        else if (game != null) showPause();
        else super.onBackPressed();
    }

    @Override protected void onResume() { super.onResume(); if (gl != null) gl.onResume(); }

    @Override
    protected void onPause() {
        Settings.save();
        if (game != null && screen == null) showPause();
        gyro.stop();
        if (gl != null) gl.onPause();
        super.onPause();
    }

    @Override protected void onDestroy() { snd.release(); super.onDestroy(); }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
}
