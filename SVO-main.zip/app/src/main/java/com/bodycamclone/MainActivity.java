package com.bodycamclone;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int MATCH = -1, WRAP = -2;
    private static final int TXT = 0xFFE8EDE4, TXT2 = 0xFF8FB07F, TXT3 = 0xFF8A948A;

    private FrameLayout root;
    private GLSurfaceView gl;
    private HudView hud;
    private Game game;
    private SoundBank snd;
    private GyroController gyro;
    private View screen;      // экран меню, лежащий поверх всего
    private Runnable onBack;  // что делает кнопка «назад» на этом экране
    private int selMap = 0, selSide = Config.SIDE_RU;

    // --- мультиплеер ---
    private Net net;                        // активная сетевая игра
    private Net.Finder finder;              // поиск комнат
    private WifiManager.MulticastLock mcLock;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private String mpRoom = "";
    private boolean joining;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        DevLog.init(this);
        final Thread.UncaughtExceptionHandler prevHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((th, ex) -> {        // вылет попадает в журнал (файл) и виден в меню «Логи» после перезапуска
            try { DevLog.e("ВЫЛЕТ", "необработанная ошибка в потоке " + th.getName(), ex); } catch (Throwable ignored) { }
            if (prevHandler != null) prevHandler.uncaughtException(th, ex);
        });
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Settings.init(this);
        GameFiles.init(this);
        snd = new SoundBank(this);
        gyro = new GyroController(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0E1214);
        setContentView(root);
        if (GameFiles.isReady()) {
            showMain();
            new Thread(GameFiles::warmUp, "cache-index").start();
        } else showCacheScreen(false);   // без кэша игра не запускается
    }

    // ---------- каркас экранов ----------

    private int dp(float v) { return Ui.dp(this, v); }

    private LinearLayout.LayoutParams lp(int w, int h, float weight, int l, int t, int r, int bt) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(dp(l), dp(t), dp(r), dp(bt));
        return p;
    }

    private void showScreen(View v, Runnable back) {
        loadoutView = null;
        if (screen != null) root.removeView(screen);
        screen = v;
        onBack = back;
        root.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    private void hideScreen() {
        loadoutView = null;
        if (screen != null) root.removeView(screen);
        screen = null;
        onBack = null;
    }

    /** Вертикальная страница меню с заголовком. */
    private LinearLayout page(String title) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        l.setPadding(dp(28), dp(14), dp(28), dp(14));
        l.setBackground(Ui.background());
        l.setClickable(true);
        if (title != null) {
            TextView t = Ui.text(this, title, 24, TXT, true);
            t.setGravity(Gravity.CENTER);
            l.addView(t, lp(MATCH, WRAP, 0f, 0, 0, 0, 8));
        }
        return l;
    }

    private Button backButton(Runnable action) {
        return Ui.button(this, "Назад", v -> action.run());
    }

    private LinearLayout card(View header, String title, String sub, View.OnClickListener click) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(10), dp(12), dp(10), dp(12));
        c.setBackground(Ui.stateBox(this, 0xFF222E26, 0xFF3F5A3A, 0xFF5E7F55, 12));
        c.setClickable(true);
        c.setOnClickListener(click);
        if (header != null) c.addView(header);
        TextView t = Ui.text(this, title, 18, TXT, true);
        t.setGravity(Gravity.CENTER);
        c.addView(t, lp(MATCH, WRAP, 0f, 0, 8, 0, 2));
        if (sub != null) {
            TextView s = Ui.text(this, sub, 13, TXT2, false);
            s.setGravity(Gravity.CENTER);
            c.addView(s, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        }
        return c;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        return r;
    }

    // ---------- главное меню ----------

    private void showMain() {
        LinearLayout l = page(null);
        l.setGravity(Gravity.CENTER);
        TextView t = Ui.text(this, "FRONTLINE FODDER", 34, TXT, true);
        t.setGravity(Gravity.CENTER);
        t.setLetterSpacing(0.15f);
        l.addView(t, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        TextView s = Ui.text(this, "СВО  ·  шутер", 14, TXT2, false);
        s.setGravity(Gravity.CENTER);
        l.addView(s, lp(MATCH, WRAP, 0f, 0, 0, 0, 18));
        l.addView(Ui.button(this, "ИГРАТЬ", v -> showMaps()), lp(dp(280), dp(52), 0f, 0, 0, 0, 10));
        l.addView(Ui.button(this, "ПО СЕТИ", v -> showMultiplayer()), lp(dp(280), dp(52), 0f, 0, 0, 0, 10));
        l.addView(Ui.button(this, "НАСТРОЙКИ", v -> showSettings(this::showMain)), lp(dp(280), dp(52), 0f, 0, 0, 0, 10));
        LinearLayout last = row();
        last.addView(Ui.button(this, "ЛОГИ", v -> showLogs()), lp(0, dp(52), 1f, 0, 0, 4, 0));
        last.addView(Ui.button(this, "КЭШ", v -> showCacheScreen(true)), lp(0, dp(52), 1f, 2, 0, 2, 0));
        last.addView(Ui.button(this, "ВЫХОД", v -> finish()), lp(0, dp(52), 1f, 4, 0, 0, 0));
        l.addView(last, lp(dp(280), WRAP, 0f, 0, 0, 0, 0));
        TextView ver = Ui.text(this, "Версия " + versionName(), 12, TXT3, false);
        ver.setGravity(Gravity.CENTER);
        l.addView(ver, lp(MATCH, WRAP, 0f, 0, 12, 0, 0));
        showScreen(l, null);
    }

    // ---------- кэш игры ----------

    private static final int REQ_CACHE = 4711;
    private TextView cacheStatus;
    private Button cachePick;
    private boolean cacheBusy;

    /** Экран выбора папки кэша. canBack = false при первом запуске: пока кэша нет, дальше пройти нельзя. */
    private void showCacheScreen(boolean canBack) {
        LinearLayout l = page("КЭШ ИГРЫ");
        l.setGravity(Gravity.CENTER);
        TextView info = Ui.text(this, canBack
                ? "Выбери папку кэша: внутри неё должны лежать папки models и user_files."
                : "Для запуска нужен кэш игры (модели и анимации). Распакуй кэш в обычную папку на телефоне (внутри должны быть models и user_files), нажми кнопку и выбери эту папку.",
                15, TXT2, false);
        info.setGravity(Gravity.CENTER);
        l.addView(info, lp(dp(440), WRAP, 0f, 0, 6, 0, 8));
        TextView hint = Ui.text(this, "Нельзя выбрать корень памяти, папку Download и Android/data - положи кэш в свою папку, например BodycamGame.", 12, TXT3, false);
        hint.setGravity(Gravity.CENTER);
        l.addView(hint, lp(dp(440), WRAP, 0f, 0, 0, 0, 14));
        cachePick = Ui.button(this, "УКАЗАТЬ ПАПКУ КЭША", v -> pickCache());
        l.addView(cachePick, lp(dp(280), dp(52), 0f, 0, 0, 0, 10));
        cacheStatus = Ui.text(this, canBack ? "Сейчас: " + GameFiles.describe() : "", 13, TXT3, false);
        cacheStatus.setGravity(Gravity.CENTER);
        l.addView(cacheStatus, lp(dp(440), WRAP, 0f, 0, 0, 0, 10));
        if (canBack) l.addView(backButton(() -> { if (!cacheBusy) showMain(); }), lp(dp(220), dp(46), 0f, 0, 0, 0, 0));
        showScreen(l, canBack ? () -> { if (!cacheBusy) showMain(); } : null);
    }

    private void pickCache() {
        if (cacheBusy) return;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        try { startActivityForResult(i, REQ_CACHE); }
        catch (Exception e) { Toast.makeText(this, "Не удалось открыть выбор папки", Toast.LENGTH_LONG).show(); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CACHE && res == RESULT_OK && data != null && data.getData() != null) connectCache(data.getData());
    }

    private void connectCache(final Uri uri) {
        if (cacheBusy) return;
        cacheBusy = true;
        if (cachePick != null) cachePick.setEnabled(false);
        if (cacheStatus != null) { cacheStatus.setTextColor(TXT3); cacheStatus.setText("Проверка папки..."); }
        new Thread(() -> {
            try {
                final int n = GameFiles.setTree(uri);
                ui.post(() -> {
                    cacheBusy = false;
                    Toast.makeText(this, "Кэш подключён, файлов: " + n, Toast.LENGTH_LONG).show();
                    showMain();
                });
            } catch (Throwable e) {
                DevLog.e("Кэш", "не удалось подключить кэш", e);
                final String msg = String.valueOf(e.getMessage());
                ui.post(() -> {
                    cacheBusy = false;
                    if (cachePick != null) cachePick.setEnabled(true);
                    if (cacheStatus != null) { cacheStatus.setTextColor(0xFFFF6B5E); cacheStatus.setText("Ошибка: " + msg); }
                });
            }
        }, "cache-connect").start();
    }

    // ---------- логи ----------

    private boolean logsProblemsOnly;

    /** Журнал загрузки моделей/анимаций, ошибок и вылетов (раньше он мигал жёлтым текстом поверх игры). */
    private void showLogs() {
        LinearLayout l = page(null);
        l.setPadding(dp(16), dp(8), dp(16), dp(8));
        TextView title = Ui.text(this, "Логи", 20, TXT, true);
        title.setGravity(Gravity.CENTER);
        l.addView(title, lp(MATCH, WRAP, 0f, 0, 0, 0, 4));

        final TextView tv = new TextView(this);
        tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        tv.setTextSize(10.5f);
        tv.setTextColor(0xFFCFD8CF);
        tv.setTextIsSelectable(true);
        tv.setPadding(dp(8), dp(6), dp(8), dp(6));
        tv.setBackgroundColor(0xFF0B0F0D);
        final ScrollView sv = new ScrollView(this);
        sv.addView(tv, new FrameLayout.LayoutParams(MATCH, WRAP));
        l.addView(sv, lp(MATCH, 0, 1f, 0, 0, 0, 6));

        final Button filter = Ui.button(this, "", null);
        final Runnable fill = () -> {
            java.util.List<String> lines = DevLog.snapshot(logsProblemsOnly);
            SpannableStringBuilder sb = new SpannableStringBuilder();
            if (lines.isEmpty()) sb.append(logsProblemsOnly ? "Проблем нет." : "Журнал пуст.");
            int cur = 0xFFCFD8CF;
            for (String s2 : lines) {
                boolean head = s2.length() > 14 && s2.charAt(12) == ' ' && s2.charAt(14) == ' ';
                if (head) cur = s2.charAt(13) == 'E' ? 0xFFFF6B5E : s2.charAt(13) == 'W' ? 0xFFFFD25A : 0xFFCFD8CF;
                else if (s2.startsWith("────")) cur = 0xFF7FB6FF;
                int st = sb.length();
                sb.append(s2).append('\n');
                sb.setSpan(new ForegroundColorSpan(cur), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            tv.setText(sb);
            filter.setText(logsProblemsOnly ? "ПОКАЗАТЬ ВСЁ" : "ТОЛЬКО ПРОБЛЕМЫ");
            sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
        };
        filter.setOnClickListener(v -> { logsProblemsOnly = !logsProblemsOnly; fill.run(); });

        LinearLayout bar = row();
        bar.addView(backButton(this::showMain), lp(0, dp(42), 1f, 0, 0, 4, 0));
        bar.addView(filter, lp(0, dp(42), 1.5f, 4, 0, 4, 0));
        bar.addView(Ui.button(this, "КОПИРОВАТЬ", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Bodycam log", DevLog.dump(logsProblemsOnly)));
            Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show();
        }), lp(0, dp(42), 1.2f, 4, 0, 4, 0));
        bar.addView(Ui.button(this, "ПОДЕЛИТЬСЯ", v -> {
            String text = DevLog.dump(logsProblemsOnly);
            if (text.length() > 120000) text = "…\n" + text.substring(text.length() - 120000);     // слишком длинный текст Android не передаёт
            Intent it = new Intent(Intent.ACTION_SEND);
            it.setType("text/plain");
            it.putExtra(Intent.EXTRA_SUBJECT, "Bodycam: лог");
            it.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(it, "Отправить лог"));
        }), lp(0, dp(42), 1.2f, 4, 0, 4, 0));
        bar.addView(Ui.button(this, "ОЧИСТИТЬ", v -> { DevLog.clear(); fill.run(); }), lp(0, dp(42), 1f, 4, 0, 0, 0));
        l.addView(bar, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        fill.run();
        showScreen(l, this::showMain);
    }

    // ---------- игра по сети ----------

    private String mpName() {
        String n = getSharedPreferences("mp", MODE_PRIVATE).getString("name", null);
        if (n == null || n.trim().isEmpty()) n = Build.MODEL != null ? Build.MODEL : "Игрок";
        return Net.clean(n, 16);
    }

    private void saveName(String n) {
        getSharedPreferences("mp", MODE_PRIVATE).edit().putString("name", Net.clean(n, 16)).apply();
    }

    private EditText field(String text, String hint) {
        EditText e = new EditText(this);
        e.setText(text);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setTextColor(TXT);
        e.setHintTextColor(TXT3);
        e.setBackground(Ui.box(this, 0xFF1B222B, 0xFF3F5A3A, 8));
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        return e;
    }

    /** Прокручиваемое тело страницы (в альбомной ориентации места мало). */
    private LinearLayout scrollBody(LinearLayout page) {
        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        sv.addView(body, new FrameLayout.LayoutParams(MATCH, WRAP));
        page.addView(sv, lp(MATCH, 0, 1f, 0, 0, 0, 6));
        return body;
    }

    private void showMultiplayer() {
        stopFinder();
        LinearLayout l = page("Игра по сети");
        LinearLayout body = scrollBody(l);
        TextView hint = Ui.text(this, "Все телефоны должны быть в одной Wi-Fi сети\n(или подключены к точке доступа одного из них)", 13, TXT2, false);
        hint.setGravity(Gravity.CENTER);
        body.addView(hint, lp(MATCH, WRAP, 0f, 0, 0, 0, 10));
        final EditText name = field(mpName(), "Твой ник");
        body.addView(name, lp(dp(280), WRAP, 0f, 0, 0, 0, 10));
        body.addView(Ui.button(this, "СОЗДАТЬ КОМНАТУ", v -> { saveName(name.getText().toString()); showCreateRoom(); }),
                lp(dp(280), dp(48), 0f, 0, 0, 0, 8));
        body.addView(Ui.button(this, "НАЙТИ КОМНАТУ", v -> { saveName(name.getText().toString()); showFindRooms(); }),
                lp(dp(280), dp(48), 0f, 0, 0, 0, 0));
        l.addView(backButton(() -> { saveName(name.getText().toString()); showMain(); }), lp(dp(220), dp(44), 0f, 0, 0, 0, 0));
        showScreen(l, this::showMain);
    }

    private void showCreateRoom() {
        if (mpRoom.isEmpty()) mpRoom = "Комната " + mpName();
        LinearLayout l = page("Создать комнату");
        LinearLayout body = scrollBody(l);
        final EditText room = field(mpRoom, "Название комнаты");
        body.addView(room, lp(dp(340), WRAP, 0f, 0, 0, 0, 8));

        TextView t1 = Ui.text(this, "Карта", 13, TXT2, false);
        t1.setGravity(Gravity.CENTER);
        body.addView(t1, lp(MATCH, WRAP, 0f, 0, 0, 0, 2));
        LinearLayout maps = row();
        for (int i = 0; i < Config.MAP_NAMES.length; i++) {
            final int idx = i;
            maps.addView(tabButton(Config.MAP_NAMES[i], selMap == i, 14, v -> { mpRoom = room.getText().toString(); selMap = idx; showCreateRoom(); }),
                    lp(0, dp(40), 1f, 3, 0, 3, 0));
        }
        body.addView(maps, lp(dp(400), WRAP, 0f, 0, 0, 0, 8));

        TextView t2 = Ui.text(this, "Твоя сторона (соперники получат другую)", 13, TXT2, false);
        t2.setGravity(Gravity.CENTER);
        body.addView(t2, lp(MATCH, WRAP, 0f, 0, 0, 0, 2));
        LinearLayout sides = row();
        sides.addView(tabButton("РОССИЯ", selSide == Config.SIDE_RU, 14, v -> { mpRoom = room.getText().toString(); selSide = Config.SIDE_RU; showCreateRoom(); }),
                lp(0, dp(40), 1f, 3, 0, 3, 0));
        sides.addView(tabButton("УКРАИНА", selSide == Config.SIDE_UA, 14, v -> { mpRoom = room.getText().toString(); selSide = Config.SIDE_UA; showCreateRoom(); }),
                lp(0, dp(40), 1f, 3, 0, 3, 0));
        body.addView(sides, lp(dp(400), WRAP, 0f, 0, 0, 0, 4));

        LinearLayout bt = row();
        bt.addView(backButton(this::showMultiplayer), lp(dp(160), dp(46), 0f, 0, 0, 10, 0));
        bt.addView(Ui.button(this, "СОЗДАТЬ", v -> startHost(room.getText().toString())), lp(dp(240), dp(46), 0f, 10, 0, 0, 0));
        l.addView(bt, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        showScreen(l, this::showMultiplayer);
    }

    private void startHost(final String room) {
        if (joining) return;
        joining = true;
        mpRoom = room;
        final String name = mpName();
        final int map = selMap, side = selSide;
        new Thread(() -> {
            try {
                Net n = Net.host(room, map, side, name);
                runOnUiThread(() -> startNetGame(n));
            } catch (Exception e) {
                runOnUiThread(() -> {
                    joining = false;
                    Toast.makeText(this, "Не удалось создать комнату: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }, "net-start").start();
    }

    private void showFindRooms() {
        stopFinder();
        acquireMulticast();
        finder = new Net.Finder();
        final LinearLayout l = page("Комнаты в сети");
        final LinearLayout list = scrollBody(l);

        LinearLayout manual = row();
        final EditText ip = field(getSharedPreferences("mp", MODE_PRIVATE).getString("ip", ""), "IP хоста, например 192.168.1.5");
        manual.addView(ip, lp(0, WRAP, 1f, 0, 0, 8, 0));
        manual.addView(Ui.button(this, "ПО IP", v -> {
            String addr = ip.getText().toString().trim();
            getSharedPreferences("mp", MODE_PRIVATE).edit().putString("ip", addr).apply();
            joinRoom(addr, Net.GAME_PORT);
        }), lp(dp(110), dp(44), 0f, 0, 0, 0, 0));
        l.addView(manual, lp(MATCH, WRAP, 0f, 0, 0, 0, 6));
        final Runnable back = () -> { stopFinder(); showMultiplayer(); };
        l.addView(backButton(back), lp(dp(220), dp(44), 0f, 0, 0, 0, 0));
        showScreen(l, back);

        final String[] sig = {null};
        final Runnable[] tick = new Runnable[1];
        tick[0] = () -> {
            if (screen != l || finder == null) return;
            List<Net.Room> rooms = finder.list();
            StringBuilder sg = new StringBuilder();
            for (Net.Room r : rooms) sg.append(r.ip).append(r.port).append(r.name).append(r.players).append(r.map).append(';');
            if (finder.error != null) sg.append(finder.error);
            if (!sg.toString().equals(sig[0])) {            // перерисовываем только при изменениях, чтобы не терять нажатия
                sig[0] = sg.toString();
                list.removeAllViews();
                if (finder.error != null) {
                    list.addView(Ui.text(this, finder.error, 14, 0xFFE0C060, false), lp(MATCH, WRAP, 0f, 6, 6, 6, 6));
                } else if (rooms.isEmpty()) {
                    TextView e = Ui.text(this, "Ищем комнаты…\nЕсли хост уже создал комнату, а её не видно - введи его IP ниже", 14, TXT2, false);
                    e.setGravity(Gravity.CENTER);
                    list.addView(e, lp(MATCH, WRAP, 0f, 6, 14, 6, 6));
                }
                for (final Net.Room r : rooms) {
                    String mapName = r.map >= 0 && r.map < Config.MAP_NAMES.length ? Config.MAP_NAMES[r.map] : "?";
                    list.addView(card(null, r.name, mapName + "  ·  игроков " + r.players + "/" + r.max + "  ·  " + r.ip, v -> joinRoom(r.ip, r.port)),
                            lp(MATCH, WRAP, 0f, 0, 3, 0, 3));
                }
            }
            ui.postDelayed(tick[0], 700);
        };
        tick[0].run();
    }

    private void joinRoom(final String ip, final int port) {
        if (joining || ip.isEmpty()) return;
        joining = true;
        stopFinder();
        Toast.makeText(this, "Подключение…", Toast.LENGTH_SHORT).show();
        final String name = mpName();
        new Thread(() -> {
            try {
                Net n = Net.join(ip, port, name);
                runOnUiThread(() -> startNetGame(n));
            } catch (Exception e) {
                runOnUiThread(() -> {
                    joining = false;
                    Toast.makeText(this, "Не удалось подключиться: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    showFindRooms();
                });
            }
        }, "net-start").start();
    }

    private void startNetGame(Net n) {
        joining = false;
        stopFinder();
        net = n;
        int side = n.myTeam == 0 ? n.hostSide : 1 - n.hostSide;      // команда 0 играет за сторону хоста
        int map = Math.max(0, Math.min(Config.MAP_SEEDS.length - 1, n.mapIdx));
        launch(new Game(Config.MAP_SEEDS[map], side, n));
        ui.removeCallbacks(netWatch);
        ui.postDelayed(netWatch, 500);
    }

    /** Следит за соединением: если хост пропал, возвращает в меню. */
    private final Runnable netWatch = new Runnable() {
        @Override public void run() {
            if (game == null || net == null) return;
            if (net.closed) {
                String why = net.error != null ? net.error : "Соединение потеряно";
                stopGame();
                showMain();
                Toast.makeText(MainActivity.this, why, Toast.LENGTH_LONG).show();
                return;
            }
            ui.postDelayed(this, 500);
        }
    };

    private void acquireMulticast() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null && mcLock == null) { mcLock = wm.createMulticastLock("bodycam"); mcLock.setReferenceCounted(false); }
            if (mcLock != null && !mcLock.isHeld()) mcLock.acquire();
        } catch (Exception ignored) { }
    }

    private void stopFinder() {
        if (finder != null) { finder.stop(); finder = null; }
        try { if (mcLock != null && mcLock.isHeld()) mcLock.release(); } catch (Exception ignored) { }
    }

    // ---------- играть: карта -> сторона -> снаряжение ----------

    private void showMaps() {
        LinearLayout l = page("Выбор карты");
        LinearLayout r = row();
        for (int i = 0; i < Config.MAP_NAMES.length; i++) {
            final int idx = i;
            r.addView(card(null, Config.MAP_NAMES[i], Config.MAP_DESC[i], v -> { selMap = idx; showSides(); }),
                    lp(0, MATCH, 1f, 6, 0, 6, 0));
        }
        l.addView(r, lp(MATCH, 0, 1f, 0, 6, 0, 10));
        l.addView(backButton(this::showMain), lp(dp(220), dp(46), 0f, 0, 0, 0, 0));
        showScreen(l, this::showMain);
    }

    private View flag(int... colors) {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        for (int col : colors) {
            View st = new View(this);
            st.setBackgroundColor(col);
            f.addView(st, new LinearLayout.LayoutParams(dp(96), dp(60 / colors.length)));
        }
        return f;
    }

    private void showSides() {
        LinearLayout l = page("Сторона конфликта");
        LinearLayout r = row();
        r.addView(card(flag(0xFFFFFFFF, 0xFF0039A6, 0xFFD52B1E), "РОССИЯ", "Российские бойцы", v -> { selSide = Config.SIDE_RU; showLoadout(); }),
                lp(0, MATCH, 1f, 6, 0, 6, 0));
        r.addView(card(flag(0xFF0057B7, 0xFFFFD700), "УКРАИНА", "Бойцы ВСУ", v -> { selSide = Config.SIDE_UA; showLoadout(); }),
                lp(0, MATCH, 1f, 6, 0, 6, 0));
        l.addView(r, lp(MATCH, 0, 1f, 0, 6, 0, 10));
        l.addView(backButton(this::showMaps), lp(dp(220), dp(46), 0f, 0, 0, 0, 0));
        showScreen(l, this::showMaps);
    }

    private LoadoutView loadoutView;

    private String versionName() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { return "?"; }
    }

    /** Строка снаряжения без выбора (задаётся классом): подпись и значение. */
    private View infoRow(String title, String value) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(6), dp(10), dp(8));
        box.setBackground(Ui.box(this, 0xFF1B2420, 0xFF2F3F2F, 10));
        box.addView(Ui.text(this, title, 12, TXT3, false), lp(MATCH, WRAP, 0f, 0, 0, 0, 3));
        box.addView(Ui.text(this, value, 16, TXT, true), lp(MATCH, WRAP, 0f, 0, 2, 0, 2));
        return box;
    }

    /** Строка выбора со стрелками: подпись, «‹ значение ›». */
    private View stepRow(String title, final String[] opts, int cur, final IntSetter set, final Runnable after) {
        final int[] idx = {Math.max(0, Math.min(opts.length - 1, cur))};
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(6), dp(10), dp(8));
        box.setBackground(Ui.box(this, 0xFF222E26, 0xFF3F5A3A, 10));
        box.addView(Ui.text(this, title, 12, TXT2, false), lp(MATCH, WRAP, 0f, 0, 0, 0, 3));
        LinearLayout r = row();
        final TextView val = Ui.text(this, opts[idx[0]], 16, TXT, true);
        val.setGravity(Gravity.CENTER);
        Button prev = Ui.button(this, "\u2039", v -> {
            idx[0] = (idx[0] + opts.length - 1) % opts.length;
            val.setText(opts[idx[0]]);
            set.set(idx[0]);
            after.run();
        });
        Button next = Ui.button(this, "\u203A", v -> {
            idx[0] = (idx[0] + 1) % opts.length;
            val.setText(opts[idx[0]]);
            set.set(idx[0]);
            after.run();
        });
        prev.setTextSize(22);
        next.setTextSize(22);
        r.addView(prev, lp(dp(46), dp(38), 0f, 0, 0, 0, 0));
        r.addView(val, lp(0, WRAP, 1f, 6, 0, 6, 0));
        r.addView(next, lp(dp(46), dp(38), 0f, 0, 0, 0, 0));
        box.addView(r, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        return box;
    }

    /** Строка-счётчик гранат одного типа: «− N +». Плюс не работает, когда набор уже полный (лимит класса). */
    private View counterRow(String title, final int type, final int max, final Runnable after) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(6), dp(10), dp(8));
        box.setBackground(Ui.box(this, 0xFF222E26, 0xFF3F5A3A, 10));
        box.addView(Ui.text(this, title, 12, TXT2, false), lp(MATCH, WRAP, 0f, 0, 0, 0, 3));
        LinearLayout r = row();
        TextView val = Ui.text(this, "×" + Settings.gn[type], 16, TXT, true);
        val.setGravity(Gravity.CENTER);
        Button minus = Ui.button(this, "\u2212", v -> { if (Settings.gn[type] > 0) { Settings.gn[type]--; after.run(); } });
        Button plus = Ui.button(this, "+", v -> { if (Settings.gnTotal() < max) { Settings.gn[type]++; after.run(); } });
        minus.setTextSize(22);
        plus.setTextSize(22);
        minus.setAlpha(Settings.gn[type] > 0 ? 1f : 0.4f);
        plus.setAlpha(Settings.gnTotal() < max ? 1f : 0.4f);
        r.addView(minus, lp(dp(46), dp(38), 0f, 0, 0, 0, 0));
        r.addView(val, lp(0, WRAP, 1f, 6, 0, 6, 0));
        r.addView(plus, lp(dp(46), dp(38), 0f, 0, 0, 0, 0));
        box.addView(r, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        return box;
    }

    private void showLoadout() {
        LinearLayout l = page("Снаряжение");
        TextView info = Ui.text(this, "Карта: " + Config.MAP_NAMES[selMap] + "   ·   Сторона: "
                + (selSide == Config.SIDE_RU ? "Россия" : "Украина"), 13, TXT2, false);
        info.setGravity(Gravity.CENTER);
        l.addView(info, lp(MATCH, WRAP, 0f, 0, 0, 0, 6));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.HORIZONTAL);

        // слева - 3D: боец с выбранной формой, оружием и подсумками
        FrameLayout stage = new FrameLayout(this);
        stage.setBackground(Ui.box(this, 0xFF121A16, 0xFF5E7F55, 12));
        stage.setPadding(dp(3), dp(3), dp(3), dp(3));
        final LoadoutView lv = new LoadoutView(this);
        stage.addView(lv, new FrameLayout.LayoutParams(MATCH, MATCH));
        final TextView stat = Ui.text(this, "", 11, 0xFFE0A060, false);
        stat.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams statLp = new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP);
        statLp.topMargin = dp(6);
        stage.addView(stat, statLp);
        TextView hint = Ui.text(this, "Потяни, чтобы повернуть", 11, TXT3, false);
        FrameLayout.LayoutParams hintLp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        hintLp.bottomMargin = dp(6);
        stage.addView(hint, hintLp);
        lv.setStatusListener(t -> stat.setText(t));
        body.addView(stage, lp(0, MATCH, 1.15f, 0, 0, 8, 0));

        final Runnable apply = () -> {
            lv.setLoadout(selSide, Settings.uniform, Settings.camo, Settings.rifle, Settings.cls, Settings.ammoBox);
            Settings.save();
        };
        apply.run();

        // справа - слоты; состав зависит от класса, поэтому список пересобирается при смене класса
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        final LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        sv.addView(rows, new FrameLayout.LayoutParams(MATCH, WRAP));
        final Runnable[] fill = new Runnable[1];
        fill[0] = () -> {
            rows.removeAllViews();
            rows.addView(stepRow("Класс", Config.CLASS_NAMES, Settings.cls,
                    i -> {
                        boolean full = Settings.gnTotal() >= Config.classGrenades(Settings.cls);     // был полный набор - при смене класса добираем до нового лимита Ф-1
                        Settings.cls = i;
                        Settings.clampGrenades();
                        if (full && Settings.gnTotal() < Config.classGrenades(i)) Settings.gn[0] += Config.classGrenades(i) - Settings.gnTotal();
                    }, () -> { apply.run(); fill[0].run(); }), lp(MATCH, WRAP, 0f, 0, 0, 0, 6));
            rows.addView(stepRow("Форма", Config.UNIFORM_NAMES, Settings.uniform,
                    i -> Settings.uniform = i, apply), lp(MATCH, WRAP, 0f, 0, 0, 0, 6));
            rows.addView(stepRow("Камуфляж", Config.CAMO_NAMES, Settings.camo,
                    i -> Settings.camo = i, apply), lp(MATCH, WRAP, 0f, 0, 0, 0, 6));
            rows.addView(stepRow("Основное оружие", new String[]{"АК-74М", "АК-74"}, 1 - Settings.rifle,
                    i -> Settings.rifle = 1 - i, apply), lp(MATCH, WRAP, 0f, 0, 0, 0, 6));
            rows.addView(infoRow("Второстепенное оружие", "Пистолет ПМ"), lp(MATCH, WRAP, 0f, 0, 0, 0, 6));
            if (Config.hasBinoculars(Settings.cls))
                rows.addView(infoRow("Бинокль", "Есть  ·  приближение ×" + (int) Config.BINOC_ZOOM), lp(MATCH, WRAP, 0f, 0, 0, 0, 6));
            int gn = Config.classGrenades(Settings.cls);
            Settings.clampGrenades();
            if (gn == 0) rows.addView(infoRow("Гранаты", "Нет  ·  медику недоступны"), lp(MATCH, WRAP, 0f, 0, 0, 0, 6));
            else {
                rows.addView(infoRow("Гранаты", "Выбрано " + Settings.gnTotal() + " из " + gn + "  ·  не больше " + gn + " на класс"), lp(MATCH, WRAP, 0f, 0, 0, 0, 3));
                for (int t = 0; t < Config.GREN_TYPES; t++)
                    rows.addView(counterRow(Config.GREN_NAMES[t] + "  ·  " + Config.GREN_DESC[t], t, gn, () -> { apply.run(); fill[0].run(); }), lp(MATCH, WRAP, 0f, 0, 0, 0, 3));
                rows.addView(new View(this), lp(MATCH, dp(3), 0f, 0, 0, 0, 0));
            }
            int mk = Config.classMedkits(Settings.cls);
            if (mk > 0) rows.addView(infoRow("Аптечки", "×" + mk + "  ·  лечат на месте"), lp(MATCH, WRAP, 0f, 0, 0, 0, 6));
            rows.addView(stepRow("Ящик с патронами", new String[]{"Нет", "Есть  (+" + Config.AMMO_BOX_RIFLE + " патронов)"}, Settings.ammoBox ? 1 : 0,
                    i -> Settings.ammoBox = i == 1, apply), lp(MATCH, WRAP, 0f, 0, 0, 0, 6));
            TextView note = Ui.text(this, "Патроны, гранаты и аптечки пополняются только в блиндажах", 11, TXT3, false);
            note.setGravity(Gravity.CENTER);
            rows.addView(note, lp(MATCH, WRAP, 0f, 0, 2, 0, 0));
        };
        fill[0].run();
        body.addView(sv, lp(0, MATCH, 1f, 8, 0, 0, 0));

        l.addView(body, lp(MATCH, 0, 1f, 0, 2, 0, 8));
        LinearLayout bt = row();
        bt.addView(backButton(this::showSides), lp(dp(180), dp(46), 0f, 0, 0, 10, 0));
        bt.addView(Ui.button(this, "В БОЙ", v -> startGame()), lp(dp(240), dp(46), 0f, 10, 0, 0, 0));
        l.addView(bt, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        // поверх меню лежит экран загрузки: модели грузятся под ним, меню открывается, когда боец уже готов
        final FrameLayout wrap = new FrameLayout(this);
        wrap.addView(l, new FrameLayout.LayoutParams(MATCH, MATCH));
        final LinearLayout overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setGravity(Gravity.CENTER);
        overlay.setBackground(Ui.background());
        overlay.setClickable(true);
        TextView ot = Ui.text(this, "ЗАГРУЗКА", 26, TXT, true);
        ot.setGravity(Gravity.CENTER);
        ot.setLetterSpacing(0.15f);
        overlay.addView(ot, lp(MATCH, WRAP, 0f, 0, 0, 0, 4));
        TextView os = Ui.text(this, "Карта: " + Config.MAP_NAMES[selMap] + "   ·   "
                + (selSide == Config.SIDE_RU ? "Россия" : "Украина"), 13, TXT2, false);
        os.setGravity(Gravity.CENTER);
        overlay.addView(os, lp(MATCH, WRAP, 0f, 0, 0, 0, 18));
        final ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        bar.setProgress(0);
        bar.setProgressTintList(ColorStateList.valueOf(0xFF8FC27A));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF2B3A2E));
        overlay.addView(bar, lp(dp(320), dp(10), 0f, 0, 0, 0, 10));
        final TextView stageTxt = Ui.text(this, "Подготовка…", 13, TXT3, false);
        stageTxt.setGravity(Gravity.CENTER);
        overlay.addView(stageTxt, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        wrap.addView(overlay, new FrameLayout.LayoutParams(MATCH, MATCH));

        final boolean[] finished = {false};
        final Runnable openMenu = () -> {
            if (finished[0]) return;
            finished[0] = true;
            if (overlay.getParent() == null) return;
            overlay.animate().alpha(0f).setDuration(250).withEndAction(() -> wrap.removeView(overlay)).start();
        };
        lv.setLoadListener(new LoadoutView.LoadListener() {
            @Override public void onProgress(float p, String st) {
                if (finished[0]) return;
                stageTxt.setText(st);
                ObjectAnimator.ofInt(bar, "progress", Math.round(p * 1000f)).setDuration(220).start();
            }
            @Override public void onReady() { openMenu.run(); }
        });
        ui.postDelayed(openMenu, 30000);          // на случай, если загрузка зависла: меню всё равно откроется

        showScreen(wrap, this::showSides);
        loadoutView = lv;
    }

    // ---------- настройки ----------

    private static final int ACC = 0xFF8FA6DE, ACC_TXT = 0xFF10141C, ROW_LINE = 0x33FFFFFF;
    private int setTab = 1, setSub = 0;   // вкладка настроек (0 игра, 1 управление, 2 видео) и подвкладка управления (0 общее, 1 гироскоп)

    private interface FloatSetter { void set(float v); }
    private interface BoolSetter { void set(boolean v); }

    private Button tabButton(String text, boolean on, float sp, View.OnClickListener l) {
        Button b = Ui.button(this, text, l);
        b.setTextSize(sp);
        b.setBackground(Ui.box(this, on ? ACC : 0xFF1E2630, on ? ACC : 0xFF2E3846, 6));
        b.setTextColor(on ? ACC_TXT : TXT);
        return b;
    }

    private void showSettings(Runnable back) {
        final Runnable done = () -> { Settings.save(); applyVideo(); back.run(); };
        LinearLayout l = page(null);
        l.setPadding(dp(20), dp(8), dp(20), dp(8));

        LinearLayout tabs = row();
        tabs.addView(tabButton("ИГРА", setTab == 0, 16, v -> { setTab = 0; showSettings(back); }), lp(0, dp(42), 1f, 0, 0, 3, 0));
        tabs.addView(tabButton("ВИДЕО", setTab == 2, 16, v -> { setTab = 2; showSettings(back); }), lp(0, dp(42), 1f, 3, 0, 3, 0));
        tabs.addView(tabButton("УПРАВЛЕНИЕ", setTab == 1, 16, v -> { setTab = 1; showSettings(back); }), lp(0, dp(42), 1f, 3, 0, 0, 0));
        l.addView(tabs, lp(MATCH, WRAP, 0f, 0, 0, 0, 4));

        if (setTab == 1) {
            LinearLayout sub = row();
            sub.addView(tabButton("ОБЩЕЕ", setSub == 0, 14, v -> { setSub = 0; showSettings(back); }), lp(0, dp(36), 1f, 0, 0, 4, 0));
            sub.addView(tabButton("ГИРОСКОП", setSub == 1, 14, v -> { setSub = 1; showSettings(back); }), lp(0, dp(36), 1f, 4, 0, 0, 0));
            l.addView(sub, lp(MATCH, WRAP, 0f, 0, 0, 0, 4));
        }

        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        sv.addView(body, new FrameLayout.LayoutParams(MATCH, WRAP));
        l.addView(sv, lp(MATCH, 0, 1f, 0, 0, 0, 6));

        if (setTab == 0) buildGameTab(body);
        else if (setTab == 2) buildVideoTab(body, back);
        else if (setSub == 0) buildControlsGeneral(body, back);
        else buildControlsGyro(body, back);

        LinearLayout bar = row();
        bar.addView(Ui.button(this, "ПО УМОЛЧАНИЮ", v -> {
            if (setTab == 0) Settings.resetGame();
            else if (setTab == 2) { Settings.resetVideo(); applyVideo(); }
            else if (setSub == 0) Settings.resetGeneral();
            else Settings.resetGyro();
            showSettings(back);
        }), lp(0, dp(42), 1f, 0, 0, 6, 0));
        bar.addView(backButton(done), lp(0, dp(42), 1f, 6, 0, 6, 0));
        bar.addView(Ui.button(this, "ПРИМЕНИТЬ", v -> {
            Settings.save();
            applyVideo();
            Toast.makeText(this, "Настройки применены", Toast.LENGTH_SHORT).show();
        }), lp(0, dp(42), 1f, 6, 0, 0, 0));
        l.addView(bar, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        showScreen(l, done);
    }

    // ----- строки настроек -----

    private LinearLayout settingRow(LinearLayout parent, String title, String subtitle) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(6), dp(8), dp(6), dp(8));
        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.addView(Ui.text(this, title, 16, TXT, false));
        if (subtitle != null) txt.addView(Ui.text(this, subtitle, 12, TXT3, false));
        r.addView(txt, lp(0, WRAP, 1f, 0, 0, 8, 0));
        parent.addView(r, lp(MATCH, WRAP, 0f, 0, 0, 0, 0));
        View line = new View(this);
        line.setBackgroundColor(ROW_LINE);
        parent.addView(line, lp(MATCH, 1, 0f, 0, 0, 0, 0));
        return r;
    }

    private void sliderRow(LinearLayout parent, String title, String subtitle, float min, float max, float cur, FloatSetter set) {
        LinearLayout r = settingRow(parent, title, subtitle);
        final TextView val = Ui.text(this, String.format(Locale.US, "%.2f", cur), 16, TXT, true);
        val.setGravity(Gravity.CENTER);
        val.setBackgroundColor(0xFF1B222B);
        r.addView(val, lp(dp(64), dp(34), 0f, 0, 0, 10, 0));
        SeekBar sb = new SeekBar(this);
        final int steps = Math.round((max - min) * 100f);
        sb.setMax(steps);
        sb.setProgress(Math.round((cur - min) * 100f));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                float v = min + p / 100f;
                set.set(v);
                val.setText(String.format(Locale.US, "%.2f", v));
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        r.addView(sb, lp(dp(230), WRAP, 0f, 0, 0, 0, 0));
    }

    private void switchRow(LinearLayout parent, String title, String subtitle, boolean cur, BoolSetter set) {
        LinearLayout r = settingRow(parent, title, subtitle);
        Switch sw = new Switch(this);
        sw.setChecked(cur);
        sw.setOnCheckedChangeListener((cb, on) -> set.set(on));
        r.addView(sw, lp(WRAP, WRAP, 0f, 0, 0, 4, 0));
    }

    // ----- вкладки -----

    private void buildGameTab(LinearLayout body) {
        switchRow(body, "Дружественный огонь", "Урон по бойцам своей команды", Settings.friendlyFire, on -> Settings.friendlyFire = on);
        switchRow(body, "Инверсия камеры по вертикали", null, Settings.invertY, on -> Settings.invertY = on);
        LinearLayout r = settingRow(body, "Прицеливание", "Как работает кнопка прицела");
        final Button ads = Ui.button(this, "", null);
        ads.setText(adsLabel());
        ads.setOnClickListener(v -> { Settings.adsToggle = !Settings.adsToggle; ads.setText(adsLabel()); });
        r.addView(ads, lp(dp(260), dp(40), 0f, 0, 0, 0, 0));
    }

    /** Строка с тремя вариантами «низкое / среднее / высокое». */
    private void qualityRow(LinearLayout body, String title, String sub, int cur, IntSetter set) {
        LinearLayout r = settingRow(body, title, sub);
        LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < Settings.QUALITY.length; i++) {
            final int idx = i;
            Button b = tabButton(Settings.QUALITY[i], cur == i, 13, v -> set.set(idx));
            b.setSingleLine(true);
            b.setPadding(dp(2), dp(4), dp(2), dp(4));
            seg.addView(b, lp(dp(100), dp(42), 0f, i == 0 ? 0 : 4, 0, 0, 0));
        }
        r.addView(seg, lp(WRAP, WRAP, 0f, 0, 0, 0, 0));
    }

    private float displayHz() {
        try { return getWindowManager().getDefaultDisplay().getRefreshRate(); } catch (Throwable t) { return 60f; }
    }

    /** Вкладка «Видео»: качество графики и частота кадров. Разрешение, дальность и эффекты работают сразу. */
    private void buildVideoTab(LinearLayout body, Runnable back) {
        final Runnable redo = () -> { applyVideo(); showSettings(back); };
        int preset = (Settings.gfxRes == Settings.gfxDist && Settings.gfxDist == Settings.gfxFx) ? Settings.gfxRes : -1;
        qualityRow(body, "Качество графики", preset < 0 ? "Свои настройки (выбор ниже)" : "Сразу меняет три настройки ниже",
                preset, i -> { Settings.gfxRes = i; Settings.gfxDist = i; Settings.gfxFx = i; redo.run(); });
        qualityRow(body, "Разрешение экрана", "Ниже - больше кадров на слабых телефонах, картинка мягче",
                Settings.gfxRes, i -> { Settings.gfxRes = i; redo.run(); });
        qualityRow(body, "Дальность прорисовки", "Как далеко видно деревья, здания и укрытия",
                Settings.gfxDist, i -> { Settings.gfxDist = i; redo.run(); });
        qualityRow(body, "Детализация эффектов", "Брызги и пятна крови, следы от пуль",
                Settings.gfxFx, i -> { Settings.gfxFx = i; redo.run(); });

        LinearLayout r = settingRow(body, "Целевая частота кадров", String.format(Locale.US, "Экран устройства: до %.0f Гц", displayHz()));
        final TextView val = Ui.text(this, String.valueOf(Settings.fpsTarget()), 18, TXT, true);
        val.setGravity(Gravity.CENTER);
        val.setBackgroundColor(0xFF1B222B);
        Button prev = tabButton("‹", false, 22, v -> {
            Settings.fpsIdx = Math.max(0, Settings.fpsIdx - 1);
            val.setText(String.valueOf(Settings.fpsTarget())); applyVideo();
        });
        Button next = tabButton("›", false, 22, v -> {
            Settings.fpsIdx = Math.min(Settings.FPS_OPTS.length - 1, Settings.fpsIdx + 1);
            val.setText(String.valueOf(Settings.fpsTarget())); applyVideo();
        });
        r.addView(prev, lp(dp(52), dp(42), 0f, 0, 0, 4, 0));
        r.addView(val, lp(dp(90), dp(42), 0f, 0, 0, 4, 0));
        r.addView(next, lp(dp(52), dp(42), 0f, 0, 0, 0, 0));

        switchRow(body, "Показывать частоту кадров", "Счётчик FPS вверху экрана в игре", Settings.showFps, on -> Settings.showFps = on);
    }

    /** Применяет видео-настройки к идущей игре: разрешение отрисовки и желаемую частоту экрана. */
    private void applyVideo() {
        if (gl == null) return;
        float s = Settings.RES_SCALE[Settings.gfxRes];
        int w = root.getWidth(), h = root.getHeight();
        if (s >= 0.99f || w <= 0 || h <= 0) gl.getHolder().setSizeFromLayout();
        else gl.getHolder().setFixedSize(Math.max(320, Math.round(w * s)), Math.max(180, Math.round(h * s)));
        int fps = Settings.fpsTarget();
        try {
            WindowManager.LayoutParams a = getWindow().getAttributes();
            a.preferredRefreshRate = fps;
            getWindow().setAttributes(a);
            if (Build.VERSION.SDK_INT >= 30 && gl.getHolder().getSurface().isValid())
                gl.getHolder().getSurface().setFrameRate(fps, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);
        } catch (Throwable t) {
            DevLog.w("Видео", "не удалось задать частоту экрана: " + t);
        }
        DevLog.i("Видео", "разрешение x" + s + ", дальность x" + Settings.DIST_MUL[Settings.gfxDist] + ", эффекты " + Settings.QUALITY[Settings.gfxFx]
                + ", цель " + fps + " к/с (экран " + Math.round(displayHz()) + " Гц)");
    }

    private void buildControlsGeneral(LinearLayout body, Runnable back) {
        LinearLayout r = settingRow(body, "Расположение кнопок", "Кнопки, зона стрельбы и их размеры");
        r.addView(tabButton("КАСТОМИЗАЦИЯ", true, 15, v -> openEditor(() -> showSettings(back))), lp(dp(190), dp(40), 0f, 0, 0, 0, 0));

        sliderRow(body, "Чувствительность", null, Settings.SENS_MIN, Settings.SENS_MAX, Settings.sens, v -> Settings.sens = v);
        sliderRow(body, "Чувствительность с прицелом", null, Settings.SENS_MIN, Settings.SENS_MAX, Settings.adsSens, v -> Settings.adsSens = v);
        sliderRow(body, "Ускорение", "Быстрый свайп поворачивает камеру сильнее", 0f, 1f, Settings.accel, v -> Settings.accel = v);
        sliderRow(body, "Сглаживание прицела", "Плавное перемещение прицела (1.00 - без сглаживания)", 0.05f, 1f, Settings.smooth, v -> Settings.smooth = v);

        LinearLayout ch = settingRow(body, "Перекрестие", null);
        for (int k = 0; k < 2; k++) {
            final int kk = k;
            CrosshairPreview pv = new CrosshairPreview(this, k);
            ch.addView(pv, lp(dp(64), dp(40), 0f, 0, 0, 6, 0));
            ch.addView(tabButton("ИЗМ", true, 13, v -> showCrosshairEditor(kk, () -> showSettings(back))), lp(dp(44), dp(40), 0f, 0, 0, 14, 0));
        }
        switchRow(body, "Точный отклик", "Уменьшает резкие скачки при движении прицела. Может увеличить нагрев устройства и расход заряда.",
                Settings.precise, on -> Settings.precise = on);
    }

    private void buildControlsGyro(LinearLayout body, Runnable back) {
        if (!GyroController.available(this)) {
            body.addView(Ui.text(this, "На этом устройстве гироскоп не найден", 14, 0xFFE0C060, false), lp(MATCH, WRAP, 0f, 6, 6, 6, 6));
        }
        LinearLayout m = settingRow(body, "Режим гироскопа", null);
        String[] names = {"ВЫКЛЮЧЕН", "ТОЛЬКО В ПРИЦЕЛЕ", "ВКЛЮЧЕН"};
        for (int i = 0; i < 3; i++) {
            final int mode = i;
            m.addView(tabButton(names[i], Settings.gyroMode == i, 13, v -> { Settings.gyroMode = mode; showSettings(back); }),
                    lp(dp(i == 1 ? 170 : 120), dp(40), 0f, 0, 0, 6, 0));
        }
        switchRow(body, "Вертикальная инверсия", null, Settings.gyroInvY, on -> Settings.gyroInvY = on);
        switchRow(body, "Горизонтальная инверсия", null, Settings.gyroInvX, on -> Settings.gyroInvX = on);
        sliderRow(body, "Чувствительность", null, Settings.SENS_MIN, Settings.SENS_MAX, Settings.gyroSens, v -> Settings.gyroSens = v);
        sliderRow(body, "Чувствительность с прицелом", null, Settings.SENS_MIN, Settings.SENS_MAX, Settings.gyroAdsSens, v -> Settings.gyroAdsSens = v);

        LinearLayout hz = settingRow(body, "Целевая частота", "Влияет на количество обновлений данных гироскопа в секунду. Может нагружать устройство.");
        final TextView hzText = Ui.text(this, Settings.GYRO_HZ[Settings.gyroHzIdx] + " HZ", 18, TXT, true);
        hzText.setGravity(Gravity.CENTER);
        hz.addView(tabButton("‹", false, 20, v -> {
            Settings.gyroHzIdx = (Settings.gyroHzIdx + Settings.GYRO_HZ.length - 1) % Settings.GYRO_HZ.length;
            hzText.setText(Settings.GYRO_HZ[Settings.gyroHzIdx] + " HZ");
        }), lp(dp(44), dp(40), 0f, 0, 0, 4, 0));
        hz.addView(hzText, lp(dp(90), WRAP, 0f, 0, 0, 4, 0));
        hz.addView(tabButton("›", false, 20, v -> {
            Settings.gyroHzIdx = (Settings.gyroHzIdx + 1) % Settings.GYRO_HZ.length;
            hzText.setText(Settings.GYRO_HZ[Settings.gyroHzIdx] + " HZ");
        }), lp(dp(44), dp(40), 0f, 0, 0, 0, 0));
    }

    private String adsLabel() {
        return Settings.adsToggle ? "Прицел: нажал — вкл/выкл" : "Прицел: пока держишь кнопку";
    }

    // ----- перекрестие -----

    /** Маленькое превью перекрестия для строки настроек и редактора. */
    private static final class CrosshairPreview extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int k;
        private final float d;
        CrosshairPreview(Context c, int kind) {
            super(c);
            k = kind;
            d = c.getResources().getDisplayMetrics().density;
            setBackgroundColor(0xFF1B222B);
        }
        @Override protected void onDraw(Canvas c) {
            ControlsUi.drawCrosshair(c, p, getWidth() / 2f, getHeight() / 2f, d * Math.min(1f, 18f * d / Math.max(1f, (Settings.chSize[k] + Settings.chGap[k]) * d)), k);
        }
    }

    private void showCrosshairEditor(int k, Runnable back) {
        LinearLayout l = page(k == 0 ? "Перекрестие" : "Перекрестие в прицеле");
        l.setPadding(dp(20), dp(8), dp(20), dp(8));
        final CrosshairPreview big = new CrosshairPreview(this, k);
        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        sv.addView(body, new FrameLayout.LayoutParams(MATCH, WRAP));
        l.addView(sv, lp(MATCH, 0, 1f, 0, 0, 0, 6));
        body.addView(big, lp(MATCH, dp(90), 0f, 0, 0, 0, 6));

        LinearLayout st = settingRow(body, "Вид", null);
        for (int i = 0; i < Settings.CH_STYLE_NAME.length; i++) {
            final int style = i;
            final Button b = tabButton(Settings.CH_STYLE_NAME[i], Settings.chStyle[k] == i, 12, null);
            b.setOnClickListener(v -> { Settings.chStyle[k] = style; showCrosshairEditor(k, back); });
            st.addView(b, lp(0, dp(38), 1f, 0, 0, 4, 0));
        }
        LinearLayout co = settingRow(body, "Цвет", null);
        for (int i = 0; i < Settings.CH_COLORS.length; i++) {
            final int ci = i;
            View sw = new View(this);
            sw.setBackground(Ui.box(this, Settings.CH_COLORS[i], Settings.chColor[k] == i ? 0xFFFFFFFF : 0xFF2E3846, 6));
            sw.setOnClickListener(v -> { Settings.chColor[k] = ci; showCrosshairEditor(k, back); });
            co.addView(sw, lp(dp(40), dp(34), 0f, 0, 0, 8, 0));
        }
        sliderRow(body, "Размер", null, 2f, 30f, Settings.chSize[k], v -> { Settings.chSize[k] = v; big.invalidate(); });
        sliderRow(body, "Толщина", null, 1f, 6f, Settings.chThick[k], v -> { Settings.chThick[k] = v; big.invalidate(); });
        sliderRow(body, "Просвет в центре", "Для креста", 0f, 20f, Settings.chGap[k], v -> { Settings.chGap[k] = v; big.invalidate(); });

        final Runnable done = () -> { Settings.save(); back.run(); };
        l.addView(backButton(done), lp(dp(220), dp(42), 0f, 0, 0, 0, 0));
        showScreen(l, done);
    }

    // ----- кастомизация раскладки -----

    private interface IntSetter { void set(int v); }

    private void openEditor(Runnable back) {
        FrameLayout f = new FrameLayout(this);
        final ButtonEditorView ev = new ButtonEditorView(this, game != null);
        f.addView(ev, new FrameLayout.LayoutParams(MATCH, MATCH));

        // панель настроек выбранного элемента (появляется только после нажатия на него)
        final FrameLayout holder = new FrameLayout(this);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(dp(360), WRAP, Gravity.TOP | Gravity.RIGHT);
        hp.setMargins(0, dp(6), dp(8), 0);
        f.addView(holder, hp);
        ev.setOnSelect(s -> {
            holder.removeAllViews();
            if (s != ButtonEditorView.SEL_NONE) holder.addView(buildEditorPanel(s, ev, holder));
        });

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        bar.setBackgroundColor(0xE61B1F2B);
        bar.setPadding(dp(6), dp(6), dp(6), dp(6));
        bar.addView(Ui.button(this, "−", v -> ev.resize(-0.1f)), lp(dp(50), dp(40), 0f, 3, 0, 3, 0));
        bar.addView(Ui.button(this, "+", v -> ev.resize(0.1f)), lp(dp(50), dp(40), 0f, 3, 0, 3, 0));
        bar.addView(Ui.button(this, "Сброс", v -> {
            Settings.resetLayout();
            ev.clearSelection();
            holder.removeAllViews();
        }), lp(dp(84), dp(40), 0f, 3, 0, 3, 0));
        final Runnable done = () -> { Settings.clampZone(); Settings.save(); back.run(); };
        bar.addView(Ui.button(this, "Готово", v -> done.run()), lp(dp(92), dp(40), 0f, 3, 0, 3, 0));
        f.addView(bar, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.LEFT));
        showScreen(f, done);
    }

    /** Строка «название - ползунок - значение в %». */
    private void miniSlider(LinearLayout parent, String title, int min, int max, int cur, IntSetter set) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(Ui.text(this, title, 14, TXT, false), lp(dp(84), WRAP, 0f, 0, 0, 4, 0));
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(Math.max(0, Math.min(max - min, cur - min)));
        final TextView val = Ui.text(this, cur + " %", 14, TXT, true);
        val.setGravity(Gravity.CENTER);
        val.setBackgroundColor(0xFF14181F);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                set.set(min + p);
                val.setText((min + p) + " %");
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        r.addView(sb, lp(0, WRAP, 1f, 0, 0, 4, 0));
        r.addView(val, lp(dp(56), dp(30), 0f, 0, 0, 0, 0));
        parent.addView(r, lp(MATCH, dp(38), 0f, 0, 0, 0, 2));
    }

    /** Ряд кнопок-вариантов, выбранная подсвечена. */
    private void segmented(LinearLayout parent, String[] names, int cur, IntSetter set) {
        LinearLayout r = row();
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            Button b = tabButton(names[i], cur == i, 11, v -> set.set(idx));
            b.setSingleLine(true);
            b.setPadding(dp(2), dp(4), dp(2), dp(4));
            r.addView(b, lp(0, dp(36), 1f, i == 0 ? 0 : 3, 0, i == names.length - 1 ? 0 : 3, 0));
        }
        parent.addView(r, lp(MATCH, WRAP, 0f, 0, 4, 0, 0));
    }

    /** Панель настроек выбранного в кастомизации элемента: кнопка, джойстик или зона стрельбы. */
    private LinearLayout buildEditorPanel(final int sel, final ButtonEditorView ev, final FrameLayout holder) {
        final Runnable rebuild = () -> { holder.removeAllViews(); holder.addView(buildEditorPanel(sel, ev, holder)); };
        LinearLayout pn = new LinearLayout(this);
        pn.setOrientation(LinearLayout.VERTICAL);
        pn.setBackgroundColor(0xF01B1F2B);
        pn.setPadding(dp(10), dp(8), dp(10), dp(8));
        pn.setClickable(true);
        String title = sel == ButtonEditorView.SEL_ZONE ? "ЗОНА СТРЕЛЬБЫ" : sel == ButtonEditorView.SEL_JOY ? "ДЖОЙСТИК" : Settings.LABEL[sel];
        pn.addView(Ui.text(this, title, 18, TXT, true), lp(MATCH, WRAP, 0f, 0, 0, 0, 4));

        if (sel != ButtonEditorView.SEL_ZONE) {
            boolean joy = sel == ButtonEditorView.SEL_JOY;
            miniSlider(pn, "Масштаб", 60, 160, Math.round((joy ? Settings.joyScale : Settings.sc[sel]) * 100f), v -> {
                if (joy) Settings.joyScale = v / 100f; else Settings.sc[sel] = v / 100f;
                ev.refresh();
            });
            miniSlider(pn, "Видимость", 20, 100, Math.round((joy ? Settings.joyAlpha : Settings.al[sel]) * 100f), v -> {
                if (joy) Settings.joyAlpha = v / 100f; else Settings.al[sel] = v / 100f;
                ev.refresh();
            });
        }

        if (sel == Settings.B_FIRE || sel == Settings.B_FIRE2 || sel == ButtonEditorView.SEL_ZONE) {
            segmented(pn, new String[]{"КНОПКА + ЗОНА", "КНОПКА", "ЗОНА"}, Settings.fireMode, i -> {
                Settings.fireMode = i; ev.refresh(); rebuild.run();
            });
        } else if (sel == Settings.B_AIM) {
            segmented(pn, new String[]{"УДЕРЖАНИЕ", "НАЖАТИЕ"}, Settings.adsToggle ? 1 : 0, i -> { Settings.adsToggle = i == 1; rebuild.run(); });
        } else if (sel == Settings.B_CROUCH) {
            segmented(pn, new String[]{"УДЕРЖАНИЕ", "НАЖАТИЕ"}, Settings.crouchHold ? 0 : 1, i -> { Settings.crouchHold = i == 0; rebuild.run(); });
        } else if (sel == Settings.B_LEAN_L || sel == Settings.B_LEAN_R) {
            segmented(pn, new String[]{"УДЕРЖАНИЕ", "НАЖАТИЕ"}, Settings.leanHold ? 0 : 1, i -> { Settings.leanHold = i == 0; rebuild.run(); });
        } else if (sel == Settings.B_PRONE) {
            segmented(pn, new String[]{"УДЕРЖАНИЕ", "НАЖАТИЕ"}, Settings.proneHold ? 0 : 1, i -> { Settings.proneHold = i == 0; rebuild.run(); });
        } else if (sel == ButtonEditorView.SEL_JOY) {
            segmented(pn, new String[]{"СТАТИЧНЫЙ", "ПЛАВАЮЩИЙ", "СВОБОДНЫЙ"}, Settings.joyMode, i -> { Settings.joyMode = i; ev.refresh(); rebuild.run(); });
            segmented(pn, new String[]{"СЛЕВА", "СПРАВА"}, Settings.joyRight ? 1 : 0, i -> { Settings.joyRight = i == 1; ev.refresh(); rebuild.run(); });
        }
        return pn;
    }

    // ---------- игра и пауза ----------

    private String rifleName() { return Settings.rifle == 1 ? "АК-74М" : "АК-74"; }

    private boolean rifleFileExists() {
        return GameFiles.exists(Config.AK_MODEL);
    }

    private void startGame() { launch(new Game(Config.MAP_SEEDS[selMap], selSide)); }

    private void launch(Game g) {
        hideScreen();
        Game.W_NAME[0] = rifleName();
        game = g;
        game.snd = snd;
        DevLog.i("Игра", "запуск игры" + (g.net != null ? " по сети" : "") + ", оружие: " + rifleName());
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(3);
        gl.setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        gl.setRenderer(new GameRenderer(this, game));
        gl.setPreserveEGLContextOnPause(true);
        hud = new HudView(this, game);
        hud.onMenu = this::showPause;
        root.addView(gl, new FrameLayout.LayoutParams(MATCH, MATCH));
        root.addView(hud, new FrameLayout.LayoutParams(MATCH, MATCH));
        applyVideo();
        gyro.start(game.input);
    }

    private void stopGame() {
        ui.removeCallbacks(netWatch);
        if (net != null) { net.close(); net = null; }
        gyro.stop();
        if (gl != null) { gl.onPause(); root.removeView(gl); gl = null; }
        if (hud != null) { root.removeView(hud); hud = null; }
        game = null;
    }

    private void showPause() {
        if (game == null) return;
        game.paused = true;
        gyro.stop();
        if (hud != null) hud.releaseInput();
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(0xB0000000);
        l.setClickable(true);
        TextView t = Ui.text(this, game.net != null ? "Меню  ·  игра продолжается" : "Пауза", 28, TXT, true);
        t.setGravity(Gravity.CENTER);
        l.addView(t, lp(MATCH, WRAP, 0f, 0, 0, 0, 14));
        l.addView(Ui.button(this, "ПРОДОЛЖИТЬ", v -> resumeGame()), lp(dp(280), dp(50), 0f, 0, 0, 0, 10));
        l.addView(Ui.button(this, "НАСТРОЙКИ", v -> showSettings(this::showPause)), lp(dp(280), dp(50), 0f, 0, 0, 0, 10));
        l.addView(Ui.button(this, game.net != null ? "ВЫЙТИ ИЗ КОМНАТЫ" : "В ГЛАВНОЕ МЕНЮ", v -> { stopGame(); showMain(); }), lp(dp(280), dp(50), 0f, 0, 0, 0, 0));
        showScreen(l, this::resumeGame);
    }

    private void resumeGame() {
        hideScreen();
        if (game != null) { game.paused = false; gyro.start(game.input); }
    }

    @Override
    public void onBackPressed() {
        if (onBack != null) onBack.run();
        else if (game != null) showPause();
        else super.onBackPressed();
    }

    @Override protected void onResume() { super.onResume(); if (gl != null) gl.onResume(); if (loadoutView != null) loadoutView.onResume(); }

    @Override
    protected void onPause() {
        Settings.save();
        if (game != null && screen == null) showPause();
        gyro.stop();
        if (gl != null) gl.onPause();
        if (loadoutView != null) loadoutView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        stopFinder();
        ui.removeCallbacks(netWatch);
        if (net != null) { net.close(); net = null; }
        snd.release();
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
}
