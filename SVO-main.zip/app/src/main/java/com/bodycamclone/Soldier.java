package com.bodycamclone;

public class Soldier {
    public final int team; // 0 = Украина (наши), 1 = противник
    public float x, z, yaw, hp = 100f;
    public boolean dead, moving, los, pause;
    public float deadT, walkPhase, fireCd, flash, hitFlash, strafeT, strafeDir = 1f,
            fallAngle, fallAngularVelocity, fallY = 0f, fallVy = 0f, bloodFade = 1f,
            losT, reactT, stuckT, avoidT, avoidDir = 1f;
    public int burst;
    public static final int MAG = 30;
    // ИИ: 0 = наступление/бой/следование, 3 = в укрытии (бежит туда, перезаряжается, ждёт)
    public int state, ammo = MAG, flank, slot;
    public float stateT = 1f, coverT, coverRetryT, underFire, reloadT, aimT, pathT, goalX, goalZ,
            lastSeenX, lastSeenZ, lastSeenAge = 99f, coverX, coverZ;
    public boolean hasGoal;
    /** Текущая цель: боец или игрок (tgtP). */
    public Soldier tgt;
    public boolean tgtP;
    /** Путь: точки поворота и номер текущей. */
    public final float[] wpx = new float[40], wpz = new float[40];
    public int wpN, wpI;
    // Состояние скелетной анимации (заполняет GameRenderer): текущий/предыдущий клип и плавный переход между ними.
    public GlbModel.Clip animCur, animPrev;
    public float animCurT, animPrevT, animBlend = 1f;
    /** Голова разнесена выстрелом (рисуется обрубок шеи); время последнего своего попадания в голову по сетевому бойцу; таймер фонтанчика. */
    public boolean headGone;
    public float headHitT = -99f, spurtT;

    // Сетевой игрок (мультиплеер): позицию присылает его телефон, ИИ не управляет.
    public boolean remote, netMoving, seen;
    public int netId;
    public float tx, tz, tyaw;

    public Soldier(int team, float x, float z, float yaw) {
        this.team = team; this.x = x; this.z = z; this.yaw = yaw;
    }
}
