package com.bodycamclone;

public class Soldier {
    public final int team; // 0 = Украина (наши), 1 = противник
    public float x, z, yaw, hp = 100f;
    public boolean dead, moving, los, pause;
    public float deadT, walkPhase, fireCd, flash, hitFlash, strafeT, strafeDir = 1f,
            fallAngle, fallAngularVelocity, fallY = 0f, fallVy = 0f, bloodFade = 1f,
            losT, reactT, stuckT, avoidT, avoidDir = 1f;
    public int burst;
    public static final int MAG = 30;
    // ИИ: 0 = наступление/бой/следование, 3 = в укрытии (бежит туда, перезаряжается, ждёт)
    public int state, ammo = MAG, flank, slot;
    public float stateT = 1f, coverT, coverRetryT, underFire, reloadT, aimT, pathT, goalX, goalZ,
            lastSeenX, lastSeenZ, lastSeenAge = 99f, coverX, coverZ;
    public boolean hasGoal;
    /** Текущая цель: боец или игрок (tgtP). */
    public Soldier tgt;
    public boolean tgtP;
    /** Путь: точки поворота и номер текущей. */
    public final float[] wpx = new float[40], wpz = new float[40];
    public int wpN, wpI;
    // Состояние скелетной анимации (заполняет GameRenderer): текущий/предыдущий клип и плавный переход между ними.
    public GlbModel.Clip animCur, animPrev;
    public float animCurT, animPrevT, animBlend = 1f;
    /** Голова разнесена выстрелом (рисуется обрубок шеи); время последнего своего попадания в голову по сетевому бойцу; таймер фонтанчика. */
    public boolean headGone;
    /** Откуда прилетело последнее попадание: направление полёта пули по земле, время попадания. Нужно, чтобы выбрать анимацию смерти. */
    public float hitDx, hitDz, hitAt = -99f;
    /** Выбранный клип смерти (выбирается при первой отрисовке мёртвого бойца, сбрасывается при воскрешении). */
    public GlbModel.Clip deathClip;
    public float headHitT = -99f, spurtT;

    /** Присел / лёг (приходит по сети от сетевого игрока; у ботов присед считается в рендерере по укрытию). */
    public boolean crouch, prone;
    // Состояние выбора анимации (ведёт GameRenderer): сглаженная скорость, фаза шага (в циклах), одноразовые клипы.
    public float lastX, lastZ, rvx, rvz, locoCycle, lastY, airT, lastFireT = -99f, fireStartT = -99f, hitAnimT = -1f, hitCool, reloadTotal, prevReloadT;
    public boolean hasLast, animMoving;
    /** Цель захвата (индекс точки или -1) и через сколько секунд её пересмотреть (противник). */
    public int objective = -1;
    public float objT;

    /**
     * Труп: где у него сейчас голова и бёдра в мире (пишет GameRenderer после расчёта позы), чтобы по телу можно было стрелять.
     * faceHits - попадания в голову, corpseHits - во всё тело. woundQ - новые раны (мир x,y,z, тип 1 = голова, случайное число):
     * Game кладёт, GameRenderer переводит в координаты модели и рисует; wounds - сохранённые раны (смещение от головы/бёдер).
     */
    public volatile boolean bodyKnown;
    public float headWX, headWY, headWZ, hipWX, hipWY, hipWZ;
    public int corpseHits, faceHits, woundN;
    public float spurtUntil;
    public final java.util.concurrent.ConcurrentLinkedQueue<float[]> woundQ = new java.util.concurrent.ConcurrentLinkedQueue<>();
    public final float[] wounds = new float[WOUNDS * 6];
    public static final int WOUNDS = 28;

    /** Возрождение: тело снова целое. */
    public void clearCorpse() {
        bodyKnown = false; corpseHits = 0; faceHits = 0; woundN = 0; spurtUntil = 0f; woundQ.clear();
    }

    // Сетевой игрок (мультиплеер): позицию присылает его телефон, ИИ не управляет.
    public boolean remote, netMoving, seen;
    public int netId;
    public float tx, tz, tyaw;
    /** Высота ног над землёй (у сетевого бойца - когда он в прыжке) и присланная высота. */
    public float y, ty;
    /** Наклон сетевого бойца (-1 влево .. +1 вправо) и присланное значение. */
    public float lean, tlean;

    public Soldier(int team, float x, float z, float yaw) {
        this.team = team; this.x = x; this.z = z; this.yaw = yaw;
    }
}
