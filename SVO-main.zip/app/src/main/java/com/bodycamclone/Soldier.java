package com.bodycamclone;

public class Soldier {
    public final int team; // 0 = Украина (наши), 1 = противник
    public float x, z, yaw, hp = 100f;
    public boolean dead, moving, los, pause;
    public float deadT, walkPhase, fireCd, flash, hitFlash, strafeT, strafeDir = 1f,
            fallAngle, fallAngularVelocity, fallY = 0f, fallVy = 0f, bloodFade = 1f,
            losT, reactT, stuckT, avoidT, avoidDir = 1f;
    public int burst;
    // Состояние скелетной анимации (заполняет GameRenderer): текущий/предыдущий клип и плавный переход между ними.
    public GlbModel.Clip animCur, animPrev;
    public float animCurT, animPrevT, animBlend = 1f;

    public Soldier(int team, float x, float z, float yaw) {
        this.team = team; this.x = x; this.z = z; this.yaw = yaw;
    }
}
