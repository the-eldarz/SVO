package com.bodycamclone;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

/**
 * Читает анимации из бинарных .fbx (Mixamo и подобные): только кривые поворота и перемещения костей.
 * Меши, материалы и скины не разбираются (массивы декодируются лениво, только нужные кривые).
 * Не зависит от Android, поэтому проверяется обычным JVM.
 */
final class FbxReader {
    private static final double TICKS_PER_SEC = 46186158000.0;

    /** Одна дорожка кости. path: 0 = перемещение (xyz, единицы файла), 1 = поворот (кватернион xyzw, локальный, с PreRotation). */
    static final class Track {
        String bone;
        int path;
        float[] times;   // секунды от начала клипа
        float[] vals;
    }

    /** Один «take» (AnimationStack) файла. */
    static final class Take {
        String name = "take";
        final List<Track> tracks = new ArrayList<>();
        float duration;
    }

    // ---------- низкоуровневое чтение бинарного дерева ----------
    private static final class Arr { char type; int len, enc, clen, off; }

    private static final class Node {
        String name;
        Object[] p;
        final List<Node> kids = new ArrayList<>();
        Node kid(String n) { for (Node k : kids) if (k.name.equals(n)) return k; return null; }
    }

    private final byte[] d;
    private final ByteBuffer bb;
    private int ver;

    private FbxReader(byte[] data) {
        d = data;
        bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
    }

    /** Возвращает takes файла (пустые отброшены). Бросает IOException, если это не бинарный FBX. */
    static List<Take> read(byte[] data) throws IOException {
        if (data.length < 30 || !new String(data, 0, 18, StandardCharsets.ISO_8859_1).equals("Kaydara FBX Binary"))
            throw new IOException("не бинарный FBX");
        FbxReader r = new FbxReader(data);
        return r.build();
    }

    private Node readNode() throws IOException {
        long end, np, pl;
        if (ver >= 7500) { end = bb.getLong(); np = bb.getLong(); pl = bb.getLong(); }
        else { end = bb.getInt() & 0xFFFFFFFFL; np = bb.getInt() & 0xFFFFFFFFL; pl = bb.getInt() & 0xFFFFFFFFL; }
        int nl = bb.get() & 0xFF;
        if (end == 0) return null;
        if (end > d.length) throw new IOException("битый FBX");
        Node n = new Node();
        n.name = new String(d, bb.position(), nl, StandardCharsets.ISO_8859_1);
        bb.position(bb.position() + nl);
        int propStart = bb.position();
        n.p = new Object[(int) np];
        for (int i = 0; i < np; i++) n.p[i] = readProp();
        bb.position((int) (propStart + pl));
        while (bb.position() < end) {
            Node k = readNode();
            if (k == null) break;
            n.kids.add(k);
        }
        bb.position((int) end);
        return n;
    }

    private Object readProp() throws IOException {
        char t = (char) (bb.get() & 0xFF);
        switch (t) {
            case 'Y': return (long) bb.getShort();
            case 'C': return (long) bb.get();
            case 'I': return (long) bb.getInt();
            case 'F': return (double) bb.getFloat();
            case 'D': return bb.getDouble();
            case 'L': return bb.getLong();
            case 'S': {
                int len = bb.getInt();
                String s = new String(d, bb.position(), len, StandardCharsets.ISO_8859_1);
                bb.position(bb.position() + len);
                return s;
            }
            case 'R': { int len = bb.getInt(); bb.position(bb.position() + len); return null; }
            case 'f': case 'd': case 'l': case 'i': case 'b': {
                Arr a = new Arr();
                a.type = t; a.len = bb.getInt(); a.enc = bb.getInt(); a.clen = bb.getInt(); a.off = bb.position();
                int size = (t == 'd' || t == 'l') ? 8 : (t == 'b' ? 1 : 4);
                bb.position(a.off + (a.enc == 1 ? a.clen : a.len * size));
                return a;
            }
            default: throw new IOException("неизвестный тип свойства " + t);
        }
    }

    /** Декодирует числовой массив в double[] (float/double/int/long). */
    private double[] nums(Object o) throws IOException {
        if (!(o instanceof Arr)) return new double[0];
        Arr a = (Arr) o;
        int size = (a.type == 'd' || a.type == 'l') ? 8 : (a.type == 'b' ? 1 : 4);
        byte[] raw;
        int off;
        if (a.enc == 1) {
            raw = new byte[a.len * size];
            Inflater inf = new Inflater();
            inf.setInput(d, a.off, a.clen);
            try {
                int got = 0;
                while (got < raw.length) {
                    int n = inf.inflate(raw, got, raw.length - got);
                    if (n == 0 && (inf.finished() || inf.needsInput() || inf.needsDictionary())) break;
                    got += n;
                }
            } catch (DataFormatException e) { throw new IOException("битый zlib в FBX"); }
            finally { inf.end(); }
            off = 0;
        } else { raw = d; off = a.off; }
        ByteBuffer b = ByteBuffer.wrap(raw, off, a.len * size).order(ByteOrder.LITTLE_ENDIAN);
        double[] r = new double[a.len];
        for (int i = 0; i < a.len; i++) {
            switch (a.type) {
                case 'f': r[i] = b.getFloat(); break;
                case 'd': r[i] = b.getDouble(); break;
                case 'l': r[i] = b.getLong(); break;
                case 'i': r[i] = b.getInt(); break;
                default: r[i] = b.get();
            }
        }
        return r;
    }

    // ---------- разбор сцены ----------
    private static final class Model { String name; double[] pre = {0, 0, 0}, post = {0, 0, 0}, rot = {0, 0, 0}, tr = {0, 0, 0}; int order; }
    private static final class Curve { double[] t, v; }
    private static final class CNode { long model = -1; String prop = ""; final Curve[] c = new Curve[3]; final double[] def = {Double.NaN, Double.NaN, Double.NaN}; long layer = -1; }

    private static String objName(Object o) {
        if (!(o instanceof String)) return "";
        String s = (String) o;
        int i = s.indexOf('\0');
        if (i >= 0) return s.substring(0, i);
        i = s.indexOf("::");
        return i >= 0 ? s.substring(i + 2) : s;
    }

    private static long id(Object[] p) { return p.length > 0 && p[0] instanceof Long ? (Long) p[0] : -1L; }

    private static double[] vec(Node props, String name, double[] def) {
        if (props == null) return def;
        for (Node q : props.kids) {
            if (q.p.length >= 7 && name.equals(q.p[0]) && q.p[4] instanceof Number) {
                return new double[]{((Number) q.p[4]).doubleValue(), ((Number) q.p[5]).doubleValue(), ((Number) q.p[6]).doubleValue()};
            }
        }
        return def;
    }

    private static int intProp(Node props, String name, int def) {
        if (props == null) return def;
        for (Node q : props.kids) if (q.p.length >= 5 && name.equals(q.p[0]) && q.p[4] instanceof Number) return ((Number) q.p[4]).intValue();
        return def;
    }

    private static double num(Node props, String name, double def) {
        if (props == null) return def;
        for (Node q : props.kids) if (q.p.length >= 5 && name.equals(q.p[0]) && q.p[4] instanceof Number) return ((Number) q.p[4]).doubleValue();
        return def;
    }

    private List<Take> build() throws IOException {
        ver = bb.getInt(23);
        bb.position(27);
        Node objects = null, conns = null;
        while (bb.remaining() >= (ver >= 7500 ? 25 : 13)) {
            Node n = readNode();
            if (n == null) break;
            if (n.name.equals("Objects")) objects = n;
            else if (n.name.equals("Connections")) conns = n;
        }
        if (objects == null || conns == null) throw new IOException("в FBX нет Objects/Connections");

        Map<Long, Model> models = new HashMap<>();
        Map<Long, CNode> cnodes = new HashMap<>();
        Map<Long, Curve> curves = new HashMap<>();
        Map<Long, Node> curveRaw = new HashMap<>();
        Map<Long, String> stackName = new LinkedHashMap<>();
        Map<Long, Long> layerStack = new HashMap<>();
        for (Node o : objects.kids) {
            long oid = id(o.p);
            String nm = o.p.length > 1 ? objName(o.p[1]) : "";
            switch (o.name) {
                case "Model": {
                    Model m = new Model();
                    m.name = nm;
                    Node pr = o.kid("Properties70");
                    m.pre = vec(pr, "PreRotation", m.pre);
                    m.post = vec(pr, "PostRotation", m.post);
                    m.rot = vec(pr, "Lcl Rotation", m.rot);
                    m.tr = vec(pr, "Lcl Translation", m.tr);
                    m.order = intProp(pr, "RotationOrder", 0);
                    models.put(oid, m);
                    break;
                }
                case "AnimationStack": stackName.put(oid, nm.isEmpty() ? "take" : nm); break;
                case "AnimationLayer": layerStack.put(oid, -1L); break;
                case "AnimationCurveNode": {
                    CNode c = new CNode();
                    Node pr = o.kid("Properties70");
                    c.def[0] = num(pr, "d|X", Double.NaN); c.def[1] = num(pr, "d|Y", Double.NaN); c.def[2] = num(pr, "d|Z", Double.NaN);
                    cnodes.put(oid, c);
                    break;
                }
                case "AnimationCurve": curveRaw.put(oid, o); break;
                default: break;
            }
        }
        for (Node c : conns.kids) {
            if (!c.name.equals("C") || c.p.length < 3 || !(c.p[1] instanceof Long) || !(c.p[2] instanceof Long)) continue;
            long ch = (Long) c.p[1], pa = (Long) c.p[2];
            String prop = c.p.length > 3 && c.p[3] instanceof String ? (String) c.p[3] : "";
            CNode cn = cnodes.get(ch);
            if (cn != null) {
                if (models.containsKey(pa)) { cn.model = pa; cn.prop = prop; }
                else if (layerStack.containsKey(pa)) cn.layer = pa;
                continue;
            }
            if (curveRaw.containsKey(ch) && cnodes.containsKey(pa)) {
                int ax = prop.endsWith("X") ? 0 : prop.endsWith("Y") ? 1 : prop.endsWith("Z") ? 2 : -1;
                if (ax < 0) continue;
                Curve cu = curves.get(ch);
                if (cu == null) {
                    Node raw = curveRaw.get(ch);
                    cu = new Curve();
                    Node kt = raw.kid("KeyTime"), kv = raw.kid("KeyValueFloat");
                    if (kv == null) kv = raw.kid("KeyValueDouble");
                    if (kt == null || kv == null || kt.p.length == 0 || kv.p.length == 0) continue;
                    double[] tt = nums(kt.p[0]), vv = nums(kv.p[0]);
                    int n = Math.min(tt.length, vv.length);
                    if (n == 0) continue;
                    cu.t = new double[n]; cu.v = new double[n];
                    for (int i = 0; i < n; i++) { cu.t[i] = tt[i] / TICKS_PER_SEC; cu.v[i] = vv[i]; }
                    curves.put(ch, cu);
                }
                cnodes.get(pa).c[ax] = cu;
            } else if (layerStack.containsKey(ch) && stackName.containsKey(pa)) {
                layerStack.put(ch, pa);
            }
        }

        // группировка по stack
        Map<Long, Take> takes = new LinkedHashMap<>();
        Map<Take, Double> start = new HashMap<>();
        for (CNode cn : cnodes.values()) {
            Model m = models.get(cn.model);
            if (m == null || (cn.c[0] == null && cn.c[1] == null && cn.c[2] == null)) continue;
            boolean isT = cn.prop.equals("Lcl Translation"), isR = cn.prop.equals("Lcl Rotation");
            if (!isT && !isR) continue;
            long sid = cn.layer >= 0 && layerStack.containsKey(cn.layer) ? layerStack.get(cn.layer) : -1L;
            Take tk = takes.get(sid);
            if (tk == null) {
                tk = new Take();
                if (stackName.containsKey(sid)) tk.name = stackName.get(sid);
                takes.put(sid, tk);
            }
            Track tr = sample(m, cn, isR);
            if (tr == null) continue;
            tk.tracks.add(tr);
        }
        List<Take> out = new ArrayList<>();
        for (Take tk : takes.values()) {
            if (tk.tracks.isEmpty()) continue;
            double t0 = Double.MAX_VALUE, t1 = -Double.MAX_VALUE;
            for (Track t : tk.tracks) { t0 = Math.min(t0, t.times[0]); t1 = Math.max(t1, t.times[t.times.length - 1]); }
            for (Track t : tk.tracks) for (int i = 0; i < t.times.length; i++) t.times[i] -= (float) t0;
            tk.duration = (float) (t1 - t0);
            if (tk.duration > 1e-4f) out.add(tk);
        }
        return out;
    }

    /** Склеивает кривые X/Y/Z на общей сетке времени и считает кватернионы (для поворота) или значения (для перемещения). */
    private Track sample(Model m, CNode cn, boolean rot) {
        int total = 0;
        for (Curve c : cn.c) if (c != null) total += c.t.length;
        double[] grid = new double[total];
        int gi = 0;
        for (Curve c : cn.c) if (c != null) { System.arraycopy(c.t, 0, grid, gi, c.t.length); gi += c.t.length; }
        Arrays.sort(grid);
        int n = 0;
        for (int i = 0; i < grid.length; i++) if (n == 0 || grid[i] - grid[n - 1] > 1e-6) grid[n++] = grid[i];
        if (n == 0) return null;
        double[] base = rot ? m.rot : m.tr;
        int[] ptr = new int[3];
        Track t = new Track();
        t.bone = m.name; t.path = rot ? 1 : 0;
        t.times = new float[n];
        t.vals = new float[n * (rot ? 4 : 3)];
        double[] e = new double[3];
        double[] prevQ = null;
        for (int i = 0; i < n; i++) {
            double tm = grid[i];
            t.times[i] = (float) tm;
            for (int a = 0; a < 3; a++) {
                Curve c = cn.c[a];
                if (c == null) { e[a] = Double.isNaN(cn.def[a]) ? base[a] : cn.def[a]; continue; }
                int k = ptr[a];
                while (k + 1 < c.t.length && c.t[k + 1] <= tm + 1e-9) k++;
                ptr[a] = k;
                if (tm <= c.t[0]) e[a] = c.v[0];
                else if (k + 1 >= c.t.length) e[a] = c.v[c.t.length - 1];
                else {
                    double f = (tm - c.t[k]) / (c.t[k + 1] - c.t[k]);
                    e[a] = c.v[k] + (c.v[k + 1] - c.v[k]) * f;
                }
            }
            if (!rot) { for (int a = 0; a < 3; a++) t.vals[i * 3 + a] = (float) e[a]; continue; }
            double[] q = qmul(qmul(euler(m.pre, 0), euler(e, m.order)), qconj(euler(m.post, 0)));
            if (prevQ != null && q[0] * prevQ[0] + q[1] * prevQ[1] + q[2] * prevQ[2] + q[3] * prevQ[3] < 0) { for (int k = 0; k < 4; k++) q[k] = -q[k]; }
            prevQ = q;
            for (int k = 0; k < 4; k++) t.vals[i * 4 + k] = (float) q[k];
        }
        return t;
    }

    // ---------- кватернионы (x, y, z, w) ----------
    private static double[] axisQ(int axis, double deg) {
        double h = Math.toRadians(deg) * 0.5, s = Math.sin(h);
        double[] q = {0, 0, 0, Math.cos(h)};
        q[axis] = s;
        return q;
    }

    /** Углы Эйлера FBX (градусы) -> кватернион. Порядок eEulerXYZ(0) = сначала X, потом Y, потом Z, то есть R = Rz*Ry*Rx. */
    static double[] euler(double[] deg, int order) {
        int[][] ords = {{0, 1, 2}, {0, 2, 1}, {1, 2, 0}, {1, 0, 2}, {2, 0, 1}, {2, 1, 0}};
        int[] o = ords[order >= 0 && order < 6 ? order : 0];
        double[] q = axisQ(o[0], deg[o[0]]);
        q = qmul(axisQ(o[1], deg[o[1]]), q);
        q = qmul(axisQ(o[2], deg[o[2]]), q);
        return q;
    }

    private static double[] qconj(double[] q) { return new double[]{-q[0], -q[1], -q[2], q[3]}; }

    /** a * b (сначала b, потом a). */
    private static double[] qmul(double[] a, double[] b) {
        return new double[]{
                a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
                a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
                a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
                a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]};
    }
}
