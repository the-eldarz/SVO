package com.bodycamclone;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Кэш игры: тяжёлые файлы (модели .glb, анимации) лежат не в APK, а в обычной папке на телефоне
 * (внутри неё папки models/ и user_files/). Игрок один раз выбирает эту папку в игре через системное
 * окно «Файлы», выбор запоминается. Файлы читаются прямо из неё, без копирования.
 * Все чтения идут через {@link #open(String)}: сначала из кэша, если там нет - из assets внутри APK.
 */
final class GameFiles {
    private GameFiles() {}

    private static final String TAG = "Кэш";
    private static final String PREFS = "bodycam_cache", K_TREE = "tree", K_ROOT = "root";
    private static final String[] COLS = {DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE};

    private static Context app;
    private static AssetManager assets;
    private static Uri tree;          // дерево, выбранное игроком
    private static String rootId;     // документ папки, в которой лежат models/ и user_files/
    private static volatile Map<String, String> index;   // "models/x.glb" -> id документа

    static void init(Context c) {
        app = c.getApplicationContext();
        assets = app.getAssets();
        SharedPreferences sp = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String t = sp.getString(K_TREE, null);
        tree = t == null ? null : Uri.parse(t);
        rootId = sp.getString(K_ROOT, null);
    }

    // ---------- состояние ----------

    private static boolean hasPermission() {
        if (tree == null) return false;
        for (UriPermission p : app.getContentResolver().getPersistedUriPermissions()) {
            if (p.getUri().equals(tree) && p.isReadPermission()) return true;
        }
        return false;
    }

    /** Кэш выбран, доступ к папке сохранён и папка не пуста (дёшево: один запрос). */
    static boolean isReady() {
        if (tree == null || rootId == null || !hasPermission()) return false;
        try (Cursor q = children(rootId)) { return q != null && q.getCount() > 0; } catch (Throwable e) { return false; }
    }

    /** Понятный путь выбранной папки, например "primary:BodycamGame". */
    static String describe() { return rootId == null ? "не выбран" : rootId; }

    /** Заранее читает список файлов кэша (вызывать из фонового потока). */
    static void warmUp() { ensureIndex(); }

    // ---------- работа с папкой ----------

    private static Cursor children(String docId) {
        Uri u = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        return app.getContentResolver().query(u, COLS, null, null, null);
    }

    private static List<String[]> list(String docId) {
        List<String[]> kids = new ArrayList<>();
        try (Cursor q = children(docId)) {
            if (q != null) while (q.moveToNext()) kids.add(new String[]{q.getString(0), q.getString(1), q.getString(2)});
        } catch (Throwable e) {
            DevLog.e(TAG, "не удалось прочитать папку " + docId, e);
        }
        return kids;
    }

    private static boolean isDir(String mime) { return DocumentsContract.Document.MIME_TYPE_DIR.equals(mime); }

    private static void walk(String docId, String rel, Map<String, String> out) {
        for (String[] k : list(docId)) {
            if (k[1] == null) continue;
            String p = rel.isEmpty() ? k[1] : rel + "/" + k[1];
            if (isDir(k[2])) walk(k[0], p, out); else out.put(p, k[0]);
        }
    }

    /** Ищет папку, где лежат models/ или user_files/ (допускается лишняя вложенная папка до 2 уровней). */
    private static String findRoot(String docId, int depth) {
        List<String[]> kids = list(docId);
        for (String[] k : kids) {
            if (isDir(k[2]) && k[1] != null && (k[1].equals("models") || k[1].equals("user_files"))) return docId;
        }
        if (depth > 0) {
            for (String[] k : kids) {
                if (!isDir(k[2])) continue;
                String r = findRoot(k[0], depth - 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static synchronized Map<String, String> ensureIndex() {
        if (index == null && tree != null && rootId != null) {
            Map<String, String> m = new HashMap<>();
            try { walk(rootId, "", m); } catch (Throwable e) { DevLog.e(TAG, "ошибка чтения кэша", e); }
            index = m;
            DevLog.i(TAG, "кэш: файлов " + m.size() + ", папка " + rootId);
        }
        return index;
    }

    /** Запоминает выбранную папку кэша. Возвращает число файлов в ней. Вызывать из фонового потока. */
    static synchronized int setTree(Uri treeUri) throws IOException {
        try {
            app.getContentResolver().takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Throwable e) {
            throw new IOException("Нет доступа к выбранной папке. Выбери другую");
        }
        Uri old = tree;
        tree = treeUri;
        String id = findRoot(DocumentsContract.getTreeDocumentId(treeUri), 2);
        if (id == null) {
            tree = old;
            try { app.getContentResolver().releasePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Throwable ignored) { }
            throw new IOException("В этой папке нет подпапки models. Выбери папку кэша, внутри которой лежат models и user_files");
        }
        Map<String, String> m = new HashMap<>();
        walk(id, "", m);
        if (m.isEmpty()) {
            tree = old;
            throw new IOException("Папка кэша пустая");
        }
        rootId = id;
        index = m;
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(K_TREE, treeUri.toString()).putString(K_ROOT, id).apply();
        DevLog.i(TAG, "выбран кэш: " + id + ", файлов " + m.size());
        return m.size();
    }

    // ---------- чтение ----------

    static boolean exists(String path) {
        Map<String, String> m = ensureIndex();
        if (m != null && m.containsKey(path)) return true;
        try (InputStream in = assets.open(path)) { return true; } catch (IOException e) { return false; }
    }

    /** Открывает файл по пути вида "models/x.glb": из кэша, иначе из assets. FileNotFoundException, если нет нигде. */
    static InputStream open(String path) throws IOException {
        Map<String, String> m = ensureIndex();
        String id = m == null ? null : m.get(path);
        if (id != null) {
            InputStream in = app.getContentResolver().openInputStream(DocumentsContract.buildDocumentUriUsingTree(tree, id));
            if (in != null) return in;
            throw new FileNotFoundException(path);
        }
        return assets.open(path);
    }

    /** Все файлы под папкой dir (рекурсивно) из кэша и из assets, пути относительные: "user_files/a/b.fbx". */
    static Set<String> listFiles(String dir) {
        Set<String> out = new LinkedHashSet<>();
        Map<String, String> m = ensureIndex();
        if (m != null) for (String k : m.keySet()) if (k.startsWith(dir + "/")) out.add(k);
        try { scanAssets(dir, out); } catch (IOException ignored) { }
        return out;
    }

    private static void scanAssets(String path, Set<String> out) throws IOException {
        String[] entries = assets.list(path);
        if (entries == null) return;
        for (String entry : entries) {
            String child = path + "/" + entry;
            String[] nested = assets.list(child);
            if (nested != null && nested.length > 0) scanAssets(child, out); else out.add(child);
        }
    }
}
