package com.bodycamclone;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Две карты (Config.MAP_NAMES): 0 - Большой лес (процедурный), 1 - арена из CS:S (zm_opt_tr, перенесена из BSP).
 * На каждой: три точки захвата A/B/C с пунктами снабжения и по пункту на базе каждой стороны (юг - наши, север - противник).
 */
public class WorldMap {
    public static final class Box {
        public final float x0, y0, z0, x1, y1, z1, r, g, b;
        public final int mode;          // 0 плоский, 1 земля, 2 стена
        public final boolean block;     // блокирует пули и обзор
        public final boolean collide;   // блокирует движение
        Box(float x0, float y0, float z0, float x1, float y1, float z1, float r, float g, float b, int mode, boolean block) {
            this.x0 = x0; this.y0 = y0; this.z0 = z0; this.x1 = x1; this.y1 = y1; this.z1 = z1;
            this.r = r; this.g = g; this.b = b; this.mode = mode; this.block = block;
            this.collide = block && y0 < 1.5f && y1 > 0.3f;
        }
    }

    /** Блиндаж. x0..z1 - внутренняя часть (пол). Пополнять припасы можно внутри, если он «свой». */
    public static final class Bunker {
        public final float cx, cz, x0, z0, x1, z1;
        public final int point;      // индекс точки захвата или -1
        public final int baseTeam;   // 0 / 1 - блиндаж на базе этой команды, иначе -1
        Bunker(float cx, float cz, float x0, float z0, float x1, float z1, int point, int baseTeam) {
            this.cx = cx; this.cz = cz; this.x0 = x0; this.z0 = z0; this.x1 = x1; this.z1 = z1;
            this.point = point; this.baseTeam = baseTeam;
        }
        public boolean contains(float x, float z) { return x > x0 && x < x1 && z > z0 && z < z1; }
    }

    /** Точка захвата. cap: +1 - полностью наша (команда 0), -1 - противника (команда 1). owner: -1 ничья, 0 наша, 1 противника. */
    public static final class Point {
        public static final float RADIUS = 8f;
        public final int id;
        public final float x, z;
        public final Bunker bunker;
        public float cap;
        public int owner = -1;
        Point(int id, Bunker b) { this.id = id; this.bunker = b; this.x = b.cx; this.z = b.cz; }
        public char letter() { return (char) ('A' + id); }
    }

    public final List<Box> boxes = new ArrayList<>();
    /** Только то, что мешает ходить (стены, укрытия, стволы деревьев): по ним считаются столкновения и сетка проходимости. */
    public final List<Box> solid = new ArrayList<>();
    public final List<float[]> enemySpawns = new ArrayList<>();
    public final List<float[]> allySpawns = new ArrayList<>();
    public final float[] playerSpawn = {0f, 42f};
    public final List<Point> points = new ArrayList<>();
    public final List<Bunker> bunkers = new ArrayList<>();
    /** Половина стороны карты, дальность тумана и дальность отрисовки (в лесу меньше - лес плотный). */
    public final float half, fog, cull;
    public final int index;

    private final List<float[]> buildings = new ArrayList<>();
    private final List<float[]> placed = new ArrayList<>();
    private final List<float[]> zones = new ArrayList<>();   // {x, z, r}: здесь ничего лишнего не ставим
    private final Random rnd;
    private final float H;
    private boolean forestTrails;

    public WorldMap(long seed) {
        index = Config.mapIndex(seed);
        half = Config.mapHalf(index);
        H = half;
        fog = index == 0 ? 70f : 110f;
        cull = index == 0 ? 85f : 130f;
        rnd = new Random(seed);
        build();
    }

    private void add(float x0, float y0, float z0, float x1, float y1, float z1, float r, float g, float b, int mode, boolean block) {
        Box bx = new Box(x0, y0, z0, x1, y1, z1, r, g, b, mode, block);
        boxes.add(bx);
        if (bx.collide) solid.add(bx);
    }

    private void build() {
        switch (index) {
            case 1: cssArena(); break;
            default: forest(); break;
        }
        if (enemySpawns.isEmpty()) enemySpawns.add(new float[]{0f, -H + 6f});
        if (allySpawns.isEmpty()) allySpawns.add(new float[]{0f, H - 6f});
    }

    // ---------- общие части карты ----------

    private void ground(float r, float g, float b) { add(-H - 12, -1f, -H - 12, H + 12, 0f, H + 12, r, g, b, 1, false); }

    private void border(float r, float g, float b, float wh) {
        float t = 1.5f;
        add(-H - t, 0, -H - t, H + t, wh, -H, r, g, b, 2, true);
        add(-H - t, 0, H, H + t, wh, H + t, r, g, b, 2, true);
        add(-H - t, 0, -H, -H, wh, H, r, g, b, 2, true);
        add(H, 0, -H, H + t, wh, H, r, g, b, 2, true);
    }

    private void road(float x0, float z0, float x1, float z1, float r, float g, float b) {
        add(x0, 0, z0, x1, 0.03f, z1, r, g, b, 0, false);
    }

    /** Ящик, повёрнутый на 90 градусов при sw. */
    private void xz(boolean sw, float cx, float cz, float hx, float hz, float y0, float y1, float r, float g, float b) {
        float a = sw ? hz : hx, c = sw ? hx : hz;
        add(cx - a, y0, cz - c, cx + a, y1, cz + c, r, g, b, 0, true);
    }

    /** Мешки с песком (низкая стенка). */
    private void sandWall(float cx, float cz, float len, boolean alongX) {
        float hx = alongX ? len / 2 : 0.4f, hz = alongX ? 0.4f : len / 2;
        add(cx - hx, 0, cz - hz, cx + hx, 0.95f, cz + hz, .62f, .55f, .38f, 0, true);
    }

    /** Коробка в системе блиндажа: lx - вдоль фасада, lz - от центра наружу (в сторону двери f). */
    private void lbox(float cx, float cz, float fx, float fz, float lx0, float lx1, float lz0, float lz1, float y0, float y1,
                      float r, float g, float b, int mode, boolean block) {
        float rx = -fz, rz = fx;
        float ax = cx + lx0 * rx + lz0 * fx, az = cz + lx0 * rz + lz0 * fz;
        float bx = cx + lx1 * rx + lz1 * fx, bz = cz + lx1 * rz + lz1 * fz;
        add(Math.min(ax, bx), y0, Math.min(az, bz), Math.max(ax, bx), y1, Math.max(az, bz), r, g, b, mode, block);
    }

    /**
     * Блиндаж: земляные стены с амбразурами, накат из брёвен, земляная насыпь сверху, мешки с песком у входа.
     * Внутри ящики с патронами и аптечка. (fx,fz) - куда смотрит главный вход; backDoor - второй вход с противоположной стороны.
     */
    private Bunker bunker(float cx, float cz, float fx, float fz, boolean backDoor, int point, int baseTeam) {
        final float IW = 3.2f, ID = 2.4f, T = 0.7f, DH = 1.15f;
        final float[] earth = {.36f, .29f, .20f}, timber = {.28f, .20f, .12f}, logs = {.38f, .26f, .14f}, mound = {.30f, .36f, .18f}, sand = {.62f, .55f, .38f};
        lbox(cx, cz, fx, fz, -IW - .3f, IW + .3f, -ID - .3f, ID + .3f, 0f, 0.04f, .27f, .22f, .16f, 0, false);              // пол
        lbox(cx, cz, fx, fz, -IW - T, -IW, -ID - T, ID + T, 0f, 2.3f, earth[0], earth[1], earth[2], 2, true);              // боковые стены
        lbox(cx, cz, fx, fz, IW, IW + T, -ID - T, ID + T, 0f, 2.3f, earth[0], earth[1], earth[2], 2, true);
        for (int side = 0; side < 2; side++) {                                                                               // фасад и тыл
            if (side == 1 && !backDoor) {
                lbox(cx, cz, fx, fz, -IW - T, IW + T, -ID - T, -ID, 0f, 2.3f, earth[0], earth[1], earth[2], 2, true);
                continue;
            }
            float z0 = side == 0 ? ID : -ID - T, z1 = side == 0 ? ID + T : -ID;
            for (int s = -1; s <= 1; s += 2) {
                float a = s < 0 ? -IW - T : DH, b = s < 0 ? -DH : IW + T;
                lbox(cx, cz, fx, fz, a, b, z0, z1, 0f, 1.2f, earth[0], earth[1], earth[2], 2, true);                    // ниже амбразуры
                lbox(cx, cz, fx, fz, a, b, z0, z1, 1.9f, 2.3f, earth[0], earth[1], earth[2], 2, true);                  // выше амбразуры (щель 1.2-1.9 м)
            }
            lbox(cx, cz, fx, fz, -DH, DH, z0, z1, 2.05f, 2.3f, timber[0], timber[1], timber[2], 2, true);               // перемычка над дверью
        }
        lbox(cx, cz, fx, fz, -IW - T - .45f, IW + T + .45f, -ID - T - .45f, ID + T + .45f, 2.3f, 2.75f, logs[0], logs[1], logs[2], 0, true);   // накат
        lbox(cx, cz, fx, fz, -IW - T - .2f, IW + T + .2f, -ID - T - .2f, ID + T + .2f, 2.75f, 3.1f, mound[0], mound[1], mound[2], 0, true);   // насыпь
        for (int side = 0; side < (backDoor ? 2 : 1); side++) {                                                              // мешки у входов
            float sg = side == 0 ? 1f : -1f, za = sg * (ID + T + .45f), zb = sg * (ID + T + 1.05f);
            lbox(cx, cz, fx, fz, -IW - T, -DH - .55f, Math.min(za, zb), Math.max(za, zb), 0f, 0.9f, sand[0], sand[1], sand[2], 0, true);
            lbox(cx, cz, fx, fz, DH + .55f, IW + T, Math.min(za, zb), Math.max(za, zb), 0f, 0.9f, sand[0], sand[1], sand[2], 0, true);
        }
        // внутри: ящики с патронами у задней стены, аптечка у фасада
        lbox(cx, cz, fx, fz, -IW + .05f, -IW + .85f, -ID + .1f, -ID + .9f, 0f, .55f, .27f, .33f, .20f, 0, true);
        lbox(cx, cz, fx, fz, -IW + .2f, -IW + .7f, -ID + .25f, -ID + .75f, .55f, 1.0f, .24f, .30f, .18f, 0, true);
        lbox(cx, cz, fx, fz, IW - .85f, IW - .05f, -ID + .1f, -ID + .7f, 0f, .5f, .45f, .33f, .20f, 0, true);
        lbox(cx, cz, fx, fz, -IW + .1f, -IW + .8f, ID - .8f, ID - .1f, 0f, .45f, .90f, .90f, .88f, 0, true);
        lbox(cx, cz, fx, fz, -IW + .4f, -IW + .5f, ID - .65f, ID - .25f, .45f, .47f, .8f, .1f, .1f, 0, false);
        lbox(cx, cz, fx, fz, -IW + .2f, -IW + .7f, ID - .5f, ID - .4f, .45f, .47f, .8f, .1f, .1f, 0, false);

        float rx = -fz, rz = fx;
        float ax = cx - IW * rx - ID * fx, az = cz - IW * rz - ID * fz, bx = cx + IW * rx + ID * fx, bz = cz + IW * rz + ID * fz;
        Bunker bk = new Bunker(cx, cz, Math.min(ax, bx), Math.min(az, bz), Math.max(ax, bx), Math.max(az, bz), point, baseTeam);
        bunkers.add(bk);
        zones.add(new float[]{cx, cz, 9f});
        return bk;
    }

    /** Базы: блиндаж нашей стороны на юге (дверь на север), противника на севере (дверь на юг). Игрок появляется внутри своего. */
    private void bases() {
        float zc = H - 5.5f;
        bunker(0f, zc, 0f, -1f, false, -1, 0);
        bunker(0f, -zc, 0f, 1f, false, -1, 1);
        playerSpawn[0] = 0f; playerSpawn[1] = zc;
        float[][] as = {{-2f, zc}, {2f, zc}, {-1.6f, zc + 1.4f}, {1.6f, zc + 1.4f}, {-4.5f, zc - 6.5f}, {4.5f, zc - 6.5f},
                {0f, zc - 7.5f}, {-8f, zc - 6f}, {8f, zc - 6f}};
        for (float[] a : as) if (!blocked(a[0], a[1], 0.7f)) allySpawns.add(a);
        float[][] es = {{-2f, -zc}, {2f, -zc}, {-1.6f, -zc - 1.4f}, {1.6f, -zc - 1.4f}};
        for (float[] e : es) if (!blocked(e[0], e[1], 0.7f)) enemySpawns.add(e);
        for (int i = 0; i < 80 && enemySpawns.size() < 34; i++) {
            float x = (rnd.nextFloat() * 2f - 1f) * (H * 0.82f), z = -H + 3f + rnd.nextFloat() * 6f;
            if (!blocked(x, z, 0.7f)) enemySpawns.add(new float[]{x, z});
        }
    }

    /** Три точки A, B, C слева направо, каждая - блиндаж с двумя входами (север и юг) и мешками вокруг. */
    private void pointsAt(float[][] pos) {
        for (int i = 0; i < pos.length; i++) {
            Bunker bk = bunker(pos[i][0], pos[i][1], 0f, 1f, true, i, -1);
            points.add(new Point(i, bk));
            float x = pos[i][0], z = pos[i][1];
            sandWall(x - 8.5f, z, 4.5f, false);
            sandWall(x + 8.5f, z, 4.5f, false);
            sandWall(x - 4.2f, z - 7.2f, 4.5f, true);
            sandWall(x + 4.2f, z - 7.2f, 4.5f, true);
            sandWall(x - 4.2f, z + 7.2f, 4.5f, true);
            sandWall(x + 4.2f, z + 7.2f, 4.5f, true);
        }
    }

    // ---------- здания ----------

    private void building(float cx, float cz, float w, float d, float h, float doorW, float doorH, float winW, int crates, float[] col) {
        float th = 0.3f;
        float x0 = cx - w / 2, x1 = cx + w / 2, z0 = cz - d / 2, z1 = cz + d / 2;
        float v = (rnd.nextFloat() - 0.5f) * 0.12f;
        float r = (col != null ? col[0] : .62f) + v, g = (col != null ? col[1] : .58f) + v, b = (col != null ? col[2] : .50f) + v;
        buildings.add(new float[]{x0, z0, x1, z1});
        wall(true, x0, x1, z1, th, h, ops(true, doorW, winW), doorH, r, g, b);
        wall(true, x0, x1, z0, th, h, ops(rnd.nextBoolean(), doorW, winW), doorH, r, g, b);
        wall(false, z0, z1, x0, th, h, ops(false, doorW, winW), doorH, r, g, b);
        wall(false, z0, z1, x1, th, h, ops(false, doorW, winW), doorH, r, g, b);
        add(x0 - 0.25f, h, z0 - 0.25f, x1 + 0.25f, h + 0.3f, z1 + 0.25f, .30f, .26f, .24f, 0, true);
        for (int i = 0; i < crates; i++) {
            float px = x0 + 1.8f + rnd.nextFloat() * (w - 3.6f), pz = z0 + 1.8f + rnd.nextFloat() * (d - 3.6f);
            float s = 0.9f + rnd.nextFloat() * 0.4f;
            add(px - s / 2, 0, pz - s / 2, px + s / 2, s, pz + s / 2, .45f, .33f, .2f, 0, true);
        }
    }

    private float[][] ops(boolean door, float doorW, float winW) {
        int doorSlot = rnd.nextInt(2);
        float[][] o = new float[2][];
        for (int i = 0; i < 2; i++) {
            float frac = i == 0 ? 0.22f : 0.72f;
            if (door && i == doorSlot) o[i] = new float[]{frac, doorW, 0};
            else o[i] = new float[]{frac, winW, 1};
        }
        if (!door && rnd.nextFloat() < 0.3f) return new float[][]{o[rnd.nextInt(2)]};
        return o;
    }

    private void wall(boolean ax, float a0, float a1, float c, float th, float h, float[][] op, float doorH, float r, float g, float b) {
        float cur = a0, len = a1 - a0;
        for (float[] o : op) {
            float mid = a0 + o[0] * len, s = mid - o[1] / 2, e = mid + o[1] / 2;
            if (s > cur) seg(ax, cur, s, c, th, 0, h, r, g, b);
            if (o[2] == 0) seg(ax, s, e, c, th, doorH, h, r, g, b);
            else { seg(ax, s, e, c, th, 0, 1.0f, r, g, b); seg(ax, s, e, c, th, 2.1f, h, r, g, b); }
            cur = e;
        }
        if (cur < a1) seg(ax, cur, a1, c, th, 0, h, r, g, b);
    }

    private void seg(boolean ax, float a0, float a1, float c, float th, float y0, float y1, float r, float g, float b) {
        if (ax) add(a0, y0, c - th / 2, a1, y1, c + th / 2, r, g, b, 2, true);
        else add(c - th / 2, y0, a0, c + th / 2, y1, a1, r, g, b, 2, true);
    }

    /** Можно ли поставить здание: вдали от блиндажей и других зданий, не на базе. */
    private boolean houseOk(float cx, float cz, float w, float d) {
        float rad = Math.max(w, d) / 2f + 1.5f;
        if (Math.abs(cx) > H - 8f || Math.abs(cz) > H - 14f) return false;
        for (float[] zn : zones) if (Math.hypot(cx - zn[0], cz - zn[1]) < zn[2] + rad) return false;
        for (float[] b : buildings)
            if (cx + w / 2 + 3 > b[0] && cx - w / 2 - 3 < b[2] && cz + d / 2 + 3 > b[1] && cz - d / 2 - 3 < b[3]) return false;
        return true;
    }

    /** Свободна ли точка для мелочи (укрытие, дерево, камень) на расстоянии clr от другой мелочи. */
    private boolean okSpot(float x, float z, float clr) {
        if (Math.abs(x) > H - 3f || Math.abs(z) > H - 3f || Math.abs(z) > H - 12f && Math.abs(x) < 34f) return false;
        for (float[] zn : zones) if (Math.hypot(x - zn[0], z - zn[1]) < zn[2]) return false;
        for (float[] b : buildings)
            if (x > b[0] - clr - 2 && x < b[2] + clr + 2 && z > b[1] - clr - 2 && z < b[3] + clr + 2) return false;
        if (forestTrails && (Math.abs(x) < 3.4f || Math.abs(z + 10f) < 3.4f)) return false;
        for (float[] p : placed) if (Math.hypot(x - p[0], z - p[1]) < clr) return false;
        return true;
    }

    // ---------- карта 0: Большой лес ----------
    private void tree(float x, float z) {
        float v = (rnd.nextFloat() - 0.5f) * 0.08f;
        int t = rnd.nextInt(10);
        if (t < 5) {            // сосна
            float hh = 0.9f + rnd.nextFloat() * 0.4f;
            add(x - 0.18f, 0, z - 0.18f, x + 0.18f, 6.5f * hh, z + 0.18f, .32f, .22f, .13f, 0, true);
            add(x - 1.7f, 1.8f, z - 1.7f, x + 1.7f, 4.2f * hh, z + 1.7f, .09f + v, .25f + v, .12f, 0, false);
            add(x - 1.0f, 4.2f * hh, z - 1.0f, x + 1.0f, 7.4f * hh, z + 1.0f, .08f + v, .22f + v, .11f, 0, false);
        } else if (t < 8) {     // дуб
            add(x - 0.24f, 0, z - 0.24f, x + 0.24f, 3.4f, z + 0.24f, .34f, .24f, .14f, 0, true);
            add(x - 2.2f, 2.6f, z - 2.2f, x + 2.2f, 6.2f, z + 2.2f, .18f + v, .36f + v, .13f, 0, false);
        } else {                // берёза
            add(x - 0.14f, 0, z - 0.14f, x + 0.14f, 5f, z + 0.14f, .82f, .82f, .76f, 0, true);
            add(x - 1.3f, 3f, z - 1.3f, x + 1.3f, 6.2f, z + 1.3f, .34f + v, .47f + v, .18f, 0, false);
        }
    }

    private void forest() {
        forestTrails = true;
        ground(.21f, .32f, .15f);
        border(.12f, .24f, .10f, 4.5f);
        bases();
        pointsAt(new float[][]{{-48f, -10f}, {0f, 6f}, {48f, -10f}});
        for (Point p : points) zones.add(new float[]{p.x, p.z, 16f});
        // тропы и поляны вокруг блиндажей
        road(-2.2f, -H, 2.2f, H, .36f, .30f, .20f);
        road(-H, -12.2f, H, -7.8f, .36f, .30f, .20f);
        for (Point p : points) add(p.x - 14f, 0f, p.z - 14f, p.x + 14f, 0.02f, p.z + 14f, .29f, .40f, .20f, 0, false);
        // лесные хижины
        for (float[] c : new float[][]{{-28f, -38f}, {30f, 36f}, {-36f, 34f}, {26f, -40f}}) {
            if (houseOk(c[0], c[1], 6.5f, 5.5f)) building(c[0], c[1], 6.5f, 5.5f, 2.8f, 1.7f, 2.2f, 1.2f, 1, new float[]{.42f, .30f, .18f});
        }
        // камни, брёвна, кусты (кусты только скрывают - пули их не задерживают)
        int n = 0, tries = 0;
        while (n < 34 && tries++ < 4000) {
            float x = (rnd.nextFloat() * 2 - 1) * (H - 6), z = (rnd.nextFloat() * 2 - 1) * (H - 6);
            if (!okSpot(x, z, 6f)) continue;
            placed.add(new float[]{x, z}); n++;
            boolean sw = rnd.nextBoolean();
            float v = (rnd.nextFloat() - .5f) * .08f;
            if (rnd.nextBoolean()) xz(sw, x, z, 1.1f + rnd.nextFloat() * .6f, 0.8f, 0f, 0.9f + rnd.nextFloat() * .4f, .45f + v, .45f + v, .43f + v);
            else xz(sw, x, z, 2.3f, 0.3f, 0f, 0.6f, .33f + v, .23f + v, .13f);
        }
        n = 0; tries = 0;
        while (n < 80 && tries++ < 4000) {
            float x = (rnd.nextFloat() * 2 - 1) * (H - 4), z = (rnd.nextFloat() * 2 - 1) * (H - 4);
            if (!okSpot(x, z, 3.5f)) continue;
            placed.add(new float[]{x, z}); n++;
            float v = (rnd.nextFloat() - .5f) * .1f;
            add(x - 0.7f, 0, z - 0.7f, x + 0.7f, 0.9f, z + 0.7f, .14f + v, .30f + v, .10f, 0, false);
        }
        n = 0; tries = 0;
        while (n < 380 && tries++ < 14000) {
            float x = (rnd.nextFloat() * 2 - 1) * (H - 3), z = (rnd.nextFloat() * 2 - 1) * (H - 3);
            if (!okSpot(x, z, 4.6f)) continue;
            placed.add(new float[]{x, z}); n++;
            tree(x, z);
        }
    }

    // ---------- карта 1: арена CS:S (zm_opt_tr) ----------
    // Геометрия перенесена из BSP (1 юнит Source = 0.0254 м, оси: x -> x, z -> вверх, y -> -z). Рельеф земли (холмы до 1.9 м) не переносился: земля плоская.
    // Размеры: 55 x 88 м, внешняя стена 7.8 м. Текстур в BSP нет, поэтому поверхности просто окрашены.

    /** Пилоны и щиты перед спавнами: {x0, y0, z0, x1, y1, z1} в метрах. */
    private static final float[][] CSS_SOLIDS = {
            {-13.82f, 0f, -2.44f, -8.94f, 4.88f, 2.44f},
            {13.82f, 0f, 19.51f, 18.69f, 4.95f, 24.38f},
            {-18.69f, 0f, 19.51f, -13.82f, 4.95f, 24.38f},
            {-18.69f, 0f, -24.38f, -13.82f, 4.95f, -19.51f},
            {13.82f, 0f, -24.38f, 18.69f, 4.95f, -19.51f},
            {8.94f, 0f, -2.44f, 13.82f, 4.88f, 2.44f},
            {-4.06f, 0f, 27.64f, 4.06f, 3.25f, 32.51f},
            {-4.06f, 0f, -32.51f, 4.06f, 3.25f, -27.64f}
    };
    /** Спавны: наша сторона (юг, террористы CS) и противник (север, контр-террористы). {x, z} в метрах. */
    private static final float[][] CSS_ALLY = {{-3f, 39.7f}, {-6.3f, 39.7f}, {-9.6f, 39.7f}, {-12.8f, 39.7f}, {-16.1f, 39.7f}, {-19.3f, 39.7f}, {3.5f, 39.7f}, {6.7f, 39.7f}, {10f, 39.7f}, {13.2f, 39.7f}, {16.5f, 39.7f}, {19.7f, 39.7f}, {-17.5f, 39.7f}, {-14.4f, 39.7f}, {-11f, 39.7f}, {-7.7f, 39.7f}, {-3f, 37.7f}, {-6.3f, 37.7f}, {-9.6f, 37.7f}, {-12.8f, 37.7f}, {-16.1f, 37.7f}, {-19.3f, 37.7f}, {3.5f, 37.7f}, {6.7f, 37.7f}, {10f, 37.7f}, {13.2f, 37.7f}, {16.5f, 37.7f}, {19.7f, 37.7f}, {-17.5f, 37.8f}, {-14.4f, 37.8f}, {-11f, 37.8f}, {-7.7f, 37.8f}, {-3f, 35.8f}, {-6.3f, 35.8f}, {-9.6f, 35.8f}, {-12.8f, 35.8f}, {-16.1f, 35.8f}, {-19.3f, 35.8f}, {3.5f, 35.8f}, {6.7f, 35.8f}, {10f, 35.8f}, {13.2f, 35.8f}, {16.5f, 35.8f}, {19.7f, 35.8f}, {-17.5f, 35.8f}, {-14.4f, 35.8f}, {-11f, 35.8f}, {-7.7f, 35.8f}};
    private static final float[][] CSS_ENEMY = {{3.5f, -40.7f}, {6.7f, -40.7f}, {10f, -40.7f}, {-3f, -40.7f}, {-6.3f, -40.7f}, {-9.6f, -40.7f}, {13.2f, -40.7f}, {-12.8f, -40.7f}, {16.5f, -40.7f}, {-16.1f, -40.7f}, {-19.3f, -40.7f}, {19.7f, -40.7f}, {18.2f, -40.7f}, {15f, -40.7f}, {11.5f, -40.7f}, {3.5f, -39f}, {6.7f, -39f}, {10f, -39f}, {-3f, -39f}, {-6.3f, -39f}, {-9.6f, -39f}, {13.2f, -39f}, {-12.8f, -39f}, {16.5f, -39f}, {-16.1f, -39f}, {-19.3f, -39f}, {19.7f, -39f}, {18.2f, -39f}, {15f, -39f}, {11.5f, -39.1f}, {3.5f, -37.3f}, {6.7f, -37.3f}, {10f, -37.3f}, {-3f, -37.3f}, {-6.3f, -37.3f}, {-9.6f, -37.3f}, {13.2f, -37.3f}, {-12.8f, -37.3f}, {16.5f, -37.3f}, {-16.1f, -37.3f}, {-19.3f, -37.3f}, {19.7f, -37.3f}, {18.2f, -37.3f}, {15f, -37.3f}, {11.5f, -37.3f}};

    /** Пункт снабжения без здания: зона, ящик с патронами и аптечка. Пополнение работает так же, как в блиндаже. */
    private Bunker supplyZone(float cx, float cz, float hw, float hd, int point, int baseTeam) {
        add(cx - hw, 0f, cz - hd, cx + hw, 0.03f, cz + hd, .30f, .27f, .20f, 0, false);                       // площадка
        add(cx - hw + .1f, 0f, cz - hd + .1f, cx - hw + 1.3f, .55f, cz - hd + .8f, .27f, .33f, .20f, 0, true);  // ящик с патронами
        add(cx - hw + .25f, .55f, cz - hd + .2f, cx - hw + 1.0f, 1.0f, cz - hd + .7f, .24f, .30f, .18f, 0, true);
        add(cx + hw - .8f, 0f, cz - hd + .1f, cx + hw - .1f, .45f, cz - hd + .7f, .90f, .90f, .88f, 0, true);   // аптечка
        add(cx + hw - .55f, .45f, cz - hd + .3f, cx + hw - .45f, .47f, cz - hd + .5f, .8f, .1f, .1f, 0, false);
        add(cx + hw - .65f, .45f, cz - hd + .38f, cx + hw - .35f, .47f, cz - hd + .42f, .8f, .1f, .1f, 0, false);
        Bunker bk = new Bunker(cx, cz, cx - hw, cz - hd, cx + hw, cz + hd, point, baseTeam);
        bunkers.add(bk);
        zones.add(new float[]{cx, cz, 5f});
        return bk;
    }

    private void cssArena() {
        final float X = 27.53f, Z = 43.89f, WH = 7.8f, T = 1.3f;
        ground(.43f, .39f, .29f);
        // внешние стены прямоугольной арены
        final float[] wc = {.42f, .38f, .33f};
        add(-X - T, 0, -Z - T, X + T, WH, -Z, wc[0], wc[1], wc[2], 2, true);
        add(-X - T, 0, Z, X + T, WH, Z + T, wc[0], wc[1], wc[2], 2, true);
        add(-X - T, 0, -Z, -X, WH, Z, wc[0], wc[1], wc[2], 2, true);
        add(X, 0, -Z, X + T, WH, Z, wc[0], wc[1], wc[2], 2, true);
        for (float[] s : CSS_SOLIDS) add(s[0], s[1], s[2], s[3], s[4], s[5], .50f, .46f, .39f, 2, true);
        // пункты снабжения на базах и три точки захвата A, B, C слева направо
        supplyZone(0f, Z - 2.2f, 3f, 1.8f, -1, 0);
        supplyZone(0f, -Z + 2.2f, 3f, 1.8f, -1, 1);
        float[][] pos = {{-20f, 0f}, {0f, 0f}, {20f, 0f}};
        for (int i = 0; i < pos.length; i++) {
            Bunker bk = supplyZone(pos[i][0], pos[i][1], 3f, 1.8f, i, -1);
            points.add(new Point(i, bk));
        }
        // спавны (после ящиков, чтобы никто не появлялся внутри них)
        for (float[] sp : CSS_ALLY) if (!blocked(sp[0], sp[1], 0.7f)) allySpawns.add(sp);
        for (float[] sp : CSS_ENEMY) if (!blocked(sp[0], sp[1], 0.7f)) enemySpawns.add(sp);
        playerSpawn[0] = 0f; playerSpawn[1] = 38f;
    }

    // ---------- столкновения ----------
    public boolean blocked(float x, float z, float r) {
        for (Box b : solid) {
            float cx = Math.max(b.x0, Math.min(x, b.x1)), cz = Math.max(b.z0, Math.min(z, b.z1));
            float dx = x - cx, dz = z - cz;
            if (dx * dx + dz * dz < r * r) return true;
        }
        return false;
    }

    /** Выталкивает круг радиуса r из стен. p = {x, z}. */
    public void resolve(float[] p, float r) { resolve(p, r, 0f); }

    /**
     * Высота пола под кругом радиуса 0.3 в точке (x, z) для ног на высоте feet: верх самого высокого укрытия,
     * которое не выше ног (при прыжке можно встать на низкий ящик). Иначе 0 - земля.
     */
    public float floorAt(float x, float z, float feet) {
        float best = 0f;
        for (Box b : solid) {
            if (b.y1 > feet + 0.05f || b.y1 <= best) continue;
            float cx = Math.max(b.x0, Math.min(x, b.x1)), cz = Math.max(b.z0, Math.min(z, b.z1));
            float dx = x - cx, dz = z - cz;
            if (dx * dx + dz * dz < 0.3f * 0.3f) best = b.y1;
        }
        return best;
    }

    /** То же, что resolve(p, r), но укрытия ниже ног (feet - высота ног над землёй) не мешают: через них можно перепрыгнуть. */
    public void resolve(float[] p, float r, float feet) {
        for (int pass = 0; pass < 2; pass++) {
            for (Box b : solid) {
                if (b.y1 <= feet + 0.05f) continue;
                float cx = Math.max(b.x0, Math.min(p[0], b.x1)), cz = Math.max(b.z0, Math.min(p[1], b.z1));
                float dx = p[0] - cx, dz = p[1] - cz, d2 = dx * dx + dz * dz;
                if (d2 >= r * r) continue;
                if (d2 > 1e-8f) {
                    float d = (float) Math.sqrt(d2), push = r - d;
                    p[0] += dx / d * push; p[1] += dz / d * push;
                } else {
                    float l = p[0] - b.x0, rr = b.x1 - p[0], u = p[1] - b.z0, dn = b.z1 - p[1];
                    float m = Math.min(Math.min(l, rr), Math.min(u, dn));
                    if (m == l) p[0] = b.x0 - r; else if (m == rr) p[0] = b.x1 + r;
                    else if (m == u) p[1] = b.z0 - r; else p[1] = b.z1 + r;
                }
            }
        }
        float lim = H - 0.6f;
        p[0] = Math.max(-lim, Math.min(lim, p[0]));
        p[1] = Math.max(-lim, Math.min(lim, p[1]));
    }

    public float raycast(float ox, float oy, float oz, float dx, float dy, float dz, float maxT) {
        float best = maxT;
        for (Box b : boxes) {
            if (!b.block) continue;
            float t = rayAabb(ox, oy, oz, dx, dy, dz, b.x0, b.y0, b.z0, b.x1, b.y1, b.z1);
            if (t >= 0 && t < best) best = t;
        }
        return best;
    }

    public static float rayAabb(float ox, float oy, float oz, float dx, float dy, float dz,
                                float x0, float y0, float z0, float x1, float y1, float z1) {
        float tmin = 0f, tmax = 1e9f;
        float[] o = {ox, oy, oz}, d = {dx, dy, dz}, lo = {x0, y0, z0}, hi = {x1, y1, z1};
        for (int i = 0; i < 3; i++) {
            if (Math.abs(d[i]) < 1e-8f) {
                if (o[i] < lo[i] || o[i] > hi[i]) return -1f;
            } else {
                float t1 = (lo[i] - o[i]) / d[i], t2 = (hi[i] - o[i]) / d[i];
                if (t1 > t2) { float t = t1; t1 = t2; t2 = t; }
                tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2);
                if (tmin > tmax) return -1f;
            }
        }
        return tmin;
    }
}
