package com.bodycamclone;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Процедурная карта: поле, дороги, здания с дверями и окнами, укрытия, деревья. */
public class WorldMap {
    public static final class Box {
        public final float x0, y0, z0, x1, y1, z1, r, g, b;
        public final int mode;          // 0 плоский, 1 земля, 2 стена
        public final boolean block;     // блокирует пули и обзор
        public final boolean collide;   // блокирует движение
        Box(float x0, float y0, float z0, float x1, float y1, float z1, float r, float g, float b, int mode, boolean block) {
            this.x0 = x0; this.y0 = y0; this.z0 = z0; this.x1 = x1; this.y1 = y1; this.z1 = z1;
            this.r = r; this.g = g; this.b = b; this.mode = mode; this.block = block;
            this.collide = block && y0 < 1.5f && y1 > 0.3f;
        }
    }

    public final List<Box> boxes = new ArrayList<>();
    public final List<float[]> enemySpawns = new ArrayList<>();
    public final List<float[]> allySpawns = new ArrayList<>();
    public final float[] playerSpawn = {0f, 42f};
    private final List<float[]> buildings = new ArrayList<>();
    private final List<float[]> placed = new ArrayList<>();
    private final Random rnd;
    private final float H = Config.MAP_HALF;

    public WorldMap(long seed) { rnd = new Random(seed); build(); }

    private void add(float x0, float y0, float z0, float x1, float y1, float z1, float r, float g, float b, int mode, boolean block) {
        boxes.add(new Box(x0, y0, z0, x1, y1, z1, r, g, b, mode, block));
    }

    private void build() {
        add(-H - 12, -1f, -H - 12, H + 12, 0f, H + 12, .38f, .42f, .27f, 1, false);
        add(-3, 0, -H, 3, 0.03f, H, .23f, .23f, .24f, 0, false);
        add(-H, 0, -3, H, 0.03f, 3, .23f, .23f, .24f, 0, false);
        float t = 1.5f, wh = 3.5f;
        add(-H - t, 0, -H - t, H + t, wh, -H, .5f, .5f, .48f, 2, true);
        add(-H - t, 0, H, H + t, wh, H + t, .5f, .5f, .48f, 2, true);
        add(-H - t, 0, -H, -H, wh, H, .5f, .5f, .48f, 2, true);
        add(H, 0, -H, H + t, wh, H, .5f, .5f, .48f, 2, true);

        float[][] centers = {{-30, -30}, {-10, -32}, {20, -28}, {38, -26}, {-36, -10},
                {28, 9}, {-30, 22}, {-12, 15}, {20, 27}};
        for (float[] c : centers) building(c[0], c[1]);
        props();

        for (int i = 0; i < 60 && enemySpawns.size() < 30; i++) {
            float x = -42 + rnd.nextFloat() * 84, z = -47 + rnd.nextFloat() * 6;
            if (!blocked(x, z, 0.7f)) enemySpawns.add(new float[]{x, z});
        }
        float[][] as = {{-5, 44}, {5, 44}, {0, 46}, {-8, 45}, {8, 45}};
        for (float[] a : as) if (!blocked(a[0], a[1], 0.7f)) allySpawns.add(a);
        if (enemySpawns.isEmpty()) enemySpawns.add(new float[]{0f, -44f});
        if (allySpawns.isEmpty()) allySpawns.add(new float[]{0f, 44f});
    }

    private void building(float cx, float cz) {
        float w = 9 + rnd.nextFloat() * 3f, d = 7 + rnd.nextFloat() * 2.5f, th = 0.3f, h = 3.2f;
        float x0 = cx - w / 2, x1 = cx + w / 2, z0 = cz - d / 2, z1 = cz + d / 2;
        float v = (rnd.nextFloat() - 0.5f) * 0.12f;
        float r = .62f + v, g = .58f + v, b = .50f + v;
        buildings.add(new float[]{x0, z0, x1, z1});
        wall(true, x0, x1, z1, th, h, ops(true), r, g, b);
        wall(true, x0, x1, z0, th, h, ops(rnd.nextBoolean()), r, g, b);
        wall(false, z0, z1, x0, th, h, ops(false), r, g, b);
        wall(false, z0, z1, x1, th, h, ops(false), r, g, b);
        add(x0 - 0.25f, h, z0 - 0.25f, x1 + 0.25f, h + 0.3f, z1 + 0.25f, .30f, .26f, .24f, 0, true);
        int n = 1 + rnd.nextInt(2);
        for (int i = 0; i < n; i++) {
            float px = x0 + 1.8f + rnd.nextFloat() * (w - 3.6f), pz = z0 + 1.8f + rnd.nextFloat() * (d - 3.6f);
            float s = 0.9f + rnd.nextFloat() * 0.4f;
            add(px - s / 2, 0, pz - s / 2, px + s / 2, s, pz + s / 2, .45f, .33f, .2f, 0, true);
        }
    }

    /** Проёмы в долях длины стены: {доля, ширина, тип 0=дверь 1=окно}. */
    private float[][] ops(boolean door) {
        int doorSlot = rnd.nextInt(2);
        float[][] o = new float[2][];
        for (int i = 0; i < 2; i++) {
            float frac = i == 0 ? 0.22f : 0.72f;
            if (door && i == doorSlot) o[i] = new float[]{frac, 1.7f, 0};
            else o[i] = new float[]{frac, 1.5f, 1};
        }
        if (!door && rnd.nextFloat() < 0.3f) return new float[][]{o[rnd.nextInt(2)]};
        return o;
    }

    private void wall(boolean ax, float a0, float a1, float c, float th, float h, float[][] op, float r, float g, float b) {
        float cur = a0, len = a1 - a0;
        for (float[] o : op) {
            float mid = a0 + o[0] * len, s = mid - o[1] / 2, e = mid + o[1] / 2;
            if (s > cur) seg(ax, cur, s, c, th, 0, h, r, g, b);
            if (o[2] == 0) seg(ax, s, e, c, th, 2.3f, h, r, g, b);
            else { seg(ax, s, e, c, th, 0, 1.0f, r, g, b); seg(ax, s, e, c, th, 2.1f, h, r, g, b); }
            cur = e;
        }
        if (cur < a1) seg(ax, cur, a1, c, th, 0, h, r, g, b);
    }

    private void seg(boolean ax, float a0, float a1, float c, float th, float y0, float y1, float r, float g, float b) {
        if (ax) add(a0, y0, c - th / 2, a1, y1, c + th / 2, r, g, b, 2, true);
        else add(c - th / 2, y0, a0, c + th / 2, y1, a1, r, g, b, 2, true);
    }

    private boolean freeSpot(float x, float z, float clr) {
        for (float[] b : buildings)
            if (x > b[0] - clr - 2 && x < b[2] + clr + 2 && z > b[1] - clr - 2 && z < b[3] + clr + 2) return false;
        if (Math.hypot(x - playerSpawn[0], z - playerSpawn[1]) < 10) return false;
        for (float[] p : placed) if (Math.hypot(x - p[0], z - p[1]) < clr) return false;
        return true;
    }

    private void xz(boolean sw, float cx, float cz, float hx, float hz, float y0, float y1, float r, float g, float b) {
        float a = sw ? hz : hx, c = sw ? hx : hz;
        add(cx - a, y0, cz - c, cx + a, y1, cz + c, r, g, b, 0, true);
    }

    private void props() {
        int n = 0, tries = 0;
        while (n < 46 && tries++ < 3000) {
            float x = (rnd.nextFloat() * 2 - 1) * (H - 6), z = (rnd.nextFloat() * 2 - 1) * (H - 6);
            if (!freeSpot(x, z, 4f)) continue;
            placed.add(new float[]{x, z}); n++;
            boolean sw = rnd.nextBoolean();
            float v = (rnd.nextFloat() - 0.5f) * 0.08f;
            switch (rnd.nextInt(5)) {
                case 0: xz(false, x, z, 0.6f, 0.6f, 0, 1.2f, .45f + v, .33f + v, .2f); break;
                case 1: xz(sw, x, z, 1.8f, 0.4f, 0, 0.9f, .55f + v, .5f + v, .35f); break;
                case 2: xz(sw, x, z, 1.0f, 0.4f, 0, 1.2f, .55f + v, .55f + v, .53f); break;
                case 3:
                    xz(sw, x, z, 2.1f, 0.95f, 0.35f, 1.15f, .32f + v, .3f + v, .28f);
                    xz(sw, x - (sw ? 0 : 0.1f), z - (sw ? 0.1f : 0), 1.0f, 0.85f, 1.15f, 1.75f, .22f, .21f, .2f);
                    break;
                default:
                    xz(false, x, z, 0.6f, 0.6f, 0, 1.2f, .45f, .33f, .2f);
                    xz(false, x + 0.3f, z + 0.2f, 0.5f, 0.5f, 1.2f, 2.1f, .5f, .37f, .22f);
                    break;
            }
        }
        n = 0; tries = 0;
        while (n < 36 && tries++ < 3000) {
            float x = (rnd.nextFloat() * 2 - 1) * (H - 4), z = (rnd.nextFloat() * 2 - 1) * (H - 4);
            if (Math.abs(x) < 4 || Math.abs(z) < 4 || !freeSpot(x, z, 5f)) continue;
            placed.add(new float[]{x, z}); n++;
            float v = (rnd.nextFloat() - 0.5f) * 0.1f;
            add(x - 0.18f, 0, z - 0.18f, x + 0.18f, 3.2f, z + 0.18f, .3f, .22f, .14f, 0, true);
            add(x - 1.5f, 3f, z - 1.5f, x + 1.5f, 5.8f, z + 1.5f, .18f + v, .34f + v, .14f, 0, true);
        }
    }

    // ---------- столкновения ----------
    public boolean blocked(float x, float z, float r) {
        for (Box b : boxes) {
            if (!b.collide) continue;
            float cx = Math.max(b.x0, Math.min(x, b.x1)), cz = Math.max(b.z0, Math.min(z, b.z1));
            float dx = x - cx, dz = z - cz;
            if (dx * dx + dz * dz < r * r) return true;
        }
        return false;
    }

    /** Выталкивает круг радиуса r из стен. p = {x, z}. */
    public void resolve(float[] p, float r) {
        for (int pass = 0; pass < 2; pass++) {
            for (Box b : boxes) {
                if (!b.collide) continue;
                float cx = Math.max(b.x0, Math.min(p[0], b.x1)), cz = Math.max(b.z0, Math.min(p[1], b.z1));
                float dx = p[0] - cx, dz = p[1] - cz, d2 = dx * dx + dz * dz;
                if (d2 >= r * r) continue;
                if (d2 > 1e-8f) {
                    float d = (float) Math.sqrt(d2), push = r - d;
                    p[0] += dx / d * push; p[1] += dz / d * push;
                } else {
                    float l = p[0] - b.x0, rr = b.x1 - p[0], u = p[1] - b.z0, dn = b.z1 - p[1];
                    float m = Math.min(Math.min(l, rr), Math.min(u, dn));
                    if (m == l) p[0] = b.x0 - r; else if (m == rr) p[0] = b.x1 + r;
                    else if (m == u) p[1] = b.z0 - r; else p[1] = b.z1 + r;
                }
            }
        }
        float lim = H - 0.6f;
        p[0] = Math.max(-lim, Math.min(lim, p[0]));
        p[1] = Math.max(-lim, Math.min(lim, p[1]));
    }

    public float raycast(float ox, float oy, float oz, float dx, float dy, float dz, float maxT) {
        float best = maxT;
        for (Box b : boxes) {
            if (!b.block) continue;
            float t = rayAabb(ox, oy, oz, dx, dy, dz, b.x0, b.y0, b.z0, b.x1, b.y1, b.z1);
            if (t >= 0 && t < best) best = t;
        }
        return best;
    }

    public static float rayAabb(float ox, float oy, float oz, float dx, float dy, float dz,
                                float x0, float y0, float z0, float x1, float y1, float z1) {
        float tmin = 0f, tmax = 1e9f;
        float[] o = {ox, oy, oz}, d = {dx, dy, dz}, lo = {x0, y0, z0}, hi = {x1, y1, z1};
        for (int i = 0; i < 3; i++) {
            if (Math.abs(d[i]) < 1e-8f) {
                if (o[i] < lo[i] || o[i] > hi[i]) return -1f;
            } else {
                float t1 = (lo[i] - o[i]) / d[i], t2 = (hi[i] - o[i]) / d[i];
                if (t1 > t2) { float t = t1; t1 = t2; t2 = t; }
                tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2);
                if (tmin > tmax) return -1f;
            }
        }
        return tmin;
    }
}
