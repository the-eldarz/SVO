package com.bodycamclone;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки управления (как в Standoff 2): чувствительность, гироскоп, зона стрельбы, перекрестие, раскладка кнопок. */
public final class Settings {
    private Settings() {}

    public static final int B_FIRE = 0, B_FIRE2 = 1, B_WEAPON = 2, B_AIM = 3, B_ZOOM = 4, B_CROUCH = 5, B_PRONE = 6, B_JUMP = 7, B_LEAN_L = 8, B_LEAN_R = 9, COUNT = 10;
    public static final String[] LABEL = {"ОГОНЬ", "ОГОНЬ 2", "ОРУЖИЕ", "ПРИЦЕЛ", "ЗУМ", "ПРИСЕСТЬ", "ЛЕЧЬ", "ПРЫЖОК", "ВЫГЛЯНУТЬ ВЛЕВО", "ВЫГЛЯНУТЬ ВПРАВО"};
    /** Половина ширины / высоты кнопки в dp при размере 100%. У круглых кнопок они равны. */
    private static final float[] BASE_HW = {44f, 26f, 56f, 29f, 22f, 27f, 27f, 27f, 23f, 23f};
    private static final float[] BASE_HH = {44f, 26f, 19f, 29f, 22f, 27f, 27f, 27f, 23f, 23f};
    /** Прямоугольные кнопки (кнопка оружия). */
    private static final boolean[] RECT = {false, false, true, false, false, false, false, false, false, false};
    /** Положение центра кнопки: отступ от правого/нижнего края экрана в dp. */
    private static final float[] DEF_OX = {179f, 121f, 350f, 262f, 262f, 70f, 105f, 62f, 122f, 62f};
    private static final float[] DEF_OY = {77f, 121f, 52f, 105f, 160f, 95f, 40f, 168f, 228f, 228f};

    public static final float[] ox = DEF_OX.clone(), oy = DEF_OY.clone(), sc = {1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f};

    /** Видимость каждой кнопки (0.2..1). */
    public static final float[] al = {1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f};
    /** true - приседание / «лечь» работает пока держишь кнопку, false - переключается нажатием. */
    public static boolean crouchHold = false, proneHold = false;
    /** true - выглядывание работает пока держишь кнопку, false - кнопка включает/выключает наклон. */
    public static boolean leanHold = true;

    // ----- Видео -----
    public static final String[] QUALITY = {"НИЗКОЕ", "СРЕДНЕЕ", "ВЫСОКОЕ"};
    /** Масштаб разрешения отрисовки и дальности прорисовки для каждого уровня. */
    public static final float[] RES_SCALE = {0.5f, 0.75f, 1f}, DIST_MUL = {0.55f, 0.8f, 1f};
    /** Допустимые целевые частоты кадров. */
    public static final int[] FPS_OPTS = {30, 45, 60, 90, 120};
    /** Уровни 0..2 (низкое..высокое): разрешение экрана, дальность прорисовки, детализация эффектов (кровь, следы пуль). */
    public static int gfxRes = 2, gfxDist = 2, gfxFx = 2;
    public static int fpsIdx = 4;
    public static boolean showFps = true;
    public static int fpsTarget() { return FPS_OPTS[Math.max(0, Math.min(FPS_OPTS.length - 1, fpsIdx))]; }

    // ----- Джойстик -----
    public static final int JOY_STATIC = 0, JOY_FLOAT = 1, JOY_FREE = 2;
    public static int joyMode = JOY_FREE;
    public static boolean joyRight = false;
    public static float joyScale = 1f, joyAlpha = 1f;
    /** Центр джойстика: отступ в dp от выбранного края (слева/справа) и от низа экрана. */
    public static float joyX = 96f, joyY = 96f;

    // ----- Управление: общее -----
    public static final float SENS_MIN = 0.1f, SENS_MAX = 5f;
    public static float sens = 1f;          // чувствительность
    public static float adsSens = 1f;       // чувствительность с прицелом
    public static float accel = 0f;         // ускорение: быстрый свайп поворачивает сильнее (0..1)
    public static float smooth = 1f;        // сглаживание прицела: 1 = выкл, меньше = плавнее
    public static boolean precise = false;  // точный отклик
    public static boolean invertY = false;
    /** true - прицел включается/выключается нажатием, false - держишь кнопку. */
    public static boolean adsToggle = true;
    /** Разрешить урон по бойцам своей команды. */
    public static boolean friendlyFire = false;
    /** Выбор оружия в снаряжении: 1 - АК-74М (3D-модель ak-74m.glb), 0 - простой АК-74 из боксов. */
    public static int rifle = 1;
    /** Снаряжение: форма (номер в Config.UNIFORM_NAMES), аптечка, ящик с патронами, гранаты (0 нет, 1 = x2, 2 = x4). */
    public static int uniform = 0, grenades = 0;
    public static boolean medkit = false, ammoBox = false;

    // ----- Гироскоп -----
    public static final int GYRO_OFF = 0, GYRO_ADS = 1, GYRO_ON = 2;
    public static final int[] GYRO_HZ = {15, 30, 60, 90, 120};
    public static int gyroMode = GYRO_OFF;
    public static boolean gyroInvX = false, gyroInvY = false;
    public static float gyroSens = 1f, gyroAdsSens = 1f;
    public static int gyroHzIdx = 1;

    // ----- Зона стрельбы -----
    public static final int FIRE_BTN_ZONE = 0, FIRE_BTN_ONLY = 1, FIRE_ZONE_ONLY = 2;
    public static int fireMode = FIRE_BTN_ZONE;
    /** Зона стрельбы в долях экрана: левый край, верх, ширина, высота. */
    public static float zx = 0.58f, zy = 0.10f, zw = 0.40f, zh = 0.45f;

    // ----- Перекрестие: [0] - от бедра, [1] - в прицеле -----
    public static final String[] CH_STYLE_NAME = {"Точка", "Круг", "Крест", "Крест + точка", "Квадрат"};
    public static final int[] CH_COLORS = {0xFFFFFFFF, 0xFF7CFC00, 0xFFFF3B30, 0xFFFFD60A, 0xFF00E5FF, 0xFFFF2DFF};
    public static final int[] chStyle = {1, 4}, chColor = {0, 0};
    public static final float[] chSize = {10f, 5f}, chThick = {1.5f, 1.5f}, chGap = {3f, 2f};

    private static SharedPreferences sp;

    public static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }

    public static void init(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("bodycam", Context.MODE_PRIVATE);
        for (int i = 0; i < COUNT; i++) {
            ox[i] = sp.getFloat("c2_b" + i + "_ox", DEF_OX[i]);
            oy[i] = sp.getFloat("c2_b" + i + "_oy", DEF_OY[i]);
            sc[i] = clamp(sp.getFloat("c2_b" + i + "_sc", 1f), 0.6f, 1.6f);
            al[i] = clamp(sp.getFloat("c2_b" + i + "_al", 1f), 0.2f, 1f);
        }
        crouchHold = sp.getBoolean("crouchHold", false);
        proneHold = sp.getBoolean("proneHold", false);
        leanHold = sp.getBoolean("leanHold", true);
        gfxRes = Math.max(0, Math.min(2, sp.getInt("gfxRes", 2)));
        gfxDist = Math.max(0, Math.min(2, sp.getInt("gfxDist", 2)));
        gfxFx = Math.max(0, Math.min(2, sp.getInt("gfxFx", 2)));
        fpsIdx = Math.max(0, Math.min(FPS_OPTS.length - 1, sp.getInt("fpsIdx", 4)));
        showFps = sp.getBoolean("showFps", true);
        joyMode = Math.max(0, Math.min(2, sp.getInt("joyMode", JOY_FREE)));
        joyRight = sp.getBoolean("joyRight", false);
        joyScale = clamp(sp.getFloat("joyScale", 1f), 0.6f, 1.6f);
        joyAlpha = clamp(sp.getFloat("joyAlpha", 1f), 0.2f, 1f);
        joyX = clamp(sp.getFloat("joyX", 96f), 20f, 600f);
        joyY = clamp(sp.getFloat("joyY", 96f), 20f, 400f);
        sens = clamp(sp.getFloat("sens", 1f), SENS_MIN, SENS_MAX);
        adsSens = clamp(sp.getFloat("adsSens", 1f), SENS_MIN, SENS_MAX);
        accel = clamp(sp.getFloat("accel", 0f), 0f, 1f);
        smooth = clamp(sp.getFloat("smooth", 1f), 0.05f, 1f);
        precise = sp.getBoolean("precise", false);
        invertY = sp.getBoolean("invy", false);
        adsToggle = sp.getBoolean("adsToggle", true);
        friendlyFire = sp.getBoolean("friendlyFire", false);
        rifle = sp.getInt("rifle", 1) == 0 ? 0 : 1;
        uniform = Math.max(0, Math.min(Config.UNIFORM_NAMES.length - 1, sp.getInt("uniform", 0)));
        grenades = Math.max(0, Math.min(Config.GRENADE_NAMES.length - 1, sp.getInt("grenades", 0)));
        medkit = sp.getBoolean("medkit", false);
        ammoBox = sp.getBoolean("ammoBox", false);
        gyroMode = Math.max(0, Math.min(2, sp.getInt("gyroMode", GYRO_OFF)));
        gyroInvX = sp.getBoolean("gyroInvX", false);
        gyroInvY = sp.getBoolean("gyroInvY", false);
        gyroSens = clamp(sp.getFloat("gyroSens", 1f), SENS_MIN, SENS_MAX);
        gyroAdsSens = clamp(sp.getFloat("gyroAdsSens", 1f), SENS_MIN, SENS_MAX);
        gyroHzIdx = Math.max(0, Math.min(GYRO_HZ.length - 1, sp.getInt("gyroHzIdx", 1)));
        fireMode = Math.max(0, Math.min(2, sp.getInt("fireMode", FIRE_BTN_ZONE)));
        zx = sp.getFloat("zx", 0.58f); zy = sp.getFloat("zy", 0.10f); zw = sp.getFloat("zw", 0.40f); zh = sp.getFloat("zh", 0.45f);
        clampZone();
        for (int k = 0; k < 2; k++) {
            chStyle[k] = Math.max(0, Math.min(CH_STYLE_NAME.length - 1, sp.getInt("chStyle" + k, k == 0 ? 1 : 4)));
            chColor[k] = Math.max(0, Math.min(CH_COLORS.length - 1, sp.getInt("chColor" + k, 0)));
            chSize[k] = clamp(sp.getFloat("chSize" + k, k == 0 ? 10f : 5f), 2f, 30f);
            chThick[k] = clamp(sp.getFloat("chThick" + k, 1.5f), 1f, 6f);
            chGap[k] = clamp(sp.getFloat("chGap" + k, k == 0 ? 3f : 2f), 0f, 20f);
        }
    }

    public static void save() {
        if (sp == null) return;
        SharedPreferences.Editor e = sp.edit();
        for (int i = 0; i < COUNT; i++) {
            e.putFloat("c2_b" + i + "_ox", ox[i]).putFloat("c2_b" + i + "_oy", oy[i]).putFloat("c2_b" + i + "_sc", sc[i]).putFloat("c2_b" + i + "_al", al[i]);
        }
        e.putBoolean("leanHold", leanHold).putInt("gfxRes", gfxRes).putInt("gfxDist", gfxDist).putInt("gfxFx", gfxFx)
                .putInt("fpsIdx", fpsIdx).putBoolean("showFps", showFps);
        e.putBoolean("crouchHold", crouchHold).putBoolean("proneHold", proneHold).putInt("joyMode", joyMode).putBoolean("joyRight", joyRight)
                .putFloat("joyScale", joyScale).putFloat("joyAlpha", joyAlpha).putFloat("joyX", joyX).putFloat("joyY", joyY);
        e.putFloat("sens", sens).putFloat("adsSens", adsSens).putFloat("accel", accel).putFloat("smooth", smooth)
                .putBoolean("precise", precise).putBoolean("invy", invertY).putBoolean("adsToggle", adsToggle)
                .putBoolean("friendlyFire", friendlyFire).putInt("rifle", rifle)
                .putInt("uniform", uniform).putInt("grenades", grenades).putBoolean("medkit", medkit).putBoolean("ammoBox", ammoBox);
        e.putInt("gyroMode", gyroMode).putBoolean("gyroInvX", gyroInvX).putBoolean("gyroInvY", gyroInvY)
                .putFloat("gyroSens", gyroSens).putFloat("gyroAdsSens", gyroAdsSens).putInt("gyroHzIdx", gyroHzIdx);
        e.putInt("fireMode", fireMode).putFloat("zx", zx).putFloat("zy", zy).putFloat("zw", zw).putFloat("zh", zh);
        for (int k = 0; k < 2; k++) {
            e.putInt("chStyle" + k, chStyle[k]).putInt("chColor" + k, chColor[k])
                    .putFloat("chSize" + k, chSize[k]).putFloat("chThick" + k, chThick[k]).putFloat("chGap" + k, chGap[k]);
        }
        e.apply();
    }

    public static void resetGeneral() {
        sens = 1f; adsSens = 1f; accel = 0f; smooth = 1f; precise = false;
        chStyle[0] = 1; chStyle[1] = 4; chColor[0] = 0; chColor[1] = 0;
        chSize[0] = 10f; chSize[1] = 5f; chThick[0] = 1.5f; chThick[1] = 1.5f; chGap[0] = 3f; chGap[1] = 2f;
    }

    public static void resetGyro() {
        gyroMode = GYRO_OFF; gyroInvX = false; gyroInvY = false; gyroSens = 1f; gyroAdsSens = 1f; gyroHzIdx = 1;
    }

    public static void resetVideo() { gfxRes = 2; gfxDist = 2; gfxFx = 2; fpsIdx = 4; showFps = true; }

    public static void resetGame() { adsToggle = true; invertY = false; friendlyFire = false; }

    public static void resetLayout() {
        for (int i = 0; i < COUNT; i++) { ox[i] = DEF_OX[i]; oy[i] = DEF_OY[i]; sc[i] = 1f; al[i] = 1f; }
        joyMode = JOY_FREE; joyRight = false; joyScale = 1f; joyAlpha = 1f; joyX = 96f; joyY = 96f;
        fireMode = FIRE_BTN_ZONE;
        zx = 0.58f; zy = 0.10f; zw = 0.40f; zh = 0.45f;
    }

    public static void clampZone() {
        zw = clamp(zw, 0.12f, 1f); zh = clamp(zh, 0.15f, 1f);
        zx = clamp(zx, 0f, 1f - zw); zy = clamp(zy, 0f, 1f - zh);
    }

    public static float joyCx(int w, float d) { return joyRight ? w - joyX * d : joyX * d; }
    public static float joyCy(int h, float d) { return h - joyY * d; }
    public static float joyRad(float d) { return 56f * joyScale * d; }

    public static float cx(int i, int w, float d) { return w - ox[i] * d; }
    public static float cy(int i, int h, float d) { return h - oy[i] * d; }
    public static float hw(int i, float d) { return BASE_HW[i] * sc[i] * d; }
    public static float hh(int i, float d) { return BASE_HH[i] * sc[i] * d; }
    /** Радиус круглой кнопки (для прямоугольной - полуширина). */
    public static float rad(int i, float d) { return hw(i, d); }
    public static boolean isRect(int i) { return RECT[i]; }

    /** Насколько точка далека от центра кнопки в долях её размера: &lt;1 - внутри кнопки. */
    public static float ratio(int i, float x, float y, int w, int h, float d) {
        float dx = x - cx(i, w, d), dy = y - cy(i, h, d);
        if (RECT[i]) return Math.max(Math.abs(dx) / hw(i, d), Math.abs(dy) / hh(i, d));
        return (float) Math.hypot(dx, dy) / hw(i, d);
    }

    /** Кнопки огня скрыты, когда включен режим «только зона». */
    public static boolean hidden(int i) { return fireMode == FIRE_ZONE_ONLY && (i == B_FIRE || i == B_FIRE2); }
}
