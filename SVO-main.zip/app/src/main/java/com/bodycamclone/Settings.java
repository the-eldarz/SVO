package com.bodycamclone;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки управления: положение и размер кнопок, чувствительность, режим прицела. Хранятся на устройстве. */
public final class Settings {
    private Settings() {}

    public static final int B_FIRE = 0, B_RELOAD = 1, B_WEAPON = 2, B_AIM = 3, B_ZOOM = 4, COUNT = 5;
    public static final String[] LABEL = {"ОГОНЬ", "R", "ОРУЖИЕ", "ПРИЦЕЛ", "ЗУМ"};
    private static final float[] BASE_R = {52f, 32f, 30f, 32f, 28f};
    /** Положение центра кнопки: отступ от правого/нижнего края экрана в dp. */
    private static final float[] DEF_OX = {95f, 200f, 195f, 95f, 195f};
    private static final float[] DEF_OY = {105f, 70f, 165f, 215f, 235f};

    public static final float[] ox = DEF_OX.clone(), oy = DEF_OY.clone(), sc = {1f, 1f, 1f, 1f, 1f};
    public static float sens = 1f;
    public static boolean invertY = false;
    /** true - прицел включается/выключается нажатием, false - держишь кнопку. */
    public static boolean adsToggle = true;
    /** Разрешить урон по бойцам своей команды. */
    public static boolean friendlyFire = false;
    /** Выбор оружия в снаряжении: 1 - АК-74М (3D-модель ak-74m.glb), 0 - простой АК-74 из боксов. */
    public static int rifle = 1;

    private static SharedPreferences sp;

    public static void init(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("bodycam", Context.MODE_PRIVATE);
        for (int i = 0; i < COUNT; i++) {
            ox[i] = sp.getFloat("b" + i + "_ox", DEF_OX[i]);
            oy[i] = sp.getFloat("b" + i + "_oy", DEF_OY[i]);
            sc[i] = Math.max(0.6f, Math.min(1.6f, sp.getFloat("b" + i + "_sc", 1f)));
        }
        sens = Math.max(0.3f, Math.min(2.5f, sp.getFloat("sens", 1f)));
        invertY = sp.getBoolean("invy", false);
        adsToggle = sp.getBoolean("adsToggle", true);
        friendlyFire = sp.getBoolean("friendlyFire", false);
        rifle = sp.getInt("rifle", 1) == 0 ? 0 : 1;
    }

    public static void save() {
        if (sp == null) return;
        SharedPreferences.Editor e = sp.edit();
        for (int i = 0; i < COUNT; i++) {
            e.putFloat("b" + i + "_ox", ox[i]).putFloat("b" + i + "_oy", oy[i]).putFloat("b" + i + "_sc", sc[i]);
        }
        e.putFloat("sens", sens).putBoolean("invy", invertY).putBoolean("adsToggle", adsToggle).putBoolean("friendlyFire", friendlyFire).putInt("rifle", rifle);
        e.apply();
    }

    public static void resetLayout() {
        for (int i = 0; i < COUNT; i++) { ox[i] = DEF_OX[i]; oy[i] = DEF_OY[i]; sc[i] = 1f; }
    }

    public static float cx(int i, int w, float d) { return w - ox[i] * d; }
    public static float cy(int i, int h, float d) { return h - oy[i] * d; }
    public static float rad(int i, float d) { return BASE_R[i] * sc[i] * d; }
}
