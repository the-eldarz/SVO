package com.bodycamclone;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.BlockingQueue;

/**
 * Игра по локальной сети (Wi-Fi / точка доступа).
 * Поиск комнат: хост раз в секунду шлёт UDP-broadcast, клиенты слушают порт DISC_PORT.
 * Сама игра: TCP, звезда - все подключаются к хосту, хост пересылает сообщения остальным и ведёт счёт.
 * Чистая Java, без Android API.
 *
 * Строки протокола (разделитель '|'):
 *   клиент -> хост: HELLO|имя   S|x|z|yaw|флаги   F   H|жертва|урон   K|убийца   P
 *   хост -> клиент: WELCOME|id|команда|карта|сторонаХоста|комната   FULL
 *                   S|id|x|z|yaw|флаги   F|id   H|стрелок|жертва|урон   K|убийца|жертва
 *                   R|id:команда:убийств:смертей:имя;...   BYE|id   P
 */
public final class Net {
    public static final int DISC_PORT = 47777, GAME_PORT = 47778, MAX_PLAYERS = 8;
    private static final String MAGIC = "BCAM1";
    private static final int TIMEOUT_MS = 10000;
    private static final String CLOSE = new String("\0close");

    /** Игрок в комнате (общий список, хост рассылает его всем). */
    public static final class PInfo {
        public final int id;
        public volatile String name;
        public volatile int team, kills, deaths;
        PInfo(int id, String name, int team) { this.id = id; this.name = name; this.team = team; }
    }

    /** Комната, найденная в сети. */
    public static final class Room {
        public String name, ip;
        public int map, players, max, port;
        public long seen;
    }

    public final boolean isHost;
    public volatile int myId, myTeam, mapIdx, hostSide;
    public volatile String roomName = "";
    /** Причина разрыва (для показа игроку). */
    public volatile String error;
    public volatile boolean closed;
    public final Map<Integer, PInfo> roster = new ConcurrentHashMap<>();
    /** События для игрового потока: {"S",id,x,z,yaw,флаги}, {"F",id}, {"H",стрелок,жертва,урон}, {"K",убийца,жертва}, {"BYE",id}. */
    public final ConcurrentLinkedQueue<String[]> inbox = new ConcurrentLinkedQueue<>();

    private final List<Conn> conns = new CopyOnWriteArrayList<>();
    private ServerSocket server;
    private DatagramSocket beacon;
    private int tcpPort, nextId = 1;

    private Net(boolean host) { isHost = host; }

    // ------------------------------------------------------------------ создание / подключение

    /** Создаёт комнату. Блокирует поток недолго (открывает порт) - вызывать не из UI-потока. */
    public static Net host(String room, int map, int hostSide, String name) throws IOException {
        Net n = new Net(true);
        n.roomName = clean(room, 24);
        n.mapIdx = map;
        n.hostSide = hostSide;
        n.myId = 0;
        n.myTeam = 0;
        n.roster.put(0, new PInfo(0, clean(name, 16), 0));
        try { n.server = new ServerSocket(GAME_PORT); } catch (IOException e) { n.server = new ServerSocket(0); }
        n.tcpPort = n.server.getLocalPort();
        daemon(n::acceptLoop, "net-accept");
        daemon(n::beaconLoop, "net-beacon");
        return n;
    }

    /** Подключается к комнате. Блокирует - вызывать не из UI-потока. */
    public static Net join(String ip, int port, String name) throws IOException {
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(ip, port), 4000);
            s.setTcpNoDelay(true);
            s.setSoTimeout(TIMEOUT_MS);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
            OutputStream os = s.getOutputStream();
            os.write(("HELLO|" + clean(name, 16) + "\n").getBytes("UTF-8"));
            os.flush();
            String w = in.readLine();
            if (w == null) throw new IOException("Хост не ответил");
            if (w.startsWith("FULL")) throw new IOException("Комната заполнена");
            String[] a = w.split("\\|", -1);
            if (a.length < 6 || !a[0].equals("WELCOME")) throw new IOException("Неверный ответ хоста");
            Net n = new Net(false);
            n.myId = Integer.parseInt(a[1]);
            n.myTeam = Integer.parseInt(a[2]);
            n.mapIdx = Integer.parseInt(a[3]);
            n.hostSide = Integer.parseInt(a[4]);
            n.roomName = a[5];
            Conn c = n.new Conn(s);
            n.conns.add(c);
            c.startWriter();
            daemon(() -> n.clientReadLoop(c, in), "net-read");
            daemon(n::heartbeatLoop, "net-ping");
            return n;
        } catch (IOException | RuntimeException e) {
            closeQuiet(s);
            if (e instanceof IOException) throw (IOException) e;
            throw new IOException("Ошибка подключения");
        }
    }

    // ------------------------------------------------------------------ отправка (вызывает игра)

    public void sendState(float x, float z, float yaw, int flags) {
        String body = r2(x) + "|" + r2(z) + "|" + r2(yaw) + "|" + flags;
        if (isHost) broadcast("S|0|" + body, null); else toHost("S|" + body);
    }

    public void sendFire() {
        if (isHost) broadcast("F|0", null); else toHost("F");
    }

    public void sendHit(int victim, float dmg) {
        if (isHost) broadcast("H|0|" + victim + "|" + r2(dmg), null);
        else toHost("H|" + victim + "|" + r2(dmg));
    }

    /** Я погиб, меня убил игрок killer. */
    public void sendKill(int killer) {
        if (isHost) handleKill(0, killer); else toHost("K|" + killer);
    }

    /** Чат: scope 0 - всем, 1 - только своей команде. Сообщение возвращается к отправителю тем же путём, что и ко всем. */
    public void sendChat(int scope, String text) {
        String t = chatClean(text);
        if (t == null) return;
        int sc = scope == 1 ? 1 : 0;
        if (isHost) handleChat(0, sc, t); else toHost("C|" + sc + "|" + t);
    }

    private void handleChat(int sender, int scope, String text) {
        PInfo s = roster.get(sender);
        if (s == null || text == null) return;
        String m = "C|" + sender + "|" + scope + "|" + text;
        for (Conn c : conns) if (scope == 0 || c.team == s.team) c.send(m);
        if (scope == 0 || s.team == myTeam) deliver(m);
    }

    /** Для чата убираем только служебные символы протокола (двоеточие и «;» можно). Пустое сообщение - null. */
    static String chatClean(String s) {
        if (s == null) return null;
        s = s.replaceAll("[|\\r\\n\\u0000]", " ").trim();
        if (s.length() > 100) s = s.substring(0, 100).trim();
        return s.isEmpty() ? null : s;
    }

    public int playerCount() { return roster.size(); }

    public void close() {
        closed = true;
        closeQuiet(server); server = null;
        if (beacon != null) { beacon.close(); beacon = null; }
        for (Conn c : conns) c.close();
        conns.clear();
    }

    // ------------------------------------------------------------------ хост

    private void acceptLoop() {
        ServerSocket ss = server;
        while (ss != null && !closed) {
            try {
                final Socket s = ss.accept();
                daemon(() -> serve(s), "net-client");
            } catch (IOException e) {
                break;
            }
        }
    }

    private void serve(Socket s) {
        Conn c = new Conn(s);
        try {
            s.setSoTimeout(TIMEOUT_MS);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
            String hello = in.readLine();
            if (hello == null || !hello.startsWith("HELLO|")) { closeQuiet(s); return; }
            String[] h = hello.split("\\|", -1);
            String name = clean(h.length > 1 ? h[1] : "", 16);
            synchronized (this) {
                if (roster.size() >= MAX_PLAYERS) {
                    s.getOutputStream().write("FULL\n".getBytes("UTF-8"));
                    s.getOutputStream().flush();
                    closeQuiet(s);
                    return;
                }
                int t0 = 0, t1 = 0;
                for (PInfo p : roster.values()) { if (p.team == 0) t0++; else t1++; }
                int team = t0 > t1 ? 1 : 0;
                c.id = nextId++;
                roster.put(c.id, new PInfo(c.id, name, team));
                c.team = team;
            }
            c.startWriter();
            c.send("WELCOME|" + c.id + "|" + c.team + "|" + mapIdx + "|" + hostSide + "|" + roomName);
            conns.add(c);
            broadcastRoster();
            String line;
            while (!closed && (line = in.readLine()) != null) hostHandle(c, line);
        } catch (IOException ignored) {
        } finally {
            if (c.id >= 0) {
                conns.remove(c);
                roster.remove(c.id);
                String bye = "BYE|" + c.id;
                broadcast(bye, null);
                deliver(bye);
                broadcastRoster();
            }
            c.close();
        }
    }

    private void hostHandle(Conn c, String line) {
        String[] a = line.split("\\|", -1);
        try {
            switch (a[0]) {
                case "S":
                    if (a.length >= 5) relay("S|" + c.id + "|" + a[1] + "|" + a[2] + "|" + a[3] + "|" + a[4], c);
                    break;
                case "F":
                    relay("F|" + c.id, c);
                    break;
                case "H":
                    if (a.length >= 3) relay("H|" + c.id + "|" + a[1] + "|" + a[2], c);
                    break;
                case "K":
                    if (a.length >= 2) handleKill(c.id, Integer.parseInt(a[1]));
                    break;
                case "C":
                    if (a.length >= 3) handleChat(c.id, "1".equals(a[1]) ? 1 : 0, chatClean(line.substring(line.indexOf('|', 2) + 1)));
                    break;
                default:
                    break;   // "P" и неизвестное - игнор
            }
        } catch (NumberFormatException ignored) {
        }
    }

    /** Игрок victim погиб от killer: хост считает счёт и рассылает всем. */
    private void handleKill(int victim, int killer) {
        PInfo v = roster.get(victim), k = roster.get(killer);
        if (v != null) v.deaths++;
        if (k != null && killer != victim) k.kills++;
        String m = "K|" + killer + "|" + victim;
        broadcast(m, null);
        deliver(m);
        broadcastRoster();
    }

    private void relay(String line, Conn except) {
        broadcast(line, except);
        deliver(line);
    }

    private void broadcast(String line, Conn except) {
        for (Conn c : conns) if (c != except) c.send(line);
    }

    private void broadcastRoster() {
        StringBuilder sb = new StringBuilder("R|");
        for (PInfo p : roster.values())
            sb.append(p.id).append(':').append(p.team).append(':').append(p.kills).append(':').append(p.deaths).append(':').append(p.name).append(';');
        broadcast(sb.toString(), null);
    }

    private void beaconLoop() {
        try {
            beacon = new DatagramSocket();
            beacon.setBroadcast(true);
        } catch (IOException e) {
            beacon = null;
        }
        while (!closed) {
            DatagramSocket ds = beacon;
            if (ds != null) {
                try {
                    byte[] b = (MAGIC + "|" + roomName + "|" + mapIdx + "|" + roster.size() + "|" + MAX_PLAYERS + "|" + tcpPort).getBytes("UTF-8");
                    for (InetAddress to : broadcastTargets()) {
                        try { ds.send(new DatagramPacket(b, b.length, to, DISC_PORT)); } catch (IOException ignored) { }
                    }
                } catch (Exception ignored) { }
            }
            broadcast("P", null);
            sleep(1000);
        }
    }

    /** Все адреса направленного broadcast (Wi-Fi, точка доступа) + общий 255.255.255.255. */
    private static List<InetAddress> broadcastTargets() {
        List<InetAddress> res = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> ifs = NetworkInterface.getNetworkInterfaces();
            while (ifs != null && ifs.hasMoreElements()) {
                NetworkInterface ni = ifs.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress b = ia.getBroadcast();
                    if (b != null && !res.contains(b)) res.add(b);
                }
            }
        } catch (Exception ignored) { }
        try { res.add(InetAddress.getByName("255.255.255.255")); } catch (Exception ignored) { }
        return res;
    }

    // ------------------------------------------------------------------ клиент

    private void clientReadLoop(Conn c, BufferedReader in) {
        try {
            String line;
            while (!closed && (line = in.readLine()) != null) {
                String[] a = line.split("\\|", -1);
                switch (a[0]) {
                    case "R": if (a.length >= 2) applyRoster(a[1]); break;
                    case "S": case "F": case "H": case "K": case "C": inbox.add(a); break;
                    case "BYE": roster.remove(parse(a, 1)); inbox.add(a); break;
                    default: break;
                }
            }
        } catch (IOException ignored) {
        }
        if (!closed) { error = "Хост отключился"; closed = true; }
        c.close();
    }

    private void heartbeatLoop() {
        while (!closed) { toHost("P"); sleep(2000); }
    }

    private void toHost(String line) {
        for (Conn c : conns) c.send(line);
    }

    private void applyRoster(String s) {
        List<Integer> seen = new ArrayList<>();
        for (String e : s.split(";")) {
            String[] f = e.split(":", 5);
            if (f.length < 5) continue;
            try {
                int id = Integer.parseInt(f[0]);
                PInfo p = roster.get(id);
                if (p == null) { p = new PInfo(id, f[4], Integer.parseInt(f[1])); roster.put(id, p); }
                p.team = Integer.parseInt(f[1]);
                p.kills = Integer.parseInt(f[2]);
                p.deaths = Integer.parseInt(f[3]);
                p.name = f[4];
                seen.add(id);
            } catch (NumberFormatException ignored) { }
        }
        for (Integer id : new ArrayList<>(roster.keySet())) if (!seen.contains(id)) roster.remove(id);
    }

    // ------------------------------------------------------------------ соединение

    private final class Conn {
        final Socket sock;
        final BlockingQueue<String> out = new LinkedBlockingQueue<>();
        volatile int id = -1, team;

        Conn(Socket s) {
            sock = s;
            try { s.setTcpNoDelay(true); } catch (Exception ignored) { }
        }

        void send(String line) {
            if (out.size() < 500) out.offer(line);   // если канал забит - лишнее выбрасываем
        }

        void startWriter() {
            daemon(() -> {
                try {
                    OutputStream os = sock.getOutputStream();
                    StringBuilder sb = new StringBuilder();
                    while (true) {
                        String l = out.take();
                        if (l == CLOSE) break;
                        sb.setLength(0);
                        sb.append(l).append('\n');
                        // склеиваем всё, что накопилось, в один пакет
                        while ((l = out.poll()) != null) {
                            if (l == CLOSE) { os.write(sb.toString().getBytes("UTF-8")); os.flush(); return; }
                            sb.append(l).append('\n');
                        }
                        os.write(sb.toString().getBytes("UTF-8"));
                        os.flush();
                    }
                } catch (Exception ignored) {
                } finally {
                    closeQuiet(sock);
                }
            }, "net-write");
        }

        void close() {
            out.offer(CLOSE);
            closeQuiet(sock);
        }
    }

    // ------------------------------------------------------------------ поиск комнат

    /** Слушает broadcast хостов и держит список комнат. */
    public static final class Finder {
        private final Map<String, Room> rooms = new ConcurrentHashMap<>();
        private volatile boolean run = true;
        private volatile DatagramSocket ds;
        /** Не null, если не удалось открыть порт прослушивания. */
        public volatile String error;

        public Finder() { daemon(this::loop, "net-find"); }

        private void loop() {
            try {
                DatagramSocket s = new DatagramSocket(null);
                s.setReuseAddress(true);
                s.bind(new InetSocketAddress(DISC_PORT));
                s.setSoTimeout(500);
                ds = s;
                byte[] buf = new byte[512];
                while (run) {
                    try {
                        DatagramPacket p = new DatagramPacket(buf, buf.length);
                        s.receive(p);
                        parseBeacon(new String(p.getData(), 0, p.getLength(), "UTF-8"), p.getAddress().getHostAddress());
                    } catch (java.net.SocketTimeoutException ignored) {
                    }
                }
                s.close();
            } catch (Exception e) {
                if (run) error = "Не удалось начать поиск: " + e.getMessage();
            }
        }

        private void parseBeacon(String msg, String ip) {
            String[] a = msg.split("\\|", -1);
            if (a.length < 6 || !a[0].equals(MAGIC)) return;
            try {
                Room r = new Room();
                r.name = a[1]; r.ip = ip;
                r.map = Integer.parseInt(a[2]); r.players = Integer.parseInt(a[3]);
                r.max = Integer.parseInt(a[4]); r.port = Integer.parseInt(a[5]);
                r.seen = System.currentTimeMillis();
                rooms.put(ip + ":" + r.port, r);
            } catch (NumberFormatException ignored) { }
        }

        /** Комнаты, которые подавали сигнал последние 4 секунды. */
        public List<Room> list() {
            long now = System.currentTimeMillis();
            List<Room> res = new ArrayList<>();
            for (Map.Entry<String, Room> e : rooms.entrySet()) {
                if (now - e.getValue().seen > 4000) rooms.remove(e.getKey()); else res.add(e.getValue());
            }
            Collections.sort(res, (x, y) -> x.name.compareToIgnoreCase(y.name));
            return res;
        }

        public void stop() {
            run = false;
            DatagramSocket s = ds;
            if (s != null) s.close();
        }
    }

    // ------------------------------------------------------------------ мелочи

    private void deliver(String line) { inbox.add(line.split("\\|", -1)); }

    private static int parse(String[] a, int i) {
        try { return Integer.parseInt(a[i]); } catch (Exception e) { return -1; }
    }

    private static String r2(float v) { return Float.toString(Math.round(v * 100f) / 100f); }

    /** Убирает служебные символы протокола и режет длину. */
    static String clean(String s, int max) {
        if (s == null) s = "";
        s = s.replaceAll("[|:;\\r\\n\\u0000]", " ").trim();
        if (s.length() > max) s = s.substring(0, max).trim();
        return s.isEmpty() ? "Игрок" : s;
    }

    private static void daemon(Runnable r, String name) {
        Thread t = new Thread(r, name);
        t.setDaemon(true);
        t.start();
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { }
    }

    private static void closeQuiet(java.io.Closeable c) {
        if (c == null) return;
        try { c.close(); } catch (Exception ignored) { }
    }

    private static void closeQuiet(Socket s) {
        if (s == null) return;
        try { s.close(); } catch (Exception ignored) { }
    }
}
