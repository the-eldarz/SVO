package com.bodycamclone;

public final class Config {
    private Config() {}
    public static final int SIDE_RU = 0, SIDE_UA = 1;
    /** Модели бойцов. Файлы лежат в app/src/main/assets/models/ (workflow копирует туда все *.glb из корня репозитория). */
    public static final String RU_MODEL = "models/russian_vdv_paratrooper.glb";
    public static final String UA_MODEL = "models/ukrainian_soldier.glb";
    public static final float SOLDIER_HEIGHT = 1.8f;

    /** Модель автомата. Кладётся в репозиторий как ak-74m.glb (workflow копирует её в models/). Размер, ось ствола и где дуло игра определяет сама. */
    public static final String AK_MODEL = "models/ak-74m.glb";
    /** Длина автомата в руках бойца (м) и в кадре у игрока. */
    public static final float AK_LENGTH_WORLD = 0.94f, AK_LENGTH_VIEW = 1.05f;
    /** Где у модели пистолетная рукоять: доля длины от приклада и доля высоты от низа магазина. */
    public static final float AK_GRIP_Z = 0.36f, AK_GRIP_Y = 0.55f;
    /** Сдвиг автомата в кадре игрока по вертикали (рукоять ниже оси ствола). */
    public static final float AK_VIEW_DY = -0.07f;
    /** Сдвиг хвата бойца вперёд вдоль ствола от запястья (м). */
    public static final float AK_HAND_FWD = 0.04f;
    /** Поставь true, если дуло определилось неправильно (автомат смотрит прикладом вперёд). */
    public static final boolean AK_FLIP = false;
    /** Если модель смотрит не туда (лицом назад/вбок) - поправь угол для нужной модели: 180, 90, -90 */
    public static final float RU_YAW_OFFSET_DEG = 0f;
    public static final float UA_YAW_OFFSET_DEG = 0f;
    public static final float[] ALLY_TINT = {0.92f, 0.98f, 1.12f};
    public static final float[] ENEMY_TINT = {1.0f, 1.0f, 1.0f};
    public static final float MAP_HALF = 50f;
    public static final int ALLIES = 4;
    public static final float LOOK_SENS = 0.0030f;

    /** Карты: пока это разные расстановки укрытий одного генератора. */
    public static final String[] MAP_NAMES = {"Окраина", "Посёлок", "Промзона"};
    public static final String[] MAP_DESC = {"Расстановка укрытий №1", "Расстановка укрытий №2", "Расстановка укрытий №3"};
    public static final long[] MAP_SEEDS = {7L, 21L, 99L};

    /** Поле зрения: обычное, при прицеливании, и шаги кнопки зума (кратность). */
    public static final float BASE_FOV = 72f, ADS_FOV = 56f;
    public static final float[] ZOOM_STEPS = {1f, 2f, 4f};
}
