package com.bodycamclone;

public final class Config {
    private Config() {}
    public static final int SIDE_RU = 0, SIDE_UA = 1;
    /** Модели бойцов. Файлы лежат в кэше игры (папка models/ внутри BodycamGame), запасной вариант - app/src/main/assets/models/. */
    public static final String RU_MODEL = "models/russian_soldier.glb";
    public static final String UA_MODEL = "models/ukrainian_soldier.glb";
    public static final float SOLDIER_HEIGHT = 1.8f;

    /** Модель автомата. Кладётся в репозиторий как ak-74m.glb (workflow копирует её в models/). Размер, ось ствола и где дуло игра определяет сама. */
    public static final String AK_MODEL = "models/ak-74m.glb";
    /** Длина автомата в руках бойца (м) и в кадре у игрока. */
    public static final float AK_LENGTH_WORLD = 0.94f, AK_LENGTH_VIEW = 1.05f;
    /** Где у модели пистолетная рукоять: доля длины от приклада и доля высоты от низа магазина. */
    public static final float AK_GRIP_Z = 0.36f, AK_GRIP_Y = 0.55f;
    /** Сдвиг автомата в кадре игрока по вертикали (рукоять ниже оси ствола). */
    public static final float AK_VIEW_DY = -0.07f;
    /** Сдвиг хвата бойца вперёд вдоль ствола от запястья (м). */
    public static final float AK_HAND_FWD = 0.04f;
    /** Поставь true, если дуло определилось неправильно (автомат смотрит прикладом вперёд). */
    public static final boolean AK_FLIP = false;
    /** Если модель смотрит не туда (лицом назад/вбок) - поправь угол для нужной модели: 180, 90, -90 */
    public static final float RU_YAW_OFFSET_DEG = 0f;
    public static final float UA_YAW_OFFSET_DEG = 0f;
    public static final float[] ALLY_TINT = {0.92f, 0.98f, 1.12f};
    public static final float[] ENEMY_TINT = {1.0f, 1.0f, 1.0f};
    public static final float MAP_HALF = 50f;
    public static final int ALLIES = 4;
    public static final float LOOK_SENS = 0.0030f;

    /** Карты. Индекс = положение в массивах; у каждой свой генератор в WorldMap. На обеих три точки захвата A/B/C и пункты снабжения на базах. */
    public static final String[] MAP_NAMES = {"Большой лес", "Арена CS (zm_opt_tr)"};
    public static final String[] MAP_DESC = {"Огромная карта 180×180 м: чаща, тропы, поляны с блиндажами",
            "Открытая арена 55×88 м из CS:S: пилоны, щиты у баз, стрельба на дальность. Без текстур, только цвета"};
    public static final long[] MAP_SEEDS = {314L, 1001L};
    /** Половина стороны каждой карты (м). */
    public static final float[] MAP_HALVES = {90f, 44f};

    public static int mapIndex(long seed) {
        for (int i = 0; i < MAP_SEEDS.length; i++) if (MAP_SEEDS[i] == seed) return i;
        return 0;
    }

    public static float mapHalf(int idx) { return MAP_HALVES[Math.max(0, Math.min(MAP_HALVES.length - 1, idx))]; }

    /** Поле зрения: обычное, при прицеливании, и шаги кнопки зума (кратность). */
    public static final float BASE_FOV = 72f, ADS_FOV = 56f;
    /** Бинокль (только у командира): кратность приближения. Обычного зума 2x / 4x у бойцов больше нет. */
    public static final float BINOC_ZOOM = 6f;

    /** Формы бойца = отдельные модели. Форма 1 - models/russian_soldier.glb и ukrainian_soldier.glb, форма 2 - russian_soldier2.glb и ukrainian_soldier2.glb, форма N - ...soldierN.glb. Нет файла - модель формы 1. */
    public static final String[] UNIFORM_NAMES = {"Форма 1", "Форма 2"};
    /** Камуфляж: оттенок, который накладывается на выбранную форму. */
    public static final String[] CAMO_NAMES = {"Без камуфляжа", "Лес", "Пустыня", "Тёмный", "Зима"};
    public static final float[][] CAMO_TINT = {{1f, 1f, 1f}, {0.80f, 1.00f, 0.72f}, {1.28f, 1.12f, 0.82f}, {0.55f, 0.58f, 0.66f}, {1.30f, 1.36f, 1.48f}};
    /** Классы бойцов. Командир: бинокль + 4 гранаты. Штурмовик: ровно 2 гранаты. Медик: аптечки, гранат нет. У всех есть основное оружие и пистолет. */
    public static final int CLASS_COMMANDER = 0, CLASS_ASSAULT = 1, CLASS_MEDIC = 2;
    public static final String[] CLASS_NAMES = {"Командир", "Штурмовик", "Медик"};
    public static final int[] CLASS_GRENADES = {4, 2, 0};
    public static final int[] CLASS_MEDKITS = {0, 0, 3};
    public static int classGrenades(int cls) { return CLASS_GRENADES[Math.max(0, Math.min(2, cls))]; }
    public static int classMedkits(int cls) { return CLASS_MEDKITS[Math.max(0, Math.min(2, cls))]; }
    public static boolean hasBinoculars(int cls) { return cls == CLASS_COMMANDER; }
    /** Аптечка: сколько здоровья возвращает и сколько секунд длится применение (оружие в это время опущено). */
    public static final float MEDKIT_HEAL = 55f, MEDKIT_TIME = 2.2f;
    /** Ящик с патронами добавляет к запасу патронов АК и ПМ. */
    public static final int AMMO_BOX_RIFLE = 90, AMMO_BOX_PISTOL = 24;

    public static float[] camoTint(int idx) {
        return CAMO_TINT[Math.max(0, Math.min(CAMO_TINT.length - 1, idx))];
    }

    /** Путь к модели бойца для стороны и формы: файл ...soldier<N+1>.glb, если он есть, иначе модель формы 1. */
    public static String uniformModel(int side, int idx) {
        String base = side == SIDE_RU ? RU_MODEL : UA_MODEL;
        if (idx <= 0) return base;
        String p = "models/" + (side == SIDE_RU ? "russian_soldier" : "ukrainian_soldier") + (idx + 1) + ".glb";
        return GameFiles.exists(p) ? p : base;
    }

    /** Осколочная граната: время до взрыва (с), радиус поражения (м), урон в упор, скорость броска (м/с). */
    public static final float GRENADE_FUSE = 2.8f, GRENADE_RADIUS = 8f, GRENADE_DMG = 210f, GRENADE_SPEED = 13f;
}
