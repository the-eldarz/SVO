package com.bodycamclone;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Прозрачный слой поверх 3D: bodycam-оверлей, HUD, джойстик, кнопки в стиле Standoff, зона стрельбы, обработка касаний. */
public class HudView extends View {
    private static final int R_NONE = 0, R_JOY = 1, R_LOOK = 2, R_FIRE = 3, R_BTN = 4, R_AIM = 5, R_ZONE = 6, R_WEAPON = 7;
    private final Game game;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private RadialGradient vig;
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss", Locale.US);
    private final int[] role = new int[32], rbtn = new int[32];
    private final float[] lx = new float[32], ly = new float[32], wx0 = new float[32], wy0 = new float[32];
    private final long[] wt0 = new long[32];
    private final boolean[] wSwiped = new boolean[32];
    private final boolean[] pressed = new boolean[Settings.COUNT];
    private float joyOx, joyOy, joyX, joyY;
    private boolean joyOn;

    public HudView(Context c, Game g) {
        super(c);
        game = g;
        d = c.getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float r = (float) Math.hypot(w, h) / 2f;
        vig = new RadialGradient(w / 2f, h / 2f, r, new int[]{0x00000000, 0x00000000, 0x88000000},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
    }

    private float joyR() { return Settings.joyRad(d); }
    private float joyBaseX() { return Settings.joyCx(getWidth(), d); }
    private float joyBaseY() { return Settings.joyCy(getHeight(), d); }

    private boolean zoneActive() { return Settings.fireMode != Settings.FIRE_BTN_ONLY; }

    private boolean inZone(float x, float y) {
        int w = getWidth(), h = getHeight();
        return x >= Settings.zx * w && x <= (Settings.zx + Settings.zw) * w && y >= Settings.zy * h && y <= (Settings.zy + Settings.zh) * h;
    }

    /** Огонь идёт, пока удерживается кнопка огня или палец в зоне стрельбы. */
    private void updateFire() {
        boolean f = false;
        for (int k = 0; k < 32; k++) if (role[k] == R_FIRE || role[k] == R_ZONE) { f = true; break; }
        game.input.fire = f;
    }

    /** Сбросить все касания (при паузе). Вызывать из UI-потока. */
    public void releaseInput() {
        for (int k = 0; k < 32; k++) role[k] = R_NONE;
        Game.Input in = game.input;
        in.fire = false; in.moveX = 0; in.moveY = 0; joyOn = false;
        in.crouchHeld = false; in.proneHeld = false; in.leanL = false; in.leanR = false;
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        Game.Player pl = game.p;
        p.setStyle(Paint.Style.FILL);
        if (vig != null) { p.setShader(vig); c.drawRect(0, 0, w, h, p); p.setShader(null); }
        if (pl.hurtT > 0f) { p.setColor(Color.argb((int) (160 * Math.min(1f, pl.hurtT / 0.4f)), 200, 0, 0)); c.drawRect(0, 0, w, h, p); }

        // bodycam: REC и время
        p.setTextSize(16 * d); p.setTypeface(android.graphics.Typeface.MONOSPACE);
        if (((int) (game.time * 1.5f)) % 2 == 0) { p.setColor(Color.RED); c.drawCircle(24 * d, 26 * d, 6 * d, p); }
        p.setColor(Color.WHITE);
        c.drawText("REC", 36 * d, 32 * d, p);
        p.setTextSize(13 * d);
        c.drawText(sdf.format(new Date()), 16 * d, h - 14 * d, p);
        int t = (int) game.time;
        c.drawText(String.format(Locale.US, "%02d:%02d:%02d", t / 3600, (t / 60) % 60, t % 60), 16 * d, 52 * d, p);
        p.setTypeface(android.graphics.Typeface.DEFAULT);

        // верх справа: волна/счёт
        p.setTextAlign(Paint.Align.RIGHT);
        p.setTextSize(14 * d);
        if (game.net == null) {
            c.drawText("Волна " + game.wave + "   Убито " + game.kills, w - 16 * d, 28 * d, p);
            c.drawText("Враги " + game.enemiesLeft + "   Наши " + game.alliesLeft, w - 16 * d, 48 * d, p);
        } else drawNetScore(c, w);
        p.setTextAlign(Paint.Align.LEFT);
        if (game.net != null) drawFeed(c);

        // статус модели
        String st = game.status;
        if (st != null && st.length() > 0 && (game.statusError || game.time < 10f)) {
            p.setTextAlign(Paint.Align.CENTER); p.setTextSize(12 * d);
            p.setColor(game.statusError ? Color.YELLOW : Color.LTGRAY);
            c.drawText(st, w / 2f, 20 * d, p);
            p.setTextAlign(Paint.Align.LEFT); p.setColor(Color.WHITE);
        }

        // перекрестие (от бедра / в прицеле) и маркер попадания
        ControlsUi.drawCrosshair(c, p, w / 2f, h / 2f, d, pl.aimT > 0.5f ? 1 : 0);
        p.setStyle(Paint.Style.FILL);
        if (pl.hitT > 0f) {
            p.setColor(Color.WHITE); p.setStrokeWidth(2 * d); float a = 8 * d, b = 14 * d;
            for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2)
                c.drawLine(w / 2f + sx * a, h / 2f + sy * a, w / 2f + sx * b, h / 2f + sy * b, p);
        }

        // здоровье
        float bw = 180 * d, bh = 10 * d, bx = w / 2f - bw / 2f, by = h - 28 * d;
        p.setColor(0x66000000); c.drawRect(bx, by, bx + bw, by + bh, p);
        p.setColor(pl.hp > 35 ? Color.rgb(90, 200, 90) : Color.rgb(220, 60, 50));
        c.drawRect(bx, by, bx + bw * Math.max(0f, pl.hp) / 100f, by + bh, p);

        // кнопки: что сейчас нажато пальцем
        java.util.Arrays.fill(pressed, false);
        for (int k = 0; k < 32; k++) if ((role[k] == R_FIRE || role[k] == R_AIM || role[k] == R_BTN || role[k] == R_WEAPON) && rbtn[k] >= 0 && rbtn[k] < Settings.COUNT) pressed[rbtn[k]] = true;
        if (zoneActive()) for (int k = 0; k < 32; k++) if (role[k] == R_ZONE) { pressed[Settings.B_FIRE] = true; pressed[Settings.B_FIRE2] = true; }

        // джойстик: основание всегда видно, как в Standoff
        float jx = joyOn ? joyOx : joyBaseX(), jy = joyOn ? joyOy : joyBaseY();
        ControlsUi.drawJoystick(c, p, jx, jy, joyR(), joyOn ? joyX : 0f, joyOn ? joyY : 0f, joyOn, Settings.joyAlpha);

        for (int i = 0; i < Settings.COUNT; i++) {
            if (Settings.hidden(i)) continue;
            boolean active = (i == Settings.B_AIM && game.input.ads) || (i == Settings.B_ZOOM && pl.zoom > 0)
                    || (i == Settings.B_CROUCH && pl.crouched) || (i == Settings.B_PRONE && pl.prone)
                    || (i == Settings.B_LEAN_L && pl.leanOff < -0.02f) || (i == Settings.B_LEAN_R && pl.leanOff > 0.02f);
            ControlsUi.drawButton(c, p, i, Settings.cx(i, w, d), Settings.cy(i, h, d), d, active, pressed[i], 1f, pl);
        }
        p.setTextAlign(Paint.Align.LEFT);

        if (!pl.alive) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xAA000000); c.drawRect(0, 0, w, h, p);
            p.setColor(Color.rgb(230, 60, 50)); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(48 * d);
            c.drawText("УБИТ", w / 2f, h / 2f - 10 * d, p);
            p.setColor(Color.WHITE); p.setTextSize(16 * d);
            if (game.net != null) {
                c.drawText("Возрождение через " + Math.max(1, (int) Math.ceil(4f - pl.deadT)), w / 2f, h / 2f + 22 * d, p);
            } else {
                c.drawText("Убито: " + game.kills + "   Волна: " + game.wave, w / 2f, h / 2f + 22 * d, p);
                if (pl.deadT > 1f) c.drawText("Коснись экрана, чтобы начать заново", w / 2f, h / 2f + 52 * d, p);
            }
            p.setTextAlign(Paint.Align.LEFT);
        }
        postInvalidateOnAnimation();
    }

    /** Кнопка под пальцем (с запасом на промах) или -1. Скрытые кнопки не считаются. */
    private int hitButton(float x, float y) {
        int hit = -1;
        float best = 1.15f;
        for (int k = 0; k < Settings.COUNT; k++) {
            if (Settings.hidden(k)) continue;
            float ratio = Settings.ratio(k, x, y, getWidth(), getHeight(), d);
            if (ratio < best) { best = ratio; hit = k; }
        }
        return hit;
    }

    /** Мультиплеер: название комнаты, мой счёт и таблица игроков (зелёные - моя команда, красные - враги). */
    private void drawNetScore(Canvas c, int w) {
        Net net = game.net;
        p.setTextAlign(Paint.Align.RIGHT);
        p.setTextSize(13 * d);
        p.setColor(Color.LTGRAY);
        c.drawText(net.roomName + "  ·  " + net.playerCount() + "/" + Net.MAX_PLAYERS, w - 16 * d, 28 * d, p);
        java.util.List<Net.PInfo> list = new java.util.ArrayList<>(net.roster.values());
        java.util.Collections.sort(list, (a, b) -> b.kills != a.kills ? b.kills - a.kills : a.deaths - b.deaths);
        float y = 48 * d;
        for (Net.PInfo pl : list) {
            p.setColor(pl.id == net.myId ? Color.WHITE : (pl.team == net.myTeam ? Color.rgb(130, 220, 120) : Color.rgb(235, 100, 90)));
            c.drawText(pl.name + "   " + pl.kills + " / " + pl.deaths, w - 16 * d, y, p);
            y += 17 * d;
        }
        p.setColor(Color.WHITE);
    }

    /** Лента убийств слева под таймером. */
    private void drawFeed(Canvas c) {
        p.setTextAlign(Paint.Align.LEFT);
        p.setTextSize(13 * d);
        float y = 78 * d;
        for (Game.Feed f : game.feed) {
            p.setColor(Color.argb((int) (255 * Math.min(1f, f.life / 1.5f)), 255, 255, 255));
            c.drawText(f.text, 16 * d, y, p);
            y += 17 * d;
        }
        p.setColor(Color.WHITE);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked();
        Game.Input in = game.input;
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            int i = e.getActionIndex(), id = e.getPointerId(i);
            if (id >= 32) return true;
            if (act == MotionEvent.ACTION_DOWN && Settings.precise) requestUnbufferedDispatch(e);
            float x = e.getX(i), y = e.getY(i);
            lx[id] = x; ly[id] = y; rbtn[id] = -1;
            if (!game.p.alive) { synchronized (in) { in.restart = true; } role[id] = R_NONE; return true; }
            int hit = hitButton(x, y);
            if (hit == Settings.B_FIRE || hit == Settings.B_FIRE2) { role[id] = R_FIRE; rbtn[id] = hit; }
            else if (hit == Settings.B_AIM) { role[id] = R_AIM; rbtn[id] = hit; in.ads = Settings.adsToggle ? !in.ads : true; }
            else if (hit == Settings.B_WEAPON) {
                role[id] = R_WEAPON; rbtn[id] = hit;
                wx0[id] = x; wy0[id] = y; wt0[id] = SystemClock.uptimeMillis(); wSwiped[id] = false;
            }
            else if (hit >= 0) {
                role[id] = R_BTN; rbtn[id] = hit;
                synchronized (in) {
                    if (hit == Settings.B_ZOOM) in.zoom = true;
                    else if (hit == Settings.B_JUMP) in.jump = true;
                    else if (hit == Settings.B_LEAN_L) in.leanL = true;
                    else if (hit == Settings.B_LEAN_R) in.leanR = true;
                    else if (hit == Settings.B_CROUCH) { if (Settings.crouchHold) in.crouchHeld = true; else in.crouchToggle = true; }
                    else if (hit == Settings.B_PRONE) { if (Settings.proneHold) in.proneHeld = true; else in.proneToggle = true; }
                }
            }
            else if (zoneActive() && inZone(x, y)) role[id] = R_ZONE;
            else if (startJoy(id, x, y, in)) { /* джойстик взят */ }
            else role[id] = R_LOOK;
            updateFire();
        } else if (act == MotionEvent.ACTION_MOVE) {
            for (int i = 0; i < e.getPointerCount(); i++) {
                int id = e.getPointerId(i);
                if (id >= 32) continue;
                float x = e.getX(i), y = e.getY(i);
                if (role[id] == R_JOY) {
                    moveJoy(x, y, in);
                } else if (role[id] == R_LOOK) {
                    // палец в зоне стрельбы (R_ZONE) камеру НЕ двигает - там только огонь
                    // берём все накопленные промежуточные точки - поворот не теряет ни пикселя
                    for (int hs = 0; hs < e.getHistorySize(); hs++) {
                        float hx = e.getHistoricalX(i, hs), hy = e.getHistoricalY(i, hs);
                        synchronized (in) { in.lookDX += hx - lx[id]; in.lookDY += hy - ly[id]; }
                        lx[id] = hx; ly[id] = hy;
                    }
                    synchronized (in) { in.lookDX += x - lx[id]; in.lookDY += y - ly[id]; }
                    lx[id] = x; ly[id] = y;
                } else if (role[id] == R_WEAPON && !wSwiped[id]) {
                    // свайп по кнопке оружия - сменить оружие
                    float thr = 24f * d;
                    if (Math.abs(x - wx0[id]) > thr || Math.abs(y - wy0[id]) > thr) {
                        wSwiped[id] = true;
                        synchronized (in) { in.sw = true; }
                    }
                }
            }
        } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_POINTER_UP || act == MotionEvent.ACTION_CANCEL) {
            int i = e.getActionIndex(), id = e.getPointerId(i);
            if (act == MotionEvent.ACTION_CANCEL) {
                for (int k = 0; k < 32; k++) role[k] = R_NONE;
                in.fire = false; in.moveX = 0; in.moveY = 0; joyOn = false;
                in.crouchHeld = false; in.proneHeld = false; in.leanL = false; in.leanR = false;
                if (!Settings.adsToggle) in.ads = false;
                return true;
            }
            if (id < 32) {
                if (role[id] == R_JOY) { joyOn = false; in.moveX = 0; in.moveY = 0; }
                if (role[id] == R_AIM && !Settings.adsToggle) in.ads = false;
                if (role[id] == R_BTN && rbtn[id] == Settings.B_CROUCH) in.crouchHeld = false;
                if (role[id] == R_BTN && rbtn[id] == Settings.B_PRONE) in.proneHeld = false;
                if (role[id] == R_BTN && rbtn[id] == Settings.B_LEAN_L) in.leanL = false;
                if (role[id] == R_BTN && rbtn[id] == Settings.B_LEAN_R) in.leanR = false;
                if (role[id] == R_WEAPON && !wSwiped[id] && SystemClock.uptimeMillis() - wt0[id] < 500) {
                    synchronized (in) { in.reload = true; }    // короткое нажатие - перезарядка
                }
                role[id] = R_NONE; rbtn[id] = -1;
                updateFire();
            }
        }
        return true;
    }


    /** Берёт джойстик под палец по правилам выбранного режима: статичный / плавающий / свободный. */
    private boolean startJoy(int id, float x, float y, Game.Input in) {
        boolean inBase = Math.hypot(x - joyBaseX(), y - joyBaseY()) <= joyR() * 1.5f;
        boolean inRegion = Settings.joyRight ? x > getWidth() * 0.6f : x < getWidth() * 0.4f;
        if (inBase) { joyOx = joyBaseX(); joyOy = joyBaseY(); }
        else if (Settings.joyMode == Settings.JOY_FREE && inRegion) { joyOx = x; joyOy = y; }
        else return false;
        role[id] = R_JOY; joyOn = true; joyX = 0; joyY = 0;
        moveJoy(x, y, in);
        return true;
    }

    private void moveJoy(float x, float y, Game.Input in) {
        float R = joyR(), dx = x - joyOx, dy = y - joyOy;
        float l = (float) Math.hypot(dx, dy);
        if (l > R) {
            if (Settings.joyMode == Settings.JOY_FLOAT) {          // плавающий: основание едет за пальцем
                joyOx += dx * (l - R) / l; joyOy += dy * (l - R) / l;
                dx = x - joyOx; dy = y - joyOy;
            } else { dx *= R / l; dy *= R / l; }
        }
        joyX = dx; joyY = dy;
        in.moveX = dx / R; in.moveY = -dy / R;
    }
}
