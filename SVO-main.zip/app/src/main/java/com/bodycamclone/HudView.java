package com.bodycamclone;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Прозрачный слой поверх 3D: bodycam-оверлей, HUD, джойстик, кнопки, обработка касаний. */
public class HudView extends View {
    private static final int R_NONE = 0, R_JOY = 1, R_LOOK = 2, R_FIRE = 3, R_BTN = 4, R_AIM = 5;
    private final Game game;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private RadialGradient vig;
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss", Locale.US);
    private final int[] role = new int[32];
    private final float[] lx = new float[32], ly = new float[32];
    private float joyOx, joyOy, joyX, joyY;
    private boolean joyOn;

    public HudView(Context c, Game g) {
        super(c);
        game = g;
        d = c.getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float r = (float) Math.hypot(w, h) / 2f;
        vig = new RadialGradient(w / 2f, h / 2f, r, new int[]{0x00000000, 0x00000000, 0x88000000},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
    }

    private boolean in(float x, float y, float cx, float cy, float r) { return Math.hypot(x - cx, y - cy) <= r; }

    /** Сбросить все касания (при паузе). Вызывать из UI-потока. */
    public void releaseInput() {
        for (int k = 0; k < 32; k++) role[k] = R_NONE;
        Game.Input in = game.input;
        in.fire = false; in.moveX = 0; in.moveY = 0; joyOn = false;
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        Game.Player pl = game.p;
        p.setStyle(Paint.Style.FILL);
        if (vig != null) { p.setShader(vig); c.drawRect(0, 0, w, h, p); p.setShader(null); }
        if (pl.hurtT > 0f) { p.setColor(Color.argb((int) (160 * Math.min(1f, pl.hurtT / 0.4f)), 200, 0, 0)); c.drawRect(0, 0, w, h, p); }

        // bodycam: REC и время
        p.setTextSize(16 * d); p.setTypeface(android.graphics.Typeface.MONOSPACE);
        if (((int) (game.time * 1.5f)) % 2 == 0) { p.setColor(Color.RED); c.drawCircle(24 * d, 26 * d, 6 * d, p); }
        p.setColor(Color.WHITE);
        c.drawText("REC", 36 * d, 32 * d, p);
        p.setTextSize(13 * d);
        c.drawText(sdf.format(new Date()), 16 * d, h - 14 * d, p);
        int t = (int) game.time;
        c.drawText(String.format(Locale.US, "%02d:%02d:%02d", t / 3600, (t / 60) % 60, t % 60), 16 * d, 52 * d, p);

        // верх справа: волна/счёт
        p.setTextAlign(Paint.Align.RIGHT);
        p.setTextSize(14 * d);
        c.drawText("Волна " + game.wave + "   Убито " + game.kills, w - 16 * d, 28 * d, p);
        c.drawText("Враги " + game.enemiesLeft + "   Наши " + game.alliesLeft, w - 16 * d, 48 * d, p);
        p.setTextAlign(Paint.Align.LEFT);

        // статус модели
        String st = game.status;
        if (st != null && st.length() > 0 && (game.statusError || game.time < 10f)) {
            p.setTextAlign(Paint.Align.CENTER); p.setTextSize(12 * d);
            p.setColor(game.statusError ? Color.YELLOW : Color.LTGRAY);
            c.drawText(st, w / 2f, 20 * d, p);
            p.setTextAlign(Paint.Align.LEFT); p.setColor(Color.WHITE);
        }

        // прицел и маркер попадания
        p.setColor(Color.argb(200, 255, 255, 255)); c.drawCircle(w / 2f, h / 2f, 2 * d, p);
        if (pl.hitT > 0f) {
            p.setStrokeWidth(2 * d); float a = 8 * d, b = 14 * d;
            for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2)
                c.drawLine(w / 2f + sx * a, h / 2f + sy * a, w / 2f + sx * b, h / 2f + sy * b, p);
        }

        // здоровье
        float bw = 180 * d, bh = 10 * d, bx = w / 2f - bw / 2f, by = h - 28 * d;
        p.setColor(0x66000000); c.drawRect(bx, by, bx + bw, by + bh, p);
        p.setColor(pl.hp > 35 ? Color.rgb(90, 200, 90) : Color.rgb(220, 60, 50));
        c.drawRect(bx, by, bx + bw * Math.max(0f, pl.hp) / 100f, by + bh, p);

        // патроны
        p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.RIGHT); p.setTextSize(20 * d);
        int wp = pl.weapon;
        String ammo = pl.reloadT > 0f ? "перезарядка..." : pl.ammo[wp] + " / " + pl.reserve[wp];
        c.drawText(Game.W_NAME[wp] + "  " + ammo, w - 16 * d, 76 * d, p);
        p.setTextAlign(Paint.Align.LEFT);

        // кнопки (положение и размер берутся из настроек)
        p.setTextAlign(Paint.Align.CENTER);
        for (int i = 0; i < Settings.COUNT; i++) {
            float bx0 = Settings.cx(i, w, d), by0 = Settings.cy(i, h, d), br = Settings.rad(i, d);
            boolean on = i == Settings.B_AIM && game.input.ads;
            p.setStyle(Paint.Style.FILL); p.setColor(on ? 0x889CC48F : 0x55FFFFFF);
            c.drawCircle(bx0, by0, br, p);
            String label = Settings.LABEL[i];
            if (i == Settings.B_ZOOM && pl.zoom > 0) label = "ЗУМ x" + (int) Config.ZOOM_STEPS[pl.zoom];
            p.setColor(Color.WHITE); p.setTextSize(13 * d * Math.max(0.8f, Settings.sc[i]));
            c.drawText(label, bx0, by0 + 4 * d, p);
        }
        p.setTextAlign(Paint.Align.LEFT);

        // Дополнительные стойки: присесть и лечь. Расположены слева от боевых кнопок.
        float stanceX = w - 292f * d;
        float crouchY = h - 105f * d, proneY = h - 180f * d, stanceR = 29f * d;
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(11f * d);
        p.setColor(pl.crouched ? 0xCC77AADD : 0x66777777);
        c.drawCircle(stanceX, crouchY, stanceR, p);
        p.setColor(Color.WHITE); c.drawText("ПРИСЕСТЬ", stanceX, crouchY + 4f * d, p);
        p.setColor(pl.prone ? 0xCC77AADD : 0x66777777);
        c.drawCircle(stanceX, proneY, stanceR, p);
        p.setColor(Color.WHITE); c.drawText("ЛЕЧЬ", stanceX, proneY + 4f * d, p);
        p.setTextAlign(Paint.Align.LEFT);

        // джойстик
        if (joyOn) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2 * d); p.setColor(0x88FFFFFF);
            c.drawCircle(joyOx, joyOy, 70 * d, p);
            p.setStyle(Paint.Style.FILL); p.setColor(0x66FFFFFF);
            c.drawCircle(joyOx + joyX, joyOy + joyY, 28 * d, p);
        }

        if (!pl.alive) {
            p.setColor(0xAA000000); c.drawRect(0, 0, w, h, p);
            p.setColor(Color.rgb(230, 60, 50)); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(48 * d);
            c.drawText("УБИТ", w / 2f, h / 2f - 10 * d, p);
            p.setColor(Color.WHITE); p.setTextSize(16 * d);
            c.drawText("Убито: " + game.kills + "   Волна: " + game.wave, w / 2f, h / 2f + 22 * d, p);
            if (pl.deadT > 1f) c.drawText("Коснись экрана, чтобы начать заново", w / 2f, h / 2f + 52 * d, p);
            p.setTextAlign(Paint.Align.LEFT);
        }
        postInvalidateOnAnimation();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked();
        Game.Input in = game.input;
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            int i = e.getActionIndex(), id = e.getPointerId(i);
            if (id >= 32) return true;
            float x = e.getX(i), y = e.getY(i);
            lx[id] = x; ly[id] = y;
            float sx = getWidth() - 292f * d;
            if (Math.hypot(x - sx, y - (getHeight() - 105f * d)) <= 34f * d) {
                synchronized (in) { in.crouchToggle = true; }
                role[id] = R_BTN; return true;
            }
            if (Math.hypot(x - sx, y - (getHeight() - 180f * d)) <= 34f * d) {
                synchronized (in) { in.proneToggle = true; }
                role[id] = R_BTN; return true;
            }
            if (!game.p.alive) { synchronized (in) { in.restart = true; } role[id] = R_NONE; return true; }
            int hit = -1;
            float bestRatio = 1.15f;
            for (int k = 0; k < Settings.COUNT; k++) {
                float ratio = (float) Math.hypot(x - Settings.cx(k, getWidth(), d), y - Settings.cy(k, getHeight(), d)) / Settings.rad(k, d);
                if (ratio < bestRatio) { bestRatio = ratio; hit = k; }
            }
            if (hit == Settings.B_FIRE) { role[id] = R_FIRE; in.fire = true; }
            else if (hit == Settings.B_AIM) { role[id] = R_AIM; in.ads = Settings.adsToggle ? !in.ads : true; }
            else if (hit >= 0) {
                role[id] = R_BTN;
                synchronized (in) {
                    if (hit == Settings.B_RELOAD) in.reload = true;
                    else if (hit == Settings.B_WEAPON) in.sw = true;
                    else if (hit == Settings.B_ZOOM) in.zoom = true;
                }
            }
            else if (x < getWidth() * 0.4f) { role[id] = R_JOY; joyOn = true; joyOx = x; joyOy = y; joyX = 0; joyY = 0; }
            else role[id] = R_LOOK;
        } else if (act == MotionEvent.ACTION_MOVE) {
            for (int i = 0; i < e.getPointerCount(); i++) {
                int id = e.getPointerId(i);
                if (id >= 32) continue;
                float x = e.getX(i), y = e.getY(i);
                if (role[id] == R_JOY) {
                    float R = 70 * d, dx = x - joyOx, dy = y - joyOy;
                    float l = (float) Math.hypot(dx, dy);
                    if (l > R) { dx *= R / l; dy *= R / l; }
                    joyX = dx; joyY = dy;
                    in.moveX = dx / R; in.moveY = -dy / R;
                } else if (role[id] == R_LOOK) {
                    synchronized (in) { in.lookDX += x - lx[id]; in.lookDY += y - ly[id]; }
                    lx[id] = x; ly[id] = y;
                }
            }
        } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_POINTER_UP || act == MotionEvent.ACTION_CANCEL) {
            int i = e.getActionIndex(), id = e.getPointerId(i);
            if (act == MotionEvent.ACTION_CANCEL) {
                for (int k = 0; k < 32; k++) role[k] = R_NONE;
                in.fire = false; in.moveX = 0; in.moveY = 0; joyOn = false;
                if (!Settings.adsToggle) in.ads = false;
                return true;
            }
            if (id < 32) {
                if (role[id] == R_JOY) { joyOn = false; in.moveX = 0; in.moveY = 0; }
                if (role[id] == R_FIRE) in.fire = false;
                if (role[id] == R_AIM && !Settings.adsToggle) in.ads = false;
                role[id] = R_NONE;
            }
        }
        return true;
    }
}
