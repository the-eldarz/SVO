package com.bodycamclone;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Прозрачный слой поверх 3D: bodycam-оверлей, HUD, джойстик, кнопки в стиле Standoff, зона стрельбы, обработка касаний. */
public class HudView extends View {
    private static final int R_NONE = 0, R_JOY = 1, R_LOOK = 2, R_FIRE = 3, R_BTN = 4, R_AIM = 5, R_ZONE = 6, R_WEAPON = 7;
    private final Game game;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private RadialGradient vig;
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss", Locale.US);
    private final int[] role = new int[32], rbtn = new int[32];
    private final float[] lx = new float[32], ly = new float[32], wx0 = new float[32], wy0 = new float[32];
    private final long[] wt0 = new long[32];
    private final boolean[] wSwiped = new boolean[32];
    private final boolean[] pressed = new boolean[Settings.COUNT];
    private float joyOx, joyOy, joyX, joyY;
    private boolean joyOn;

    public HudView(Context c, Game g) {
        super(c);
        game = g;
        d = c.getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float r = (float) Math.hypot(w, h) / 2f;
        vig = new RadialGradient(w / 2f, h / 2f, r, new int[]{0x00000000, 0x00000000, 0x88000000},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
    }

    private float joyR() { return Settings.joyRad(d); }
    private float joyBaseX() { return Settings.joyCx(getWidth(), d); }
    private float joyBaseY() { return Settings.joyCy(getHeight(), d); }

    private boolean zoneActive() { return Settings.fireMode != Settings.FIRE_BTN_ONLY; }

    private boolean inZone(float x, float y) {
        int w = getWidth(), h = getHeight();
        return x >= Settings.zx * w && x <= (Settings.zx + Settings.zw) * w && y >= Settings.zy * h && y <= (Settings.zy + Settings.zh) * h;
    }

    /** Огонь идёт, пока удерживается кнопка огня или палец в зоне стрельбы. */
    private void updateFire() {
        boolean f = false;
        for (int k = 0; k < 32; k++) if (role[k] == R_FIRE || role[k] == R_ZONE) { f = true; break; }
        game.input.fire = f;
    }

    /** Сбросить все касания (при паузе). Вызывать из UI-потока. */
    public void releaseInput() {
        for (int k = 0; k < 32; k++) role[k] = R_NONE;
        Game.Input in = game.input;
        in.fire = false; in.moveX = 0; in.moveY = 0; joyOn = false;
        in.crouchHeld = false; in.proneHeld = false; in.leanL = false; in.leanR = false;
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        Game.Player pl = game.p;
        p.setStyle(Paint.Style.FILL);
        if (vig != null) { p.setShader(vig); c.drawRect(0, 0, w, h, p); p.setShader(null); }
        if (game.blastFlash > 0f) { p.setColor(Color.argb((int) (230 * Math.min(1f, game.blastFlash)), 255, 245, 220)); c.drawRect(0, 0, w, h, p); }
        if (pl.hurtT > 0f) { p.setColor(Color.argb((int) (160 * Math.min(1f, pl.hurtT / 0.4f)), 200, 0, 0)); c.drawRect(0, 0, w, h, p); }

        // bodycam: REC и время
        p.setTextSize(16 * d); p.setTypeface(android.graphics.Typeface.MONOSPACE);
        if (((int) (game.time * 1.5f)) % 2 == 0) { p.setColor(Color.RED); c.drawCircle(24 * d, 26 * d, 6 * d, p); }
        p.setColor(Color.WHITE);
        c.drawText("REC", 36 * d, 32 * d, p);
        p.setTextSize(13 * d);
        c.drawText(sdf.format(new Date()), 16 * d, h - 14 * d, p);
        int t = (int) game.time;
        c.drawText(String.format(Locale.US, "%02d:%02d:%02d", t / 3600, (t / 60) % 60, t % 60), 16 * d, 52 * d, p);
        p.setTypeface(android.graphics.Typeface.DEFAULT);

        // верх справа: волна/счёт
        p.setTextAlign(Paint.Align.RIGHT);
        p.setTextSize(14 * d);
        if (game.net == null) {
            c.drawText("Волна " + game.wave + "   Убито " + game.kills, w - 16 * d, 28 * d, p);
            c.drawText("Враги " + game.enemiesLeft + "   Наши " + game.alliesLeft, w - 16 * d, 48 * d, p);
        } else drawNetScore(c, w);
        p.setTextAlign(Paint.Align.LEFT);
        if (game.net != null) drawFeed(c);

        // частота кадров (настройки -> Видео)
        if (Settings.showFps) {
            p.setTypeface(android.graphics.Typeface.MONOSPACE);
            p.setTextSize(13 * d);
            p.setColor(game.fps >= Settings.fpsTarget() * 0.9f ? 0xFF8CFF8C : (game.fps >= Settings.fpsTarget() * 0.6f ? 0xFFFFD060 : 0xFFFF7060));
            c.drawText(String.format(Locale.US, "%d FPS", Math.round(game.fps)), 92 * d, 31 * d, p);
            p.setTypeface(android.graphics.Typeface.DEFAULT);
            p.setColor(Color.WHITE);
        }

        drawPoints(c, w, h);

        // перекрестие (от бедра / в прицеле) и маркер попадания
        if (pl.binoc < 0.5f) ControlsUi.drawCrosshair(c, p, w / 2f, h / 2f, d, pl.aimT > 0.5f ? 1 : 0);
        p.setStyle(Paint.Style.FILL);
        if (pl.hitT > 0f) {
            p.setColor(Color.WHITE); p.setStrokeWidth(2 * d); float a = 8 * d, b = 14 * d;
            for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2)
                c.drawLine(w / 2f + sx * a, h / 2f + sy * a, w / 2f + sx * b, h / 2f + sy * b, p);
        }

        drawBinocularView(c, w, h);
        drawHealBar(c, w, h);

        // здоровье
        float bw = 180 * d, bh = 10 * d, bx = w / 2f - bw / 2f, by = h - 28 * d;
        p.setColor(0x66000000); c.drawRect(bx, by, bx + bw, by + bh, p);
        p.setColor(pl.hp > 35 ? Color.rgb(90, 200, 90) : Color.rgb(220, 60, 50));
        c.drawRect(bx, by, bx + bw * Math.max(0f, pl.hp) / 100f, by + bh, p);

        drawSupplyHint(c, w, by);

        // кнопки: что сейчас нажато пальцем
        java.util.Arrays.fill(pressed, false);
        for (int k = 0; k < 32; k++) if ((role[k] == R_FIRE || role[k] == R_AIM || role[k] == R_BTN || role[k] == R_WEAPON) && rbtn[k] >= 0 && rbtn[k] < Settings.COUNT) pressed[rbtn[k]] = true;
        if (zoneActive()) for (int k = 0; k < 32; k++) if (role[k] == R_ZONE) { pressed[Settings.B_FIRE] = true; pressed[Settings.B_FIRE2] = true; }

        // джойстик: основание всегда видно, как в Standoff
        float jx = joyOn ? joyOx : joyBaseX(), jy = joyOn ? joyOy : joyBaseY();
        ControlsUi.drawJoystick(c, p, jx, jy, joyR(), joyOn ? joyX : 0f, joyOn ? joyY : 0f, joyOn, Settings.joyAlpha);

        for (int i = 0; i < Settings.COUNT; i++) {
            if (Settings.hidden(i)) continue;
            boolean active = (i == Settings.B_AIM && game.input.ads) || (i == Settings.B_ZOOM && pl.zoom > 0) || (i == Settings.B_MEDKIT && pl.healT > 0f)
                    || (i == Settings.B_CROUCH && pl.crouched) || (i == Settings.B_PRONE && pl.prone)
                    || (i == Settings.B_LEAN_L && pl.leanOff < -0.02f) || (i == Settings.B_LEAN_R && pl.leanOff > 0.02f);
            ControlsUi.drawButton(c, p, i, Settings.cx(i, w, d), Settings.cy(i, h, d), d, active, pressed[i], 1f, pl);
        }
        p.setTextAlign(Paint.Align.LEFT);

        if (!pl.alive) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xAA000000); c.drawRect(0, 0, w, h, p);
            p.setColor(Color.rgb(230, 60, 50)); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(48 * d);
            c.drawText("УБИТ", w / 2f, h / 2f - 10 * d, p);
            p.setColor(Color.WHITE); p.setTextSize(16 * d);
            if (game.net != null) {
                c.drawText("Возрождение через " + Math.max(1, (int) Math.ceil(4f - pl.deadT)), w / 2f, h / 2f + 22 * d, p);
            } else {
                c.drawText("Убито: " + game.kills + "   Волна: " + game.wave, w / 2f, h / 2f + 22 * d, p);
                if (pl.deadT > 1f) c.drawText("Коснись экрана, чтобы начать заново", w / 2f, h / 2f + 52 * d, p);
            }
            p.setTextAlign(Paint.Align.LEFT);
        }
        postInvalidateOnAnimation();
    }

    /** Кнопка под пальцем (с запасом на промах) или -1. Скрытые кнопки не считаются. */
    private int hitButton(float x, float y) {
        int hit = -1;
        float best = 1.15f;
        for (int k = 0; k < Settings.COUNT; k++) {
            if (Settings.hidden(k)) continue;
            float ratio = Settings.ratio(k, x, y, getWidth(), getHeight(), d);
            if (ratio < best) { best = ratio; hit = k; }
        }
        return hit;
    }

    /** Мультиплеер: название комнаты, мой счёт и таблица игроков (зелёные - моя команда, красные - враги). */
    private static final int C_NEUTRAL = 0xFFB4B4B4, C_ALLY = 0xFF3D8BFF, C_ENEMY = 0xFFE04646;
    private final android.graphics.RectF arc = new android.graphics.RectF();

    private static int ownerColor(int owner) { return owner == 0 ? C_ALLY : owner == 1 ? C_ENEMY : C_NEUTRAL; }

    /** Верхняя панель A/B/C (кто владеет, ход захвата), метки точек в мире и надпись о захвате. */
    private void drawPoints(Canvas c, int w, int h) {
        java.util.List<WorldMap.Point> pts = game.map.points;
        if (pts.isEmpty()) return;
        p.setTextAlign(Paint.Align.CENTER);
        // панель
        float py = 50 * d, r = 14 * d;
        for (int i = 0; i < pts.size(); i++) {
            WorldMap.Point pt = pts.get(i);
            float px = w / 2f + (i - (pts.size() - 1) / 2f) * 42 * d;
            p.setStyle(Paint.Style.FILL); p.setColor(0xAA000000); c.drawCircle(px, py, r + 2 * d, p);
            p.setColor((ownerColor(pt.owner) & 0x00FFFFFF) | 0x77000000); c.drawCircle(px, py, r - 3 * d, p);
            boolean capturing = (pt.cap > 0.01f && pt.owner != 0) || (pt.cap < -0.01f && pt.owner != 1);
            if (capturing) {
                arc.set(px - r, py - r, px + r, py + r);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3.5f * d);
                p.setColor(pt.cap > 0 ? C_ALLY : C_ENEMY);
                c.drawArc(arc, -90f, Math.abs(pt.cap) * 360f, false, p);
                p.setStyle(Paint.Style.FILL);
            }
            p.setColor(Color.WHITE); p.setTextSize(14 * d); p.setFakeBoldText(true);
            c.drawText(String.valueOf(pt.letter()), px, py + 5 * d, p);
            p.setFakeBoldText(false);
        }
        // метки точек в мире: куда бежать
        Game.Player pl = game.p;
        if (pl.alive) {
            float sy = (float) Math.sin(pl.yaw), cy = (float) Math.cos(pl.yaw), cp = (float) Math.cos(pl.pitch), sp = (float) Math.sin(pl.pitch);
            float ex = pl.x + game.leanDX(), ez = pl.z + game.leanDZ(), ey = 1.6f;
            float tanV = (float) Math.tan(Math.toRadians(game.curFov() / 2.0)), tanH = tanV * w / h;
            for (WorldMap.Point pt : pts) {
                float vx = pt.x - ex, vy = 3.8f - ey, vz = pt.z - ez;
                float xc = vx * cy + vz * sy;
                float yc = vx * (-sp * sy) + vy * cp + vz * (sp * cy);
                float zc = vx * (cp * sy) + vy * sp + vz * (-cp * cy);
                if (zc < 0.5f) continue;
                float sx = w / 2f + (xc / zc) / tanH * (w / 2f), syy = h / 2f - (yc / zc) / tanV * (h / 2f);
                if (sx < 24 * d || sx > w - 24 * d || syy < 70 * d || syy > h - 70 * d) continue;
                float dist = (float) Math.hypot(pt.x - pl.x, pt.z - pl.z);
                p.setStyle(Paint.Style.FILL); p.setColor(0x88000000); c.drawCircle(sx, syy, 11 * d, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2 * d); p.setColor(ownerColor(pt.owner)); c.drawCircle(sx, syy, 11 * d, p);
                p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTextSize(13 * d); p.setFakeBoldText(true);
                c.drawText(String.valueOf(pt.letter()), sx, syy + 4.5f * d, p);
                p.setFakeBoldText(false); p.setTextSize(11 * d);
                c.drawText((int) dist + " м", sx, syy + 24 * d, p);
            }
        }
        // «Точка B захвачена»
        if (game.toastT > 0f && game.toast != null && game.toast.length() > 0) {
            int a = (int) (255 * Math.min(1f, game.toastT / 0.6f));
            p.setTextSize(19 * d); p.setFakeBoldText(true);
            p.setColor(Color.argb(a, 0, 0, 0)); c.drawText(game.toast, w / 2f + 1.5f * d, 92 * d + 1.5f * d, p);
            p.setColor(Color.argb(a, 255, 255, 255)); c.drawText(game.toast, w / 2f, 92 * d, p);
            p.setFakeBoldText(false);
        }
        p.setTextAlign(Paint.Align.LEFT); p.setColor(Color.WHITE); p.setStyle(Paint.Style.FILL);
    }

    /** Подсказка над полоской здоровья, когда игрок в блиндаже. */
    private android.graphics.Path binocPath;
    private int binocW, binocH;

    /** Вид в бинокль (только у командира): тёмная рамка с двумя пересекающимися кругами, тонкая сетка и приближение. */
    private void drawBinocularView(Canvas c, int w, int h) {
        float k = game.p.binoc;
        if (k < 0.02f) return;
        if (binocPath == null || binocW != w || binocH != h) {
            binocW = w; binocH = h;
            float rr = h * 0.47f, off = rr * 0.80f;
            android.graphics.Path circles = new android.graphics.Path();
            circles.addCircle(w / 2f - off, h / 2f, rr, android.graphics.Path.Direction.CW);
            android.graphics.Path right = new android.graphics.Path();
            right.addCircle(w / 2f + off, h / 2f, rr, android.graphics.Path.Direction.CW);
            circles.op(right, android.graphics.Path.Op.UNION);
            android.graphics.Path full = new android.graphics.Path();
            full.addRect(0, 0, w, h, android.graphics.Path.Direction.CW);
            full.op(circles, android.graphics.Path.Op.DIFFERENCE);
            binocPath = full;
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(((int) (255 * Math.min(1f, k)) << 24) | 0x000000);
        c.drawPath(binocPath, p);
        int a = (int) (200 * Math.min(1f, k));
        p.setColor((a << 24) | 0xFFFFFF);
        p.setStrokeWidth(1.2f * d);
        float cx = w / 2f, cy = h / 2f;
        c.drawLine(cx - 70 * d, cy, cx - 10 * d, cy, p);
        c.drawLine(cx + 10 * d, cy, cx + 70 * d, cy, p);
        c.drawLine(cx, cy + 10 * d, cx, cy + 70 * d, p);
        for (int i = 1; i <= 4; i++) c.drawLine(cx - 6 * d, cy + (10 + i * 14) * d, cx + 6 * d, cy + (10 + i * 14) * d, p);
        p.setTextAlign(Paint.Align.CENTER); p.setTextSize(13 * d);
        c.drawText("БИНОКЛЬ  x" + (int) Config.BINOC_ZOOM, cx, h - 60 * d, p);
        p.setTextAlign(Paint.Align.LEFT);
        p.setColor(Color.WHITE);
    }

    /** Полоска лечения аптечкой над здоровьем. */
    private void drawHealBar(Canvas c, int w, int h) {
        Game.Player pl = game.p;
        if (pl.healT <= 0f) return;
        float bw = 140 * d, bh = 7 * d, bx = w / 2f - bw / 2f, by = h - 52 * d;
        float prog = 1f - pl.healT / Config.MEDKIT_TIME;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x88000000); c.drawRect(bx, by, bx + bw, by + bh, p);
        p.setColor(0xFFE8F0E8); c.drawRect(bx, by, bx + bw * Math.max(0f, Math.min(1f, prog)), by + bh, p);
        p.setTextAlign(Paint.Align.CENTER); p.setTextSize(12 * d); p.setColor(Color.WHITE);
        c.drawText("Лечение...", w / 2f, by - 5 * d, p);
        p.setTextAlign(Paint.Align.LEFT);
    }

    private void drawSupplyHint(Canvas c, int w, float healthY) {
        int st = game.supplyState;
        if (st == 0) return;
        String t; int col;
        if (st == 1) { t = "Блиндаж: пополнение припасов и здоровья..."; col = Color.rgb(120, 230, 120); }
        else if (st == 2) { t = "Блиндаж: припасы полные"; col = Color.rgb(200, 235, 200); }
        else { t = "Чужой блиндаж: захвати точку, чтобы пополнять припасы"; col = Color.rgb(255, 215, 90); }
        p.setTextAlign(Paint.Align.CENTER); p.setTextSize(13 * d); p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF000000); c.drawText(t, w / 2f + 1f * d, healthY - 10 * d + 1f * d, p);
        p.setColor(col); c.drawText(t, w / 2f, healthY - 10 * d, p);
        p.setTextAlign(Paint.Align.LEFT); p.setColor(Color.WHITE);
    }

    private void drawNetScore(Canvas c, int w) {
        Net net = game.net;
        p.setTextAlign(Paint.Align.RIGHT);
        p.setTextSize(13 * d);
        p.setColor(Color.LTGRAY);
        c.drawText(net.roomName + "  ·  " + net.playerCount() + "/" + Net.MAX_PLAYERS, w - 16 * d, 28 * d, p);
        java.util.List<Net.PInfo> list = new java.util.ArrayList<>(net.roster.values());
        java.util.Collections.sort(list, (a, b) -> b.kills != a.kills ? b.kills - a.kills : a.deaths - b.deaths);
        float y = 48 * d;
        for (Net.PInfo pl : list) {
            p.setColor(pl.id == net.myId ? Color.WHITE : (pl.team == net.myTeam ? Color.rgb(130, 220, 120) : Color.rgb(235, 100, 90)));
            c.drawText(pl.name + "   " + pl.kills + " / " + pl.deaths, w - 16 * d, y, p);
            y += 17 * d;
        }
        p.setColor(Color.WHITE);
    }

    /** Лента убийств слева под таймером. */
    private void drawFeed(Canvas c) {
        p.setTextAlign(Paint.Align.LEFT);
        p.setTextSize(13 * d);
        float y = 78 * d;
        for (Game.Feed f : game.feed) {
            p.setColor(Color.argb((int) (255 * Math.min(1f, f.life / 1.5f)), 255, 255, 255));
            c.drawText(f.text, 16 * d, y, p);
            y += 17 * d;
        }
        p.setColor(Color.WHITE);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked();
        Game.Input in = game.input;
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            int i = e.getActionIndex(), id = e.getPointerId(i);
            if (id >= 32) return true;
            if (act == MotionEvent.ACTION_DOWN && Settings.precise) requestUnbufferedDispatch(e);
            float x = e.getX(i), y = e.getY(i);
            lx[id] = x; ly[id] = y; rbtn[id] = -1;
            if (!game.p.alive) { synchronized (in) { in.restart = true; } role[id] = R_NONE; return true; }
            int hit = hitButton(x, y);
            if (hit == Settings.B_FIRE || hit == Settings.B_FIRE2) { role[id] = R_FIRE; rbtn[id] = hit; }
            else if (hit == Settings.B_AIM) { role[id] = R_AIM; rbtn[id] = hit; in.ads = Settings.adsToggle ? !in.ads : true; }
            else if (hit == Settings.B_WEAPON) {
                role[id] = R_WEAPON; rbtn[id] = hit;
                wx0[id] = x; wy0[id] = y; wt0[id] = SystemClock.uptimeMillis(); wSwiped[id] = false;
            }
            else if (hit >= 0) {
                role[id] = R_BTN; rbtn[id] = hit;
                synchronized (in) {
                    if (hit == Settings.B_ZOOM) in.zoom = true;
                    else if (hit == Settings.B_JUMP) in.jump = true;
                    else if (hit == Settings.B_GRENADE) in.grenade = true;
                    else if (hit == Settings.B_MEDKIT) in.medkit = true;
                    else if (hit == Settings.B_LEAN_L) {
                        if (Settings.leanHold) in.leanL = true;
                        else { in.leanL = !in.leanL; in.leanR = false; }            // режим «нажатие»: включает/выключает наклон
                    } else if (hit == Settings.B_LEAN_R) {
                        if (Settings.leanHold) in.leanR = true;
                        else { in.leanR = !in.leanR; in.leanL = false; }
                    }
                    else if (hit == Settings.B_CROUCH) { if (Settings.crouchHold) in.crouchHeld = true; else in.crouchToggle = true; }
                    else if (hit == Settings.B_PRONE) { if (Settings.proneHold) in.proneHeld = true; else in.proneToggle = true; }
                }
            }
            else if (zoneActive() && inZone(x, y)) role[id] = R_ZONE;
            else if (startJoy(id, x, y, in)) { /* джойстик взят */ }
            else role[id] = R_LOOK;
            updateFire();
        } else if (act == MotionEvent.ACTION_MOVE) {
            for (int i = 0; i < e.getPointerCount(); i++) {
                int id = e.getPointerId(i);
                if (id >= 32) continue;
                float x = e.getX(i), y = e.getY(i);
                if (role[id] == R_JOY) {
                    moveJoy(x, y, in);
                } else if (role[id] == R_LOOK) {
                    // палец в зоне стрельбы (R_ZONE) камеру НЕ двигает - там только огонь
                    // берём все накопленные промежуточные точки - поворот не теряет ни пикселя
                    for (int hs = 0; hs < e.getHistorySize(); hs++) {
                        float hx = e.getHistoricalX(i, hs), hy = e.getHistoricalY(i, hs);
                        synchronized (in) { in.lookDX += hx - lx[id]; in.lookDY += hy - ly[id]; }
                        lx[id] = hx; ly[id] = hy;
                    }
                    synchronized (in) { in.lookDX += x - lx[id]; in.lookDY += y - ly[id]; }
                    lx[id] = x; ly[id] = y;
                } else if (role[id] == R_WEAPON && !wSwiped[id]) {
                    // свайп по кнопке оружия - сменить оружие
                    float thr = 24f * d;
                    if (Math.abs(x - wx0[id]) > thr || Math.abs(y - wy0[id]) > thr) {
                        wSwiped[id] = true;
                        synchronized (in) { in.sw = true; }
                    }
                }
            }
        } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_POINTER_UP || act == MotionEvent.ACTION_CANCEL) {
            int i = e.getActionIndex(), id = e.getPointerId(i);
            if (act == MotionEvent.ACTION_CANCEL) {
                for (int k = 0; k < 32; k++) role[k] = R_NONE;
                in.fire = false; in.moveX = 0; in.moveY = 0; joyOn = false;
                in.crouchHeld = false; in.proneHeld = false; in.leanL = false; in.leanR = false;
                if (!Settings.adsToggle) in.ads = false;
                return true;
            }
            if (id < 32) {
                if (role[id] == R_JOY) { joyOn = false; in.moveX = 0; in.moveY = 0; }
                if (role[id] == R_AIM && !Settings.adsToggle) in.ads = false;
                if (role[id] == R_BTN && rbtn[id] == Settings.B_CROUCH) in.crouchHeld = false;
                if (role[id] == R_BTN && rbtn[id] == Settings.B_PRONE) in.proneHeld = false;
                if (Settings.leanHold && role[id] == R_BTN && rbtn[id] == Settings.B_LEAN_L) in.leanL = false;
                if (Settings.leanHold && role[id] == R_BTN && rbtn[id] == Settings.B_LEAN_R) in.leanR = false;
                if (role[id] == R_WEAPON && !wSwiped[id] && SystemClock.uptimeMillis() - wt0[id] < 500) {
                    synchronized (in) { in.reload = true; }    // короткое нажатие - перезарядка
                }
                role[id] = R_NONE; rbtn[id] = -1;
                updateFire();
            }
        }
        return true;
    }


    /** Берёт джойстик под палец по правилам выбранного режима: статичный / плавающий / свободный. */
    private boolean startJoy(int id, float x, float y, Game.Input in) {
        boolean inBase = Math.hypot(x - joyBaseX(), y - joyBaseY()) <= joyR() * 1.5f;
        boolean inRegion = Settings.joyRight ? x > getWidth() * 0.6f : x < getWidth() * 0.4f;
        if (inBase) { joyOx = joyBaseX(); joyOy = joyBaseY(); }
        else if (Settings.joyMode == Settings.JOY_FREE && inRegion) { joyOx = x; joyOy = y; }
        else return false;
        role[id] = R_JOY; joyOn = true; joyX = 0; joyY = 0;
        moveJoy(x, y, in);
        return true;
    }

    private void moveJoy(float x, float y, Game.Input in) {
        float R = joyR(), dx = x - joyOx, dy = y - joyOy;
        float l = (float) Math.hypot(dx, dy);
        if (l > R) {
            if (Settings.joyMode == Settings.JOY_FLOAT) {          // плавающий: основание едет за пальцем
                joyOx += dx * (l - R) / l; joyOy += dy * (l - R) / l;
                dx = x - joyOx; dy = y - joyOy;
            } else { dx *= R / l; dy *= R / l; }
        }
        joyX = dx; joyY = dy;
        in.moveX = dx / R; in.moveY = -dy / R;
    }
}
