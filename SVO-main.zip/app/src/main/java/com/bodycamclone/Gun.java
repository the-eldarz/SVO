package com.bodycamclone;

import android.opengl.Matrix;
import android.util.Log;

/**
 * Автомат из .glb. Сам находит ось ствола (самая длинная сторона модели), определяет где дуло, а где приклад,
 * и строит матрицу fix: после неё дуло смотрит в -Z, приклад в +Z, верх в +Y, длина равна 1,
 * а начало координат лежит у пистолетной рукояти (Config.AK_GRIP_Z / AK_GRIP_Y).
 */
public final class Gun {
    public final GlbModel model;
    /** Из координат модели (после normalize) в «единичное» пространство оружия. */
    public final float[] fix = new float[16];

    public Gun(GlbModel m) {
        model = m;
        float[] mn = {1e30f, 1e30f, 1e30f}, mx = {-1e30f, -1e30f, -1e30f};
        int count = 0;
        for (GlbModel.Prim p : m.prims) for (int i = 0; i + 2 < p.data.length; i += 8) {
            for (int k = 0; k < 3; k++) {
                float v = p.data[i + k];
                if (v < mn[k]) mn[k] = v;
                if (v > mx[k]) mx[k] = v;
            }
            count++;
        }
        float[] ext = {mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]};
        int a = 0;                                   // ось ствола: самая длинная
        for (int k = 1; k < 3; k++) if (ext[k] > ext[a]) a = k;
        int u = (a == 1) ? 2 : 1;                    // «вверх»: Y (если ствол не вдоль Y)
        int sd = 3 - a - u;                          // боковая ось
        float len = Math.max(1e-6f, ext[a]);
        float mid = (mn[a] + mx[a]) / 2f;
        float lowLimit = mn[u] + 0.30f * ext[u];
        float slice = 0.08f * len;
        float botSum = 0f, allSum = 0f;
        int botN = 0;
        float loMin = 1e30f, loMax = -1e30f, hiMin = 1e30f, hiMax = -1e30f;
        for (GlbModel.Prim p : m.prims) for (int i = 0; i + 2 < p.data.length; i += 8) {
            float pa = p.data[i + a], pu = p.data[i + u];
            allSum += pa;
            if (pu <= lowLimit) { botSum += pa; botN++; }
            if (pa <= mn[a] + slice) { loMin = Math.min(loMin, pu); loMax = Math.max(loMax, pu); }
            if (pa >= mx[a] - slice) { hiMin = Math.min(hiMin, pu); hiMax = Math.max(hiMax, pu); }
        }
        // Три «голоса» за то, где приклад: (1) магазин и рукоять внизу смещены к прикладу,
        // (2) у дула сечение тоньше, чем у приклада, (3) основная масса деталей (ствольная коробка) ближе к прикладу.
        float vote = 0f;
        if (botN > 0) vote += sgn(botSum / botN - mid, 0.02f * len);
        float loExt = loMax - loMin, hiExt = hiMax - hiMin;
        if (hiExt < loExt * 0.9f) vote -= 1f;        // тонкий конец на +a - это дуло, значит приклад на -a
        else if (loExt < hiExt * 0.9f) vote += 1f;
        if (count > 0) vote += 0.5f * sgn(allSum / count - mid, 0.01f * len);
        float stock = vote >= 0f ? 1f : -1f;         // знак оси a в сторону приклада
        if (Config.AK_FLIP) stock = -stock;

        float[] zg = new float[3], yg = new float[3];
        zg[a] = stock; yg[u] = 1f;
        float[] xg = {yg[1] * zg[2] - yg[2] * zg[1], yg[2] * zg[0] - yg[0] * zg[2], yg[0] * zg[1] - yg[1] * zg[0]};
        float[] A = new float[16];
        A[0] = xg[0]; A[4] = xg[1]; A[8] = xg[2];
        A[1] = yg[0]; A[5] = yg[1]; A[9] = yg[2];
        A[2] = zg[0]; A[6] = zg[1]; A[10] = zg[2];
        A[15] = 1f;
        float zMax = stock > 0f ? mx[a] : -mn[a];                    // конец приклада в новых координатах
        float xc = xg[sd] * (mn[sd] + mx[sd]) / 2f;
        float yo = mn[u] + Config.AK_GRIP_Y * ext[u];
        float zo = zMax - Config.AK_GRIP_Z * len;
        float[] t = new float[16];
        Matrix.setIdentityM(t, 0);
        Matrix.scaleM(t, 0, 1f / len, 1f / len, 1f / len);
        Matrix.translateM(t, 0, -xc, -yo, -zo);
        Matrix.multiplyMM(fix, 0, t, 0, A, 0);
        Log.d("Bodycam", "Gun: ось ствола=" + "XYZ".charAt(a) + ", приклад в сторону " + (stock > 0 ? "+" : "-")
                + ", голоса=" + vote + ", размеры=" + ext[0] + "/" + ext[1] + "/" + ext[2]);
    }

    private static float sgn(float v, float eps) { return v > eps ? 1f : (v < -eps ? -1f : 0f); }
}
