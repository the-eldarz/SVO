package com.bodycamclone;

import android.content.Context;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class GameRenderer implements GLSurfaceView.Renderer {
    private static final String TAG = "Bodycam";
    private static final float[] WHITE = {1f, 1f, 1f};
    private static final float[] SKY = {0.62f, 0.69f, 0.76f};

    static final String VS = "#version 300 es\n"
            + "layout(location=0) in vec3 aPos; layout(location=1) in vec3 aNormal; layout(location=2) in vec2 aUV;\n"
            + "layout(location=3) in vec4 aJoints; layout(location=4) in vec4 aWeights; layout(location=5) in float aHead;\n"
            + "uniform mat4 uMVP; uniform mat4 uModel; uniform mat4 uBones[80]; uniform int uSkinned;\n"
            + "out vec3 vN; out vec2 vUV; out vec3 vW; out float vHead;\n"
            + "void main(){\n"
            + "  vHead = aHead;\n"
            + "  vec4 p = vec4(aPos,1.0); vec3 nrm = aNormal;\n"
            + "  if(uSkinned==1){\n"
            + "    mat4 sk = aWeights.x*uBones[int(aJoints.x+0.5)] + aWeights.y*uBones[int(aJoints.y+0.5)]\n"
            + "            + aWeights.z*uBones[int(aJoints.z+0.5)] + aWeights.w*uBones[int(aJoints.w+0.5)];\n"
            + "    p = sk*p; nrm = mat3(sk)*aNormal;\n"
            + "  }\n"
            + "  vec4 w = uModel*p; vW=w.xyz; vN=mat3(uModel)*nrm; vUV=aUV; gl_Position=uMVP*p;\n"
            + "}\n";
    static final String FS = "#version 300 es\n"
            + "precision highp float;\n"
            + "uniform vec4 uColor; uniform vec3 uTint; uniform sampler2D uTex; uniform int uUseTex; uniform int uMode;\n"
            + "uniform vec3 uSun; uniform vec3 uCam; uniform float uFog; uniform vec3 uFogColor; uniform float uEmissive; uniform int uHeadGone;\n"
            + "in vec3 vN; in vec2 vUV; in vec3 vW; in float vHead; out vec4 o;\n"
            + "void main(){\n"
            + "  vec4 base = uColor;\n"
            + "  if(uUseTex==1){ vec4 t = texture(uTex, vUV); if(t.a<0.4) discard; base.rgb *= t.rgb; }\n"
            + "  if(uHeadGone==1){ if(vHead>0.5) discard; base.rgb = mix(base.rgb, vec3(0.42,0.02,0.02), clamp(vHead*2.2,0.0,1.0)); }\n"
            + "  if(uMode==3){ o = vec4(base.rgb*uEmissive,1.0); return; }\n"
            + "  if(uMode==1){ float c = mod(floor(vW.x*0.5)+floor(vW.z*0.5),2.0); base.rgb *= 0.92+0.08*c;\n"
            + "                float n = fract(sin(dot(floor(vW.xz*2.0),vec2(12.9898,78.233)))*43758.5453); base.rgb *= 0.94+0.06*n; }\n"
            + "  if(uMode==2){ float s = step(0.5, fract(vW.y*2.5)); base.rgb *= 0.93+0.07*s; }\n"
            + "  vec3 n = normalize(vN);\n"
            + "  float diff = max(dot(n, normalize(uSun)), 0.0);\n"
            + "  vec3 lit = base.rgb*uTint*(0.45+0.65*diff);\n"
            + "  float d = length(vW-uCam);\n"
            + "  float f = clamp((d-25.0)/(uFog-25.0),0.0,1.0);\n"
            + "  o = vec4(mix(lit,uFogColor,f),1.0);\n"
            + "}\n";

    private final Context ctx;
    private final Game game;
    private int prog, uMVP, uModel, uColor, uTint, uTex, uUseTex, uMode, uSun, uCam, uFog, uFogColor, uEmissive, uBones, uSkinned, uHeadGone;
    private GlbModel.Prim cube;
    private AnimationLibrary.Set anims = new AnimationLibrary.Set();
    private final float[] bones = new float[GlbModel.MAX_BONES * 16];
    private float frameDt = 0.016f;
    private final float[] headP = new float[3], hv4 = new float[4], hw4 = new float[4];
    private final Map<String, GlbModel> models = new HashMap<>();
    private GlbModel modelAlly, modelEnemy;
    private boolean loadedOnce;
    private Gun gun;
    /** Оттенок формы бойцов своей стороны (выбранная форма x обычный оттенок союзников). */
    private float[] allyTint = Config.ALLY_TINT;
    private String lastLoadError = "";
    private final float[] gunA = new float[16], gunB = new float[16], attach = new float[16], handR = new float[3], handL = new float[3];
    private int w = 1, h = 1;
    private long last;
    private final float[] proj = new float[16], view = new float[16], vp = new float[16];
    private final float[] model = new float[16], mvp = new float[16], base = new float[16], tmp = new float[16];

    public GameRenderer(Context ctx, Game game) { this.ctx = ctx; this.game = game; }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        prog = buildProgram();
        uMVP = loc("uMVP"); uModel = loc("uModel"); uColor = loc("uColor"); uTint = loc("uTint");
        uTex = loc("uTex"); uUseTex = loc("uUseTex"); uMode = loc("uMode"); uSun = loc("uSun");
        uCam = loc("uCam"); uFog = loc("uFog"); uFogColor = loc("uFogColor"); uEmissive = loc("uEmissive");
        uBones = loc("uBones[0]"); uSkinned = loc("uSkinned"); uHeadGone = loc("uHeadGone");
        cube = makeCube();
        cube.uploadGeometry();
        if (!loadedOnce) {
            loadedOnce = true;
            String allyPath = Config.uniformModel(ctx.getAssets(), game.side, Settings.uniform);
            float[] ut = Config.uniformTint(Settings.uniform);
            allyTint = new float[]{Config.ALLY_TINT[0] * ut[0], Config.ALLY_TINT[1] * ut[1], Config.ALLY_TINT[2] * ut[2]};
            String enemyPath = game.side == Config.SIDE_RU ? Config.UA_MODEL : Config.RU_MODEL;
            GlbModel ma = loadModel(allyPath), me = loadModel(enemyPath);
            String missing = (ma == null ? allyPath.substring(7) + " " : "") + (me == null ? enemyPath.substring(7) : "");
            if (ma == null) ma = me;
            if (me == null) me = ma;
            modelAlly = ma; modelEnemy = me;
            if (missing.trim().length() > 0) {
                game.status = "Нет модели: " + missing.trim() + (ma != null ? " (пока стоит другая модель)" : " (показаны заглушки)");
                game.statusError = true;
            }
            loadAnimations();
            if (Settings.rifle == 1) {
                GlbModel gm = loadModel(Config.AK_MODEL, true);
                if (gm != null) gun = new Gun(gm);
                else {
                    game.status = game.status + "; АК-74М: " + lastLoadError;
                    game.statusError = true;
                }
            }
        }
        for (GlbModel m : models.values()) if (m != null) m.upload();
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);
        last = 0;
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        w = Math.max(1, width); h = Math.max(1, height);
        GLES30.glViewport(0, 0, w, h);
    }

    private int loc(String n) { return GLES30.glGetUniformLocation(prog, n); }

    private int buildProgram() {
        int vs = compile(GLES30.GL_VERTEX_SHADER, VS), fs = compile(GLES30.GL_FRAGMENT_SHADER, FS);
        int p = GLES30.glCreateProgram();
        GLES30.glAttachShader(p, vs); GLES30.glAttachShader(p, fs);
        GLES30.glLinkProgram(p);
        int[] ok = new int[1];
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("link: " + GLES30.glGetProgramInfoLog(p));
        return p;
    }

    private int compile(int type, String src) {
        int s = GLES30.glCreateShader(type);
        GLES30.glShaderSource(s, src);
        GLES30.glCompileShader(s);
        int[] ok = new int[1];
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("shader: " + GLES30.glGetShaderInfoLog(s));
        return s;
    }

    /** Собирает клипы из user_files/*.glb и из самих моделей, выбирает idle/бег/смерть и пишет итог в строку статуса. */
    private void loadAnimations() {
        AnimationLibrary.Result r = AnimationLibrary.loadClips(ctx);
        java.util.List<GlbModel.Clip> all = new java.util.ArrayList<>(r.clips);
        for (GlbModel m : models.values()) if (m != null) all.addAll(m.clips);
        anims = AnimationLibrary.classify(all);
        GlbModel ref = modelAlly != null ? modelAlly : modelEnemy;
        String info;
        if (ref == null) {
            return; // модели нет - статус уже сообщает об этом
        } else if (ref.boneCount == 0) {
            info = "У модели нет скелета (skin) - анимации невозможны [" + ref.skinInfo + "]";
        } else if (r.fbxFiles > 0 && r.glbFiles == 0 && all.isEmpty()) {
            info = "Найдено FBX: " + r.fbxFiles + ". FBX игра не читает - сконвертируй анимации в .glb";
        } else if (all.isEmpty()) {
            info = "Клипов анимации не найдено (файлов .glb: " + r.glbFiles + ", .fbx: " + r.fbxFiles + ")";
        } else if (!anims.any()) {
            info = "Клипов: " + all.size() + ", но в именах нет idle/run/walk/death - переименуй файлы";
        } else {
            int bad = 0;
            if (anims.idle != null && ref.matchCount(anims.idle) < 5) { bad++; anims.idle = null; }
            if (anims.move != null && ref.matchCount(anims.move) < 5) { bad++; anims.move = null; }
            for (GlbModel.Clip dc : new java.util.ArrayList<>(anims.deaths)) {
                if (ref.matchCount(dc) < 5) { bad++; anims.removeDeath(dc); }
            }
            info = bad > 0 ? "Анимации не подходят к скелету модели (имена костей не совпали): " + bad
                    : "Анимации: idle=" + (anims.idle != null) + " бег=" + (anims.move != null) + " смерть=" + anims.deaths.size();
        }
        game.status = game.status + "; " + info;
        if (info.startsWith("Анимации:") == false) game.statusError = true;
    }

    private GlbModel loadModel(String path) { return loadModel(path, false); }

    /** quiet = не трогать строку статуса (так грузится оружие); причина ошибки остаётся в lastLoadError. */
    private GlbModel loadModel(String path, boolean quiet) {
        if (models.containsKey(path)) return models.get(path);
        GlbModel m = null;
        try (InputStream in = ctx.getAssets().open(path)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 20);
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            m = GlbModel.parse(bo.toByteArray(), quiet ? 1f : Config.SOLDIER_HEIGHT);
            if (!quiet) {
                game.status = "Модель загружена: " + m.triangles + " треугольников";
                game.statusError = false;
            }
        } catch (FileNotFoundException e) {
            lastLoadError = "нет файла " + path.substring(path.lastIndexOf('/') + 1) + ", показан простой автомат";
            if (!quiet) {
                game.status = "Не найден " + path + " (положи в app/src/main/assets/models/). Показаны заглушки";
                game.statusError = true;
            }
        } catch (Throwable e) {
            Log.e(TAG, "model " + path, e);
            lastLoadError = "ошибка модели: " + e.getMessage() + ", показан простой автомат";
            if (!quiet) {
                game.status = "Ошибка модели: " + e.getMessage() + ". Показаны заглушки";
                game.statusError = true;
            }
        }
        models.put(path, m);
        return m;
    }

    static GlbModel.Prim makeCube() {
        float[][] f = {
                {0, 0, 1, 1, 0, 0, 0, 1, 0}, {0, 0, -1, -1, 0, 0, 0, 1, 0},
                {1, 0, 0, 0, 0, -1, 0, 1, 0}, {-1, 0, 0, 0, 0, 1, 0, 1, 0},
                {0, 1, 0, 1, 0, 0, 0, 0, -1}, {0, -1, 0, 1, 0, 0, 0, 0, 1}};
        float[] sa = {-1, 1, 1, -1}, sb = {-1, -1, 1, 1};
        float[] d = new float[24 * 8];
        int[] idx = new int[36];
        for (int i = 0; i < 6; i++) {
            float[] q = f[i];
            for (int k = 0; k < 4; k++) {
                int o = (i * 4 + k) * 8;
                d[o] = 0.5f * (q[0] + sa[k] * q[3] + sb[k] * q[6]);
                d[o + 1] = 0.5f * (q[1] + sa[k] * q[4] + sb[k] * q[7]);
                d[o + 2] = 0.5f * (q[2] + sa[k] * q[5] + sb[k] * q[8]);
                d[o + 3] = q[0]; d[o + 4] = q[1]; d[o + 5] = q[2];
                d[o + 6] = (sa[k] + 1) / 2; d[o + 7] = (sb[k] + 1) / 2;
            }
            int b = i * 4, o = i * 6;
            idx[o] = b; idx[o + 1] = b + 1; idx[o + 2] = b + 2; idx[o + 3] = b; idx[o + 4] = b + 2; idx[o + 5] = b + 3;
        }
        GlbModel.Prim p = new GlbModel.Prim();
        p.data = d; p.idx = idx;
        return p;
    }

    private void setU(float[] mvpM, float[] modelM, float r, float g, float b, float[] tint, int mode, float emis, int useTex) {
        GLES30.glUniformMatrix4fv(uMVP, 1, false, mvpM, 0);
        GLES30.glUniformMatrix4fv(uModel, 1, false, modelM, 0);
        GLES30.glUniform4f(uColor, r, g, b, 1f);
        GLES30.glUniform3f(uTint, tint[0], tint[1], tint[2]);
        GLES30.glUniform1i(uMode, mode);
        GLES30.glUniform1f(uEmissive, emis);
        GLES30.glUniform1i(uUseTex, useTex);
        GLES30.glUniform1i(uSkinned, 0);
        GLES30.glUniform1i(uHeadGone, 0);
    }

    /** Бокс: parent * T(cx,cy,cz) * S(sx,sy,sz); parent может быть null. */
    private void box(float[] vpM, float[] parent, float cx, float cy, float cz, float sx, float sy, float sz,
                     float r, float g, float b, float[] tint, int mode, float emis) {
        if (parent == null) Matrix.setIdentityM(tmp, 0);
        else System.arraycopy(parent, 0, tmp, 0, 16);
        Matrix.translateM(tmp, 0, cx, cy, cz);
        Matrix.scaleM(tmp, 0, sx, sy, sz);
        Matrix.multiplyMM(mvp, 0, vpM, 0, tmp, 0);
        setU(mvp, tmp, r, g, b, tint, mode, emis, 0);
        cube.draw();
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        frameDt = dt;
        game.update(dt);
        Game.Player p = game.p;

        GLES30.glClearColor(SKY[0], SKY[1], SKY[2], 1f);
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);
        GLES30.glUseProgram(prog);
        GLES30.glUniform1i(uTex, 0);
        GLES30.glUniform3f(uSun, 0.4f, 0.9f, 0.3f);
        GLES30.glUniform1f(uFog, 110f);
        GLES30.glUniform3f(uFogColor, SKY[0], SKY[1], SKY[2]);

        float aspect = (float) w / h;
        float sy = (float) Math.sin(p.yaw), cy = (float) Math.cos(p.yaw);
        float cp = (float) Math.cos(p.pitch), sp = (float) Math.sin(p.pitch);
        float bobY = p.moving && !p.air ? Math.abs((float) Math.sin(p.bob)) * 0.035f : 0f;
        float stanceDrop = p.crouchBlend * 0.48f + p.proneBlend * 0.92f;
        float eyeY = p.alive ? 1.6f - stanceDrop + p.jumpY + bobY * (1f - p.proneBlend) : 1.6f - Math.min(1f, p.deadT * 2f) * 1.25f;
        float roll = (p.moving && !p.air ? (float) Math.sin(p.bob) * 0.012f : 0f)
                + (p.alive ? p.leanOff / Game.LEAN_MAX * 0.19f : 0f);     // крен камеры при выглядывании (~11 градусов)
        float ex = p.alive ? p.x + game.leanDX() : p.x, ez = p.alive ? p.z + game.leanDZ() : p.z;
        Matrix.perspectiveM(proj, 0, game.curFov(), aspect, 0.1f, 200f);
        Matrix.setLookAtM(view, 0, ex, eyeY, ez, ex + cp * sy, eyeY + sp, ez - cp * cy,
                (float) Math.sin(roll) * cy, (float) Math.cos(roll), (float) Math.sin(roll) * sy);   // верх камеры наклоняется вправо при roll > 0
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0);
        GLES30.glUniform3f(uCam, ex, eyeY, ez);

        float fx = sy, fz = -cy;
        for (WorldMap.Box b : game.map.boxes) {
            float cx = (b.x0 + b.x1) / 2f, cyy = (b.y0 + b.y1) / 2f, cz = (b.z0 + b.z1) / 2f;
            float sx = b.x1 - b.x0, sh = b.y1 - b.y0, sz = b.z1 - b.z0;
            float rad = (float) Math.hypot(sx, sz) / 2f;
            float dx = cx - ex, dz = cz - ez;
            if (dx * fx + dz * fz < -rad) continue;
            if (dx * dx + dz * dz > (130f + rad) * (130f + rad)) continue;
            box(vp, null, cx, cyy, cz, sx, sh, sz, b.r, b.g, b.b, WHITE, b.mode, 0f);
        }
        // Небольшие тёмные отметины попаданий на геометрии карты (стены, укрытия, земля).
        for (Game.BulletMark mark : game.bulletMarks) {
            Matrix.setIdentityM(model, 0);
            Matrix.translateM(model, 0, mark.x, mark.y, mark.z);
            if (mark.ny > 0.5f || mark.ny < -0.5f) Matrix.rotateM(model, 0, mark.ny > 0 ? -90f : 90f, 1f, 0f, 0f);
            else if (mark.nx > 0.5f || mark.nx < -0.5f) Matrix.rotateM(model, 0, mark.nx > 0 ? 90f : -90f, 0f, 1f, 0f);
            float fade = Math.min(1f, mark.life / 3f);
            box(vp, model, 0f, 0f, 0f, 0.075f, 0.075f, 0.006f,
                    0.075f * fade, 0.065f * fade, 0.055f * fade, WHITE, 0, 0f);
        }
        for (Soldier s : game.soldiers) {
            float dx = s.x - ex, dz = s.z - ez;
            if (dx * dx + dz * dz > 120f * 120f) continue;
            drawSoldier(s);
        }
        drawGore(ex, ez);
        drawViewmodel(aspect);
    }

    /** Брызги, осколки и лужицы крови. */
    private void drawGore(float ex, float ez) {
        Gore gr = game.gore;
        for (Gore.Splat sp : gr.splats) {
            float dx = sp.x - ex, dz = sp.z - ez;
            if (dx * dx + dz * dz > 60f * 60f) continue;
            float sz = sp.size * Math.min(1f, sp.life / 3f);
            box(vp, null, sp.x, 0.010f, sp.z, sz, 0.006f, sz, 0.30f, 0.025f, 0.02f, WHITE, 0, 0f);
        }
        for (Gore.P q : gr.parts) {
            float dx = q.x - ex, dz = q.z - ez;
            if (dx * dx + dz * dz > 60f * 60f) continue;
            box(vp, null, q.x, q.y, q.z, q.size, q.size, q.size, q.r, q.g, q.b, WHITE, 0, 0f);
        }
    }

    private final java.util.Random deathRnd = new java.util.Random();

    /** Клип смерти для убитого бойца: выбирается один раз при гибели по направлению выстрела и попаданию в голову. */
    private GlbModel.Clip deathClipFor(Soldier s) {
        if (anims.deaths.isEmpty()) return null;
        if (s.deathClip == null) {
            float fx = (float) Math.sin(s.yaw), fz = (float) -Math.cos(s.yaw);   // куда смотрел боец
            s.deathClip = AnimationLibrary.pickDeath(anims, fx, fz, s.hitDx, s.hitDz, s.headGone, deathRnd);
        }
        return s.deathClip;
    }

    private void drawSoldier(Soldier s) {
        float[] tint = s.team == 0 ? allyTint : Config.ENEMY_TINT;
        if (s.dead) tint = new float[]{tint[0] * 0.65f, tint[1] * 0.65f, tint[2] * 0.65f};
        Matrix.setIdentityM(base, 0);
        Matrix.translateM(base, 0, s.x, s.y, s.z);
        float yawOff = ((s.team == 0) == (game.side == Config.SIDE_RU)) ? Config.RU_YAW_OFFSET_DEG : Config.UA_YAW_OFFSET_DEG;
        Matrix.rotateM(base, 0, 180f - (float) Math.toDegrees(s.yaw) + yawOff, 0f, 1f, 0f);
        if (!s.dead && s.lean != 0f) Matrix.rotateM(base, 0, s.lean * 14f, 0f, 0f, 1f);      // сетевой боец выглядывает: наклон корпуса
        GlbModel m = s.team == 0 ? modelAlly : modelEnemy;
        GlbModel.Clip want = null;
        if (!s.dead) s.deathClip = null;
        if (m != null && m.boneCount > 0) want = s.dead ? deathClipFor(s) : (s.moving ? anims.move : anims.idle);
        if (want != s.animCur) {
            s.animPrev = s.animCur; s.animPrevT = s.animCurT;
            s.animBlend = s.animCur == null ? 1f : 0f;
            s.animCur = want;
        }
        if (want != null) {
            float t;
            if (s.dead) t = Math.min(s.deadT, want.duration);
            else if (s.moving) t = (s.walkPhase / 6.2831853f * want.duration) % want.duration; // шаг привязан к пройденному пути
            else t = (game.time + Math.abs(s.x * 3.1f + s.z * 1.7f)) % want.duration;
            s.animCurT = t;
            s.animBlend = Math.min(1f, s.animBlend + frameDt / 0.2f);
        }
        if (s.dead) {
            if (want == null) {
            // Whole-body ragdoll-style tumble with gravity-driven settling.
            Matrix.translateM(base, 0, 0f, s.fallY, 0f);
            Matrix.rotateM(base, 0, (float)Math.toDegrees(s.fallAngle), 0f, 0f, 1f);
            Matrix.rotateM(base, 0, -82f, 1f, 0f, 0f);
            }
        } else if (want != null) {
            // скелетная анимация сама двигает модель - процедурное покачивание не нужно
        } else if (s.moving) {
            float ph = s.walkPhase;
            Matrix.translateM(base, 0, 0f, Math.abs((float) Math.sin(ph)) * 0.04f, 0f);
            Matrix.rotateM(base, 0, (float) Math.sin(ph) * 3f, 0f, 0f, 1f);
        } else if (!s.dead) {
            float breathe = (float)Math.sin(game.time * 2.1f + s.x * 3f + s.z) ;
            Matrix.translateM(base, 0, 0f, breathe * 0.008f, 0f);
            Matrix.rotateM(base, 0, breathe * 0.45f, 0f, 0f, 1f);
        }
        if (m != null) {
            Matrix.multiplyMM(mvp, 0, vp, 0, base, 0);
            if (want != null) {
                m.pose(want, s.animCurT, s.animPrev, s.animPrevT, s.animBlend, bones);
                GLES30.glUniformMatrix4fv(uBones, m.boneCount, false, bones, 0);
            }
            // Голова разнесена: узнаём, где у кости головы сейчас шея (в позе анимации или в позе покоя)
            boolean stump = false;
            if (s.headGone && m.boneHead >= 0) {
                if (want == null) m.pose(null, 0f, null, 0f, 1f, bones);
                stump = m.jointPos(m.boneHead, headP);
            }
            for (GlbModel.Prim p : m.prims) {
                setU(mvp, base, p.color[0], p.color[1], p.color[2], tint, 0, 0f, p.tex != 0 ? 1 : 0);
                if (want != null && p.skinData != null) GLES30.glUniform1i(uSkinned, 1);
                if (s.headGone && p.headW != null) GLES30.glUniform1i(uHeadGone, 1);
                if (p.tex != 0) { GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, p.tex); }
                p.draw();
            }
            if (stump) {
                // красный обрубок шеи закрывает дыру на месте головы, из него бьёт кровь
                box(vp, base, headP[0], headP[1] - 0.025f, headP[2], 0.115f, 0.07f, 0.115f, 0.38f, 0.02f, 0.02f, WHITE, 0, 0f);
                if (s.dead && s.deadT < 1.8f) {
                    s.spurtT -= frameDt;
                    if (s.spurtT <= 0f) {
                        s.spurtT = 0.045f;
                        hv4[0] = headP[0]; hv4[1] = headP[1]; hv4[2] = headP[2]; hv4[3] = 1f;
                        Matrix.multiplyMV(hw4, 0, base, 0, hv4, 0);
                        game.gore.spurt(hw4[0], hw4[1], hw4[2]);
                    }
                }
            }
        } else {
            float[][] parts = {
                    {-.12f, .42f, 0, .2f, .84f, .22f, .30f, .35f, .22f}, {.12f, .42f, 0, .2f, .84f, .22f, .30f, .35f, .22f},
                    {0, 1.12f, 0, .46f, .6f, .26f, .33f, .38f, .24f},
                    {-.3f, 1.1f, .05f, .14f, .55f, .16f, .33f, .38f, .24f}, {.3f, 1.1f, .05f, .14f, .55f, .16f, .33f, .38f, .24f},
                    {0, 1.6f, 0, .22f, .24f, .24f, .8f, .62f, .5f}, {0, 1.74f, 0, .28f, .12f, .3f, .25f, .3f, .2f},
                    {.18f, 1.2f, .3f, .06f, .08f, .7f, .1f, .1f, .1f}};
            for (float[] q : parts) box(vp, base, q[0], q[1], q[2], q[3], q[4], q[5], q[6], q[7], q[8], tint, 0, 0f);
        }
        boolean gunShown = gun != null && m != null && !s.dead && drawSoldierGun(m, want != null);
        if (s.dead && s.bloodFade > 0.01f) {
            float[] stain = {0.34f, 0.035f, 0.025f};
            Matrix.setIdentityM(model, 0);
            Matrix.translateM(model, 0, s.x, 0.012f, s.z);
            Matrix.rotateM(model, 0, -s.yaw * 57.29578f, 0f, 1f, 0f);
            box(vp, model, 0f, 0f, 0f, 0.42f * s.bloodFade, 0.012f, 0.28f * s.bloodFade,
                    stain[0], stain[1], stain[2], WHITE, 0, 0f);
        }
        if (s.flash > 0f && !s.dead) {
            if (gunShown) {
                float L = Config.AK_LENGTH_WORLD, k = 0.16f / L;
                box(vp, gunA, 0f, 0.07f / L, -(1f - Config.AK_GRIP_Z) - 0.05f, k, k, k, 1f, .85f, .35f, WHITE, 3, 1.5f);
            } else {
                box(vp, base, 0.18f, 1.25f, 0.8f, .16f, .16f, .16f, 1f, .85f, .35f, WHITE, 3, 1.5f);
            }
        }
    }

    /** Рисует автомат: modelM уже включает позицию, масштаб и gun.fix. */
    private void drawGunModel(float[] vpM, float[] modelM) {
        Matrix.multiplyMM(mvp, 0, vpM, 0, modelM, 0);
        for (GlbModel.Prim p : gun.model.prims) {
            setU(mvp, modelM, p.color[0], p.color[1], p.color[2], WHITE, 0, 0f, p.tex != 0 ? 1 : 0);
            if (p.tex != 0) { GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, p.tex); }
            p.draw();
        }
    }

    /**
     * Автомат в руках бойца. Ствол направляется от правой кисти (рукоять) к левой (цевьё); если поза не похожа на
     * стойку с оружием, ствол смотрит вперёд. После вызова gunA = матрица автомата без gun.fix (для вспышки).
     */
    private boolean drawSoldierGun(GlbModel m, boolean posed) {
        float fx = 0f, fy = -0.08f, fz = 1f, gx, gy, gz;
        if (posed && m.jointPos(m.boneRHand, handR) && m.jointPos(m.boneLHand, handL)) {
            float dx = handL[0] - handR[0], dy = handL[1] - handR[1], dz = handL[2] - handR[2];
            float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (l > 0.10f && dz / l > 0.45f) { fx = dx / l; fy = dy / l; fz = dz / l; }
            gx = handR[0]; gy = handR[1]; gz = handR[2];
        } else {
            gx = 0.18f; gy = 1.2f; gz = 0.15f;       // без скелета: на уровне груди справа
        }
        float fl = (float) Math.sqrt(fx * fx + fy * fy + fz * fz);
        fx /= fl; fy /= fl; fz /= fl;
        float ux = -fx * fy, uy = 1f - fy * fy, uz = -fz * fy;
        float ul = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
        if (ul < 1e-4f) { ux = 0f; uy = 0f; uz = 1f; } else { ux /= ul; uy /= ul; uz /= ul; }
        float xx = fy * uz - fz * uy, xy = fz * ux - fx * uz, xz = fx * uy - fy * ux;   // правая сторона = ствол x верх
        gx += fx * Config.AK_HAND_FWD; gy += fy * Config.AK_HAND_FWD; gz += fz * Config.AK_HAND_FWD;
        attach[0] = xx; attach[1] = xy; attach[2] = xz; attach[3] = 0f;
        attach[4] = ux; attach[5] = uy; attach[6] = uz; attach[7] = 0f;
        attach[8] = -fx; attach[9] = -fy; attach[10] = -fz; attach[11] = 0f;
        attach[12] = gx; attach[13] = gy; attach[14] = gz; attach[15] = 1f;
        Matrix.multiplyMM(gunA, 0, base, 0, attach, 0);
        float L = Config.AK_LENGTH_WORLD;
        Matrix.scaleM(gunA, 0, L, L, L);
        Matrix.multiplyMM(gunB, 0, gunA, 0, gun.fix, 0);
        drawGunModel(vp, gunB);
        return true;
    }

    private void drawViewmodel(float aspect) {
        Game.Player p = game.p;
        if (!p.alive) return;
        GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT);
        Matrix.perspectiveM(proj, 0, 60f, aspect, 0.02f, 5f);
        GLES30.glUniform3f(uCam, 0f, 0f, 0f);
        float sway = p.moving ? (float) Math.sin(p.bob) * 0.012f : (float)Math.sin(game.time * 1.4f) * 0.0025f;
        float bob = p.moving ? Math.abs((float) Math.cos(p.bob)) * 0.012f : (float)Math.sin(game.time * 1.8f) * 0.002f;
        bob -= p.crouchBlend * 0.035f + p.proneBlend * 0.11f;
        float dip = 0f;
        float[] wdef = Game.W_RELOAD_PUBLIC();
        if (p.reloadT > 0f) dip = (float) Math.sin(Math.PI * (1f - p.reloadT / wdef[p.weapon]));
        Matrix.setIdentityM(base, 0);
        float wl = p.wallBlend * p.wallBlend * (3f - 2f * p.wallBlend);   // плавное убирание оружия у стены
        float a = p.aimT * (1f - wl);
        float px = (0.16f + sway) * (1f - a);
        float py = (-0.17f + bob - 0.2f * dip - p.crouchBlend * 0.035f - p.proneBlend * 0.13f) * (1f - a) + (-0.095f - 0.2f * dip) * a;
        float pz = -0.38f * (1f - a) - 0.30f * a + p.kick * 0.05f * (1f - 0.5f * a);
        Matrix.translateM(base, 0, px + 0.13f * wl, py - 0.20f * wl, pz + 0.22f * wl);   // вправо-вниз и назад к телу
        Matrix.rotateM(base, 0, p.kick * 4f - 28f * dip, 1f, 0f, 0f);
        Matrix.rotateM(base, 0, -62f * wl, 1f, 0f, 0f);    // ствол вниз
        Matrix.rotateM(base, 0, -28f * wl, 0f, 1f, 0f);    // ствол уходит вправо от стены
        Matrix.rotateM(base, 0, 10f * wl, 0f, 0f, 1f);     // небольшой крен
        float[] sleeve = {.26f, .3f, .2f}, dark = {.12f, .12f, .13f}, wood = {.35f, .2f, .1f};
        if (p.weapon == 0 && gun != null) {
            float L = Config.AK_LENGTH_VIEW;
            System.arraycopy(base, 0, gunA, 0, 16);
            Matrix.translateM(gunA, 0, 0f, Config.AK_VIEW_DY, 0f);
            Matrix.scaleM(gunA, 0, L, L, L);
            Matrix.multiplyMM(gunB, 0, gunA, 0, gun.fix, 0);
            drawGunModel(proj, gunB);
            vm(.04f, -.14f, .25f, .07f, .07f, .4f, sleeve);
            vm(-.07f, -.07f, -.25f, .07f, .07f, .4f, sleeve);
            if (p.flashT > 0f) box(proj, base, 0f, .02f, -(1f - Config.AK_GRIP_Z) * L - 0.05f, .09f, .09f, .06f, 1f, .85f, .3f, WHITE, 3, 1.6f);
        } else if (p.weapon == 0) {
            vm(.0f, .0f, .0f, .06f, .09f, .55f, dark);
            vm(.0f, .02f, -.45f, .025f, .025f, .4f, new float[]{.2f, .2f, .22f});
            vm(.0f, -.005f, -.22f, .07f, .07f, .25f, wood);
            vm(.0f, -.03f, .38f, .05f, .12f, .25f, wood);
            vm(.0f, -.15f, -.03f, .04f, .16f, .07f, dark);
            vm(.0f, .06f, -.62f, .01f, .04f, .01f, dark);
            vm(.04f, -.14f, .25f, .07f, .07f, .4f, sleeve);
            vm(-.07f, -.07f, -.25f, .07f, .07f, .4f, sleeve);
            if (p.flashT > 0f) box(proj, base, 0f, .02f, -.7f, .09f, .09f, .06f, 1f, .85f, .3f, WHITE, 3, 1.6f);
        } else {
            vm(0f, 0f, 0f, .04f, .06f, .2f, dark);
            vm(0f, -.07f, .07f, .035f, .11f, .05f, wood);
            vm(.02f, -.1f, .15f, .07f, .07f, .35f, sleeve);
            vm(-.03f, -.1f, .1f, .07f, .07f, .3f, sleeve);
            if (p.flashT > 0f) box(proj, base, 0f, 0f, -.14f, .06f, .06f, .05f, 1f, .85f, .3f, WHITE, 3, 1.6f);
        }
    }

    private void vm(float x, float y, float z, float sx, float sy, float sz, float[] c) {
        box(proj, base, x, y, z, sx, sy, sz, c[0], c[1], c[2], WHITE, 0, 0f);
    }
}
