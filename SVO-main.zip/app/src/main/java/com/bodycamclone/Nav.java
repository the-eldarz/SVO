package com.bodycamclone;

import java.util.Arrays;

/** Сетка проходимости карты (клетка 1 м) и поиск пути A* для ботов. Путь возвращается короткой ломаной. */
public final class Nav {
    private final int n;
    private final float half;
    private final boolean[] walk;
    private final float[] g;
    private final int[] parent, stamp, closed, cells;
    private int cur;
    private int[] hNode = new int[8192];
    private float[] hF = new float[8192];
    private int hN;
    private static final int[] DX = {1, -1, 0, 0, 1, 1, -1, -1}, DZ = {0, 0, 1, -1, 1, -1, 1, -1};

    public Nav(WorldMap map) {
        half = map.half;
        n = Math.round(half * 2f);
        int total = n * n;
        walk = new boolean[total]; g = new float[total];
        parent = new int[total]; stamp = new int[total]; closed = new int[total]; cells = new int[total];
        float lim = half - 0.9f;
        for (int cz = 0; cz < n; cz++) {
            for (int cx = 0; cx < n; cx++) {
                float x = cellC(cx), z = cellC(cz);
                walk[cz * n + cx] = Math.abs(x) <= lim && Math.abs(z) <= lim && !map.blocked(x, z, 0.36f);
            }
        }
    }

    private float cellC(int c) { return -half + c + 0.5f; }

    private int cell(float v) {
        int c = (int) Math.floor(v + half);
        return c < 0 ? 0 : (c >= n ? n - 1 : c);
    }

    public boolean isWalk(float x, float z) { return walk[cell(z) * n + cell(x)]; }

    private int nearestWalk(int cx, int cz, int maxR) {
        if (walk[cz * n + cx]) return cz * n + cx;
        for (int r = 1; r <= maxR; r++) {
            int best = -1;
            float bd = 1e9f;
            for (int dz = -r; dz <= r; dz++) {
                for (int dx = -r; dx <= r; dx++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                    int x = cx + dx, z = cz + dz;
                    if (x < 0 || z < 0 || x >= n || z >= n || !walk[z * n + x]) continue;
                    float d = dx * dx + dz * dz;
                    if (d < bd) { bd = d; best = z * n + x; }
                }
            }
            if (best >= 0) return best;
        }
        return -1;
    }

    private void push(int node, float f) {
        if (hN == hNode.length) { hNode = Arrays.copyOf(hNode, hN * 2); hF = Arrays.copyOf(hF, hN * 2); }
        int i = hN++;
        while (i > 0) {
            int par = (i - 1) >> 1;
            if (hF[par] <= f) break;
            hNode[i] = hNode[par]; hF[i] = hF[par];
            i = par;
        }
        hNode[i] = node; hF[i] = f;
    }

    private int pop() {
        int top = hNode[0];
        hN--;
        if (hN > 0) {
            int node = hNode[hN];
            float f = hF[hN];
            int i = 0;
            while (true) {
                int c = 2 * i + 1;
                if (c >= hN) break;
                if (c + 1 < hN && hF[c + 1] < hF[c]) c++;
                if (hF[c] >= f) break;
                hNode[i] = hNode[c]; hF[i] = hF[c];
                i = c;
            }
            hNode[i] = node; hF[i] = f;
        }
        return top;
    }

    private static float heur(int x, int z, int tx, int tz) {
        float dx = Math.abs(x - tx), dz = Math.abs(z - tz);
        return dx + dz - 0.5858f * Math.min(dx, dz);
    }

    private boolean lineWalk(int a, int b) {
        float x0 = cellC(a % n), z0 = cellC(a / n), x1 = cellC(b % n), z1 = cellC(b / n);
        float dx = x1 - x0, dz = z1 - z0, d = (float) Math.sqrt(dx * dx + dz * dz);
        if (d < 1e-4f) return true;
        int steps = (int) (d / 0.4f) + 1;
        float px = -dz / d * 0.3f, pz = dx / d * 0.3f;
        for (int i = 1; i <= steps; i++) {
            float f = (float) i / steps, x = x0 + dx * f, z = z0 + dz * f;
            if (!isWalk(x, z) || !isWalk(x + px, z + pz) || !isWalk(x - px, z - pz)) return false;
        }
        return true;
    }

    /**
     * Путь от (sx,sz) к (gx,gz). Заполняет ox/oz точками поворота (без стартовой) и возвращает их число.
     * 0 = пути нет или идти нужно напрямую.
     */
    public int path(float sx, float sz, float gx, float gz, float[] ox, float[] oz) {
        int s = nearestWalk(cell(sx), cell(sz), 2);
        int t = nearestWalk(cell(gx), cell(gz), 6);
        if (s < 0 || t < 0 || s == t) return 0;
        cur++;
        hN = 0;
        int tx = t % n, tz = t / n;
        g[s] = 0f; parent[s] = -1; stamp[s] = cur;
        push(s, heur(s % n, s / n, tx, tz));
        boolean found = false;
        int expanded = 0;
        while (hN > 0) {
            int c = pop();
            if (closed[c] == cur) continue;
            closed[c] = cur;
            if (c == t) { found = true; break; }
            if (++expanded > 6000) break;
            int cx = c % n, cz = c / n;
            for (int k = 0; k < 8; k++) {
                int nx = cx + DX[k], nz = cz + DZ[k];
                if (nx < 0 || nz < 0 || nx >= n || nz >= n) continue;
                int ni = nz * n + nx;
                if (!walk[ni] || closed[ni] == cur) continue;
                if (k >= 4 && (!walk[cz * n + nx] || !walk[nz * n + cx])) continue;   // не срезать углы
                float ng = g[c] + (k >= 4 ? 1.4142f : 1f);
                if (stamp[ni] != cur || ng < g[ni]) {
                    stamp[ni] = cur; g[ni] = ng; parent[ni] = c;
                    push(ni, ng + heur(nx, nz, tx, tz));
                }
            }
        }
        if (!found) return 0;
        int len = 0;
        for (int c = t; c != -1 && len < cells.length; c = parent[c]) cells[len++] = c;
        for (int i = 0, j = len - 1; i < j; i++, j--) { int tmp = cells[i]; cells[i] = cells[j]; cells[j] = tmp; }
        int cnt = 0, i0 = 0;
        while (i0 < len - 1 && cnt < ox.length) {
            int best = i0 + 1;
            for (int k = i0 + 2; k < len; k++) {
                if (lineWalk(cells[i0], cells[k])) best = k; else break;
            }
            ox[cnt] = cellC(cells[best] % n); oz[cnt] = cellC(cells[best] / n);
            cnt++;
            i0 = best;
        }
        return cnt;
    }
}
