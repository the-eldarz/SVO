package com.bodycamclone;

import android.content.Context;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.MotionEvent;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * 3D-превью снаряжения для меню: боец (его модель, выбранная форма) в позе покоя, выбранное оружие у него в руках,
 * аптечка на поясе, гранаты на разгрузке и ящик с патронами рядом. Тянешь пальцем - вращается.
 * Использует те же шейдеры, модели и анимации, что и сама игра.
 */
public final class LoadoutView extends GLSurfaceView {
    private static final String TAG = "Bodycam";
    private static final float[] WHITE = {1f, 1f, 1f};
    private static final float BG_R = 0.07f, BG_G = 0.09f, BG_B = 0.085f;

    public interface StatusListener { void onStatus(String text); }

    private volatile int side, uniform, camo, rifle, grenades;
    private volatile boolean medkit, ammoBox;
    private volatile float dragYaw = 25f;
    private volatile long lastTouch;
    private volatile boolean dragging;
    private volatile StatusListener statusListener;
    private float lastX;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Scene scene = new Scene();

    public LoadoutView(Context c) {
        super(c);
        setEGLContextClientVersion(3);
        setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        setRenderer(scene);
    }

    /** Можно вызывать в любой момент: превью подхватит новый выбор на следующем кадре. */
    public void setLoadout(int side, int uniform, int camo, int rifle, boolean medkit, boolean ammoBox, int grenades) {
        this.side = side; this.uniform = uniform; this.camo = camo; this.rifle = rifle;
        this.medkit = medkit; this.ammoBox = ammoBox; this.grenades = grenades;
    }

    public void setStatusListener(StatusListener l) { statusListener = l; }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = e.getX();
                dragging = true;
                lastTouch = SystemClock.uptimeMillis();
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            case MotionEvent.ACTION_MOVE:
                dragYaw += (e.getX() - lastX) * 0.45f;
                lastX = e.getX();
                lastTouch = SystemClock.uptimeMillis();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                lastTouch = SystemClock.uptimeMillis();
                return true;
            default:
                return super.onTouchEvent(e);
        }
    }

    // ---------- простые меши ----------

    private static int put(float[] d, int o, float x, float y, float z, float nx, float ny, float nz, float u, float v) {
        d[o] = x; d[o + 1] = y; d[o + 2] = z; d[o + 3] = nx; d[o + 4] = ny; d[o + 5] = nz; d[o + 6] = u; d[o + 7] = v;
        return o + 8;
    }

    /** Шар диаметром 1. */
    private static GlbModel.Prim makeSphere(int st, int sl) {
        float[] d = new float[(st + 1) * (sl + 1) * 8];
        int[] idx = new int[st * sl * 6];
        int o = 0;
        for (int i = 0; i <= st; i++) {
            double th = Math.PI * i / st;
            float y = (float) Math.cos(th), r = (float) Math.sin(th);
            for (int j = 0; j <= sl; j++) {
                double ph = 2 * Math.PI * j / sl;
                float x = r * (float) Math.cos(ph), z = r * (float) Math.sin(ph);
                o = put(d, o, .5f * x, .5f * y, .5f * z, x, y, z, (float) j / sl, (float) i / st);
            }
        }
        int k = 0;
        for (int i = 0; i < st; i++) for (int j = 0; j < sl; j++) {
            int a = i * (sl + 1) + j, b = a + sl + 1;
            idx[k++] = a; idx[k++] = b; idx[k++] = a + 1;
            idx[k++] = a + 1; idx[k++] = b; idx[k++] = b + 1;
        }
        GlbModel.Prim p = new GlbModel.Prim();
        p.data = d; p.idx = idx;
        return p;
    }

    /** Цилиндр диаметром 1 и высотой 1 вдоль оси Y, центр в нуле. */
    private static GlbModel.Prim makeCylinder(int seg) {
        int sideV = 2 * (seg + 1), capV = 2 * (seg + 2);
        float[] d = new float[(sideV + capV) * 8];
        int[] idx = new int[seg * 12];
        int o = 0;
        for (int j = 0; j <= seg; j++) {
            double a = 2 * Math.PI * j / seg;
            float x = (float) Math.cos(a), z = (float) Math.sin(a), u = (float) j / seg;
            o = put(d, o, .5f * x, .5f, .5f * z, x, 0f, z, u, 0f);
            o = put(d, o, .5f * x, -.5f, .5f * z, x, 0f, z, u, 1f);
        }
        int k = 0;
        for (int j = 0; j < seg; j++) {
            int a = j * 2;
            idx[k++] = a; idx[k++] = a + 1; idx[k++] = a + 2;
            idx[k++] = a + 1; idx[k++] = a + 3; idx[k++] = a + 2;
        }
        int top = sideV;
        o = put(d, o, 0f, .5f, 0f, 0f, 1f, 0f, .5f, .5f);
        for (int j = 0; j <= seg; j++) {
            double a = 2 * Math.PI * j / seg;
            o = put(d, o, .5f * (float) Math.cos(a), .5f, .5f * (float) Math.sin(a), 0f, 1f, 0f, .5f, .5f);
        }
        int bot = top + seg + 2;
        o = put(d, o, 0f, -.5f, 0f, 0f, -1f, 0f, .5f, .5f);
        for (int j = 0; j <= seg; j++) {
            double a = 2 * Math.PI * j / seg;
            o = put(d, o, .5f * (float) Math.cos(a), -.5f, .5f * (float) Math.sin(a), 0f, -1f, 0f, .5f, .5f);
        }
        for (int j = 0; j < seg; j++) { idx[k++] = top; idx[k++] = top + 1 + j; idx[k++] = top + 2 + j; }
        for (int j = 0; j < seg; j++) { idx[k++] = bot; idx[k++] = bot + 1 + j; idx[k++] = bot + 2 + j; }
        GlbModel.Prim p = new GlbModel.Prim();
        p.data = d; p.idx = idx;
        return p;
    }

    // ---------- сцена ----------

    private final class Scene implements GLSurfaceView.Renderer {
        private int prog, uMVP, uModel, uColor, uTint, uUseTex, uMode, uSun, uCam, uFog, uFogColor, uEmissive, uBones, uSkinned, uHeadGone;
        private GlbModel.Prim cube, sphere, cyl;
        private GlbModel soldier;
        private String soldierPath;
        private Gun gun;
        private boolean gunTried;
        private GlbModel.Clip idle;
        private List<GlbModel.Clip> userClips;
        /** Где у бойца перед грудью и спина (в координатах модели) - сюда крепятся гранаты и аптечка. */
        private float zChest = 0.16f, zBack = -0.14f;
        private final float[] bones = new float[GlbModel.MAX_BONES * 16];
        private final float[] proj = new float[16], view = new float[16], vp = new float[16];
        private final float[] base = new float[16], tmp = new float[16], mvp = new float[16], aux = new float[16];
        private final float[] attach = new float[16], gunA = new float[16], gunB = new float[16];
        private final float[] handR = new float[3], handL = new float[3];
        private int w = 1, h = 1;
        private long lastNs;
        private float time, autoYaw;
        private String lastStatus = "";

        @Override
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            int vs = compile(GLES30.GL_VERTEX_SHADER, GameRenderer.VS), fs = compile(GLES30.GL_FRAGMENT_SHADER, GameRenderer.FS);
            prog = GLES30.glCreateProgram();
            GLES30.glAttachShader(prog, vs);
            GLES30.glAttachShader(prog, fs);
            GLES30.glLinkProgram(prog);
            int[] ok = new int[1];
            GLES30.glGetProgramiv(prog, GLES30.GL_LINK_STATUS, ok, 0);
            if (ok[0] == 0) throw new RuntimeException("link: " + GLES30.glGetProgramInfoLog(prog));
            uMVP = loc("uMVP"); uModel = loc("uModel"); uColor = loc("uColor"); uTint = loc("uTint");
            uUseTex = loc("uUseTex"); uMode = loc("uMode"); uSun = loc("uSun"); uCam = loc("uCam");
            uFog = loc("uFog"); uFogColor = loc("uFogColor"); uEmissive = loc("uEmissive");
            uBones = loc("uBones[0]"); uSkinned = loc("uSkinned"); uHeadGone = loc("uHeadGone");
            cube = GameRenderer.makeCube(); cube.uploadGeometry();
            sphere = makeSphere(14, 20); sphere.uploadGeometry();
            cyl = makeCylinder(28); cyl.uploadGeometry();
            // контекст мог пересоздаться: всё, что лежало в старом, загружаем заново
            soldier = null; soldierPath = null; gun = null; gunTried = false; idle = null;
            GLES30.glEnable(GLES30.GL_DEPTH_TEST);
            lastNs = 0;
        }

        @Override
        public void onSurfaceChanged(GL10 gl, int width, int height) {
            w = Math.max(1, width); h = Math.max(1, height);
            GLES30.glViewport(0, 0, w, h);
        }

        private int loc(String n) { return GLES30.glGetUniformLocation(prog, n); }

        private int compile(int type, String src) {
            int s = GLES30.glCreateShader(type);
            GLES30.glShaderSource(s, src);
            GLES30.glCompileShader(s);
            int[] ok = new int[1];
            GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0);
            if (ok[0] == 0) throw new RuntimeException("shader: " + GLES30.glGetShaderInfoLog(s));
            return s;
        }

        // ----- загрузка -----

        private GlbModel load(String path, float height) {
            try (InputStream in = GameFiles.open(path)) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 20);
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                GlbModel m = GlbModel.parse(bo.toByteArray(), height);
                m.upload();
                return m;
            } catch (Throwable e) {
                Log.w(TAG, "loadout model " + path + ": " + e);
                return null;
            }
        }

        private void free(GlbModel m) {
            if (m == null) return;
            int[] one = new int[1];
            for (GlbModel.Prim p : m.prims) {
                if (p.vao != 0) { one[0] = p.vao; GLES30.glDeleteVertexArrays(1, one, 0); }
                int[] bufs = {p.vbo, p.ibo, p.skinVbo, p.headVbo};
                GLES30.glDeleteBuffers(4, bufs, 0);
                if (p.tex != 0) { one[0] = p.tex; GLES30.glDeleteTextures(1, one, 0); }
            }
        }

        /** Подбирает клип покоя под скелет бойца и замеряет, где у него грудь и спина. */
        private void analyze() {
            idle = null;
            try {
                if (soldier.boneCount > 0) {
                    if (userClips == null) userClips = AnimationLibrary.loadClips(getContext()).clips;
                    List<GlbModel.Clip> all = new ArrayList<>(userClips);
                    all.addAll(soldier.clips);
                    AnimationLibrary.Set set = AnimationLibrary.classify(all);
                    if (set.idle != null && soldier.matchCount(set.idle) >= 5) idle = set.idle;
                }
            } catch (Throwable e) {
                Log.w(TAG, "loadout anim: " + e);
            }
            float zf = -1e9f, zb = 1e9f;
            boolean gotF = false, gotB = false;
            for (GlbModel.Prim p : soldier.prims) for (int i = 0; i + 2 < p.data.length; i += 8) {
                float y = p.data[i + 1], z = p.data[i + 2];
                if (y > 1.10f && y < 1.40f && z > zf) { zf = z; gotF = true; }
                if (y > 0.75f && y < 1.15f && z < zb) { zb = z; gotB = true; }
            }
            zChest = gotF ? Math.max(0.08f, Math.min(0.30f, zf)) : 0.16f;
            zBack = gotB ? Math.max(-0.30f, Math.min(-0.06f, zb)) : -0.14f;
        }

        private void report(String s) {
            if (s.equals(lastStatus)) return;
            lastStatus = s;
            final StatusListener l = statusListener;
            final String text = s;
            if (l != null) ui.post(() -> l.onStatus(text));
        }

        private void ensure(int sd, int un, int rf) {
            String want = Config.uniformModel(sd, un);
            if (!want.equals(soldierPath)) {
                free(soldier);
                soldier = null; idle = null;
                soldierPath = want;
                soldier = load(want, Config.SOLDIER_HEIGHT);
                if (soldier != null) analyze();
            }
            if (rf == 1 && !gunTried) {
                gunTried = true;
                GlbModel gm = load(Config.AK_MODEL, 1f);
                gun = gm != null ? new Gun(gm) : null;
            }
            StringBuilder sb = new StringBuilder();
            if (soldier == null) sb.append("Нет модели бойца: ").append(soldierPath.substring(soldierPath.lastIndexOf('/') + 1));
            if (rf == 1 && gun == null) {
                if (sb.length() > 0) sb.append("  ·  ");
                sb.append("нет ak-74m.glb, показан простой АК");
            }
            report(sb.toString());
        }

        // ----- рисование -----

        private void setU(float[] mvpM, float[] modelM, float r, float g, float b, float[] tint, int useTex) {
            GLES30.glUniformMatrix4fv(uMVP, 1, false, mvpM, 0);
            GLES30.glUniformMatrix4fv(uModel, 1, false, modelM, 0);
            GLES30.glUniform4f(uColor, r, g, b, 1f);
            GLES30.glUniform3f(uTint, tint[0], tint[1], tint[2]);
            GLES30.glUniform1i(uMode, 0);
            GLES30.glUniform1f(uEmissive, 0f);
            GLES30.glUniform1i(uUseTex, useTex);
            GLES30.glUniform1i(uSkinned, 0);
            GLES30.glUniform1i(uHeadGone, 0);
        }

        /** Деталь: parent * T(cx,cy,cz) * S(sx,sy,sz). */
        private void part(GlbModel.Prim pr, float[] parent, float cx, float cy, float cz, float sx, float sy, float sz, float[] c) {
            System.arraycopy(parent, 0, tmp, 0, 16);
            Matrix.translateM(tmp, 0, cx, cy, cz);
            Matrix.scaleM(tmp, 0, sx, sy, sz);
            Matrix.multiplyMM(mvp, 0, vp, 0, tmp, 0);
            setU(mvp, tmp, c[0], c[1], c[2], WHITE, 0);
            pr.draw();
        }

        private void drawGun(float[] modelM) {
            Matrix.multiplyMM(mvp, 0, vp, 0, modelM, 0);
            for (GlbModel.Prim p : gun.model.prims) {
                setU(mvp, modelM, p.color[0], p.color[1], p.color[2], WHITE, p.tex != 0 ? 1 : 0);
                if (p.tex != 0) { GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, p.tex); }
                p.draw();
            }
        }

        /** Простой АК из боксов (если выбран АК-74 или нет файла ak-74m.glb). Начало координат - рукоять, ствол в -Z. */
        private void drawBoxRifle(float[] parent) {
            float[] dark = {.12f, .12f, .13f}, wood = {.35f, .2f, .1f}, steel = {.2f, .2f, .22f};
            part(cube, parent, 0f, 0f, 0f, .06f, .09f, .55f, dark);
            part(cube, parent, 0f, .02f, -.45f, .025f, .025f, .4f, steel);
            part(cube, parent, 0f, -.005f, -.22f, .07f, .07f, .25f, wood);
            part(cube, parent, 0f, -.03f, .38f, .05f, .12f, .25f, wood);
            part(cube, parent, 0f, -.15f, -.03f, .04f, .16f, .07f, dark);
        }

        /** Оружие в руках: ствол от правой кисти к левой (как у бойцов в игре). */
        private void drawHeldWeapon(boolean posed, int rf) {
            float fx = 0f, fy = -0.08f, fz = 1f, gx, gy, gz;
            if (posed && soldier.jointPos(soldier.boneRHand, handR) && soldier.jointPos(soldier.boneLHand, handL)) {
                float dx = handL[0] - handR[0], dy = handL[1] - handR[1], dz = handL[2] - handR[2];
                float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (l > 0.10f && dz / l > 0.45f) { fx = dx / l; fy = dy / l; fz = dz / l; }
                gx = handR[0]; gy = handR[1]; gz = handR[2];
            } else {
                gx = 0.18f; gy = 1.2f; gz = 0.15f;
            }
            float fl = (float) Math.sqrt(fx * fx + fy * fy + fz * fz);
            fx /= fl; fy /= fl; fz /= fl;
            float ux = -fx * fy, uy = 1f - fy * fy, uz = -fz * fy;
            float ul = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
            if (ul < 1e-4f) { ux = 0f; uy = 0f; uz = 1f; } else { ux /= ul; uy /= ul; uz /= ul; }
            float xx = fy * uz - fz * uy, xy = fz * ux - fx * uz, xz = fx * uy - fy * ux;
            gx += fx * Config.AK_HAND_FWD; gy += fy * Config.AK_HAND_FWD; gz += fz * Config.AK_HAND_FWD;
            attach[0] = xx; attach[1] = xy; attach[2] = xz; attach[3] = 0f;
            attach[4] = ux; attach[5] = uy; attach[6] = uz; attach[7] = 0f;
            attach[8] = -fx; attach[9] = -fy; attach[10] = -fz; attach[11] = 0f;
            attach[12] = gx; attach[13] = gy; attach[14] = gz; attach[15] = 1f;
            Matrix.multiplyMM(gunA, 0, base, 0, attach, 0);
            if (rf == 1 && gun != null) {
                float L = Config.AK_LENGTH_WORLD;
                Matrix.scaleM(gunA, 0, L, L, L);
                Matrix.multiplyMM(gunB, 0, gunA, 0, gun.fix, 0);
                drawGun(gunB);
            } else {
                Matrix.scaleM(gunA, 0, 0.9f, 0.9f, 0.9f);
                drawBoxRifle(gunA);
            }
        }

        private void drawMedkit() {
            float[] white = {.92f, .92f, .88f}, red = {.80f, .08f, .06f}, strap = {.12f, .13f, .12f};
            System.arraycopy(base, 0, aux, 0, 16);
            Matrix.translateM(aux, 0, 0f, 0.98f, zBack - 0.045f);
            part(cube, aux, 0f, 0f, 0f, .26f, .18f, .09f, white);
            part(cube, aux, 0f, 0f, -.047f, .14f, .04f, .012f, red);
            part(cube, aux, 0f, 0f, -.047f, .04f, .14f, .012f, red);
            part(cube, aux, 0f, .075f, 0f, .27f, .03f, .095f, strap);
        }

        private void drawGrenades(int count) {
            float[] xs = count >= 4 ? new float[]{-.20f, -.08f, .08f, .20f} : new float[]{-.10f, .10f};
            float[] olive = {.24f, .30f, .19f}, grey = {.45f, .46f, .44f};
            for (float x : xs) {
                System.arraycopy(base, 0, aux, 0, 16);
                Matrix.translateM(aux, 0, x, 1.14f, zChest + 0.035f);
                part(sphere, aux, 0f, 0f, 0f, .085f, .105f, .085f, olive);
                part(cyl, aux, 0f, .062f, 0f, .04f, .03f, .04f, grey);
                part(cube, aux, .026f, .07f, 0f, .018f, .05f, .012f, grey);
            }
        }

        private void drawAmmoCrate() {
            float[] olive = {.28f, .33f, .20f}, lid = {.20f, .24f, .14f}, dark = {.1f, .1f, .1f}, label = {.88f, .78f, .22f};
            System.arraycopy(base, 0, aux, 0, 16);
            Matrix.translateM(aux, 0, 0.78f, 0f, 0.05f);
            Matrix.rotateM(aux, 0, -22f, 0f, 1f, 0f);
            part(cube, aux, 0f, .11f, 0f, .44f, .22f, .27f, olive);
            part(cube, aux, 0f, .225f, 0f, .455f, .025f, .285f, lid);
            part(cube, aux, -.23f, .12f, 0f, .022f, .06f, .12f, dark);
            part(cube, aux, .23f, .12f, 0f, .022f, .06f, .12f, dark);
            part(cube, aux, 0f, .12f, .138f, .20f, .09f, .006f, label);
        }

        @Override
        public void onDrawFrame(GL10 gl) {
            long now = System.nanoTime();
            float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
            lastNs = now;
            time += dt;
            final int sd = side, un = uniform, cm = camo, rf = rifle, gr = grenades;
            final boolean mk = medkit, ab = ammoBox;
            if (!dragging && SystemClock.uptimeMillis() - lastTouch > 1200) autoYaw += dt * 14f;
            ensure(sd, un, rf);

            GLES30.glClearColor(BG_R, BG_G, BG_B, 1f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);
            GLES30.glUseProgram(prog);
            float aspect = (float) w / h;
            float dist = 4.2f * Math.max(1f, 1.15f / aspect);
            Matrix.perspectiveM(proj, 0, 32f, aspect, 0.2f, 40f);
            Matrix.setLookAtM(view, 0, 0f, 1.35f, dist, 0f, 0.95f, 0f, 0f, 1f, 0f);
            Matrix.multiplyMM(vp, 0, proj, 0, view, 0);
            GLES30.glUniform3f(uSun, .45f, .85f, .75f);
            GLES30.glUniform3f(uCam, 0f, 1.35f, dist);
            GLES30.glUniform1f(uFog, 1000f);
            GLES30.glUniform3f(uFogColor, BG_R, BG_G, BG_B);

            float yawOff = sd == Config.SIDE_RU ? Config.RU_YAW_OFFSET_DEG : Config.UA_YAW_OFFSET_DEG;
            Matrix.setIdentityM(base, 0);
            Matrix.rotateM(base, 0, dragYaw + autoYaw + yawOff, 0f, 1f, 0f);

            // подиум
            part(cyl, base, 0f, -.015f, 0f, 1.95f, .03f, 1.95f, new float[]{.30f, .40f, .28f});
            part(cyl, base, 0f, -.02f, 0f, 1.85f, .04f, 1.85f, new float[]{.14f, .17f, .15f});

            if (soldier != null) {
                float[] ut = Config.camoTint(cm);
                float[] tint = {Config.ALLY_TINT[0] * ut[0], Config.ALLY_TINT[1] * ut[1], Config.ALLY_TINT[2] * ut[2]};
                boolean posed = idle != null;
                if (posed) {
                    float t = time % Math.max(0.01f, idle.duration);
                    soldier.pose(idle, t, null, 0f, 1f, bones);
                    GLES30.glUniformMatrix4fv(uBones, soldier.boneCount, false, bones, 0);
                }
                Matrix.multiplyMM(mvp, 0, vp, 0, base, 0);
                for (GlbModel.Prim p : soldier.prims) {
                    setU(mvp, base, p.color[0], p.color[1], p.color[2], tint, p.tex != 0 ? 1 : 0);
                    if (posed && p.skinData != null) GLES30.glUniform1i(uSkinned, 1);
                    if (p.tex != 0) { GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, p.tex); }
                    p.draw();
                }
                drawHeldWeapon(posed, rf);
                if (mk) drawMedkit();
                if (gr > 0) drawGrenades(gr == 1 ? 2 : 4);
            }
            if (ab) drawAmmoCrate();
        }
    }
}
