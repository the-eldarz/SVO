package com.bodycamclone;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Game {
    public static final class Input {
        public volatile float moveX, moveY;
        public volatile boolean fire;
        public float lookDX, lookDY;
        /** Накопленный поворот гироскопа в радианах (вправо / вниз). Заполняет GyroController. */
        public float gyroDX, gyroDY;
        public volatile boolean ads;
        public volatile boolean crouchToggle, proneToggle;
        public boolean reload, sw, restart, zoom, crouch, prone;
    }

    public static final class Player {
        public float x, z, yaw, pitch, hp = 100f;
        public boolean alive = true, moving, crouched, prone;
        public float crouchBlend, proneBlend;
        public float hurtT, hitT, fireCd, reloadT, flashT, kick, bob, deadT, aimT;
        public int weapon, zoom;
        public int[] ammo = new int[2], reserve = new int[2];
        boolean firePrev;
        float stepSign = 1f;
    }

    public static final String[] W_NAME = {"АК-74", "ПМ"};
    static final float[] W_DMG = {35f, 28f}, W_CD = {0.10f, 0.30f}, W_RELOAD = {2.2f, 1.6f}, W_SPREAD = {0.012f, 0.008f};
    static final int[] W_MAG = {30, 8};
    static final boolean[] W_AUTO = {true, false};

    public static float[] W_RELOAD_PUBLIC() { return W_RELOAD; }

    public final Input input = new Input();
    public final Player p = new Player();
    public final List<Soldier> soldiers = new ArrayList<>();
    public static final class BulletMark {
        public float x, y, z, nx, ny, nz, life = 45f;
        BulletMark(float x, float y, float z, float nx, float ny, float nz) { this.x=x; this.y=y; this.z=z; this.nx=nx; this.ny=ny; this.nz=nz; }
    }
    public final List<BulletMark> bulletMarks = new ArrayList<>();
    public final WorldMap map;
    private final Nav nav;
    private int pathBudget, allySlot;
    private float mvx, mvz;
    private final Soldier[] cS = new Soldier[3];
    private final float[] cD = new float[3];
    private int cN;
    /** За кого играет игрок: Config.SIDE_RU / SIDE_UA. */
    public final int side;
    public volatile boolean paused;
    public SoundBank snd;
    public volatile int kills, wave, enemiesLeft, alliesLeft;
    public volatile String status = "";
    public volatile boolean statusError;
    public float time;
    private final Random rnd = new Random();
    private final float[] tmp = new float[2];
    private float lookBufX, lookBufY;   // остаток сглаживания прицела
    private float waveTimer = -1f, ambT = 3f;

    public Game(long mapSeed, int side) {
        this.map = new WorldMap(mapSeed);
        this.nav = new Nav(map);
        this.side = side;
        reset();
    }

    /** Текущее вертикальное поле зрения с учётом прицела и зума. */
    public float curFov() {
        return (float) Math.toDegrees(2.0 * Math.atan(tanHalfFov()));
    }

    private float tanHalfFov() {
        float f = Config.BASE_FOV + (Config.ADS_FOV - Config.BASE_FOV) * p.aimT;
        return (float) Math.tan(Math.toRadians(f / 2.0)) / Config.ZOOM_STEPS[p.zoom];
    }

    public void reset() {
        soldiers.clear();
        bulletMarks.clear();
        p.x = map.playerSpawn[0]; p.z = map.playerSpawn[1]; p.yaw = 0f; p.pitch = 0f;
        p.hp = 100f; p.alive = true; p.deadT = 0f; p.weapon = 0; p.reloadT = 0f; p.fireCd = 0f;
        p.ammo[0] = W_MAG[0]; p.ammo[1] = W_MAG[1]; p.reserve[0] = 120; p.reserve[1] = 40;
        kills = 0; wave = 0; waveTimer = -1f;
        p.zoom = 0; p.aimT = 0f; input.ads = false; lookBufX = 0f; lookBufY = 0f;
        spawnWave();
    }

    private void place(Soldier s) {
        tmp[0] = s.x; tmp[1] = s.z;
        map.resolve(tmp, 0.4f);
        s.x = tmp[0]; s.z = tmp[1];
        soldiers.add(s);
    }

    private void spawnWave() {
        wave++;
        int n = Math.min(3 + wave * 2, 14);
        for (int i = 0; i < n; i++) {
            float[] sp = map.enemySpawns.get(rnd.nextInt(map.enemySpawns.size()));
            Soldier en = new Soldier(1, sp[0] + (rnd.nextFloat() - .5f), sp[1], (float) Math.PI);
            en.flank = rnd.nextInt(3) - 1;
            en.pathT = rnd.nextFloat();
            en.stateT = 1f + rnd.nextFloat() * 3f;
            place(en);
        }
        int alive = 0;
        for (Soldier s : soldiers) if (s.team == 0 && !s.dead) alive++;
        for (int i = alive; i < Config.ALLIES; i++) {
            float[] sp = map.allySpawns.get(rnd.nextInt(map.allySpawns.size()));
            Soldier al = new Soldier(0, sp[0], sp[1], 0f);
            al.slot = allySlot++ % 5;
            al.pathT = rnd.nextFloat();
            place(al);
        }
        if (wave > 1 && p.alive) {
            p.hp = Math.min(100f, p.hp + 35f);
            p.reserve[0] += 60; p.reserve[1] += 16;
        }
    }

    private void sfx(int id, float vol, float rate) { if (snd != null) snd.play(id, vol, rate); }

    public void update(float dt) {
        if (dt <= 0f || paused) return;
        float ldx, ldy; boolean reload, sw, restart, zoom, crouch, prone;
        synchronized (input) {
            ldx = input.lookDX; ldy = input.lookDY; input.lookDX = 0; input.lookDY = 0;
            reload = input.reload; sw = input.sw; restart = input.restart; zoom = input.zoom; crouch = input.crouchToggle; prone = input.proneToggle;
            input.crouchToggle = false; input.proneToggle = false;
            input.reload = false; input.sw = false; input.restart = false; input.zoom = false;
        }
        time += dt;
        for (Iterator<BulletMark> marks = bulletMarks.iterator(); marks.hasNext();) { BulletMark mark = marks.next(); mark.life -= dt; if (mark.life <= 0f) marks.remove(); }
        if (p.alive) updatePlayer(dt, ldx, ldy, reload, sw, zoom, crouch, prone);
        else { p.deadT += dt; if (restart && p.deadT > 1f) { reset(); return; } }

        pathBudget = 2;
        for (Soldier s : soldiers) updateSoldier(s, dt);
        int n = soldiers.size();
        for (int i = 0; i < n; i++) {
            Soldier a = soldiers.get(i);
            if (a.dead) continue;
            for (int j = i + 1; j < n; j++) {
                Soldier b = soldiers.get(j);
                if (b.dead) continue;
                float dx = b.x - a.x, dz = b.z - a.z, d2 = dx * dx + dz * dz;
                if (d2 < 0.49f && d2 > 1e-6f) {
                    float d = (float) Math.sqrt(d2), push = (0.7f - d) * 0.5f;
                    a.x -= dx / d * push; a.z -= dz / d * push; b.x += dx / d * push; b.z += dz / d * push;
                }
            }
        }
        Iterator<Soldier> it = soldiers.iterator();
        while (it.hasNext()) { Soldier s = it.next(); if (s.dead && s.deadT > 25f) it.remove(); }
        int e = 0, a = 0;
        for (Soldier s : soldiers) if (!s.dead) { if (s.team == 1) e++; else a++; }
        enemiesLeft = e; alliesLeft = a;
        if (e == 0 && p.alive) {
            if (waveTimer < 0f) waveTimer = 4f;
            waveTimer -= dt;
            if (waveTimer <= 0f) { waveTimer = -1f; spawnWave(); }
        }
        ambT -= dt;
        if (ambT <= 0f) { ambT = 2f + rnd.nextFloat() * 5f; sfx(SoundBank.FAR, 0.2f + rnd.nextFloat() * 0.2f, 0.9f + rnd.nextFloat() * 0.2f); }
    }

    private void updatePlayer(float dt, float ldx, float ldy, boolean reload, boolean sw, boolean zoom, boolean crouch, boolean prone) {
        if (prone) { p.prone = !p.prone; if (p.prone) p.crouched = false; }
        if (crouch) { p.crouched = !p.crouched; if (p.crouched) p.prone = false; }
        p.crouchBlend += ((p.crouched ? 1f : 0f) - p.crouchBlend) * Math.min(1f, dt * 8f);
        p.proneBlend += ((p.prone ? 1f : 0f) - p.proneBlend) * Math.min(1f, dt * 7f);
        if (zoom) p.zoom = (p.zoom + 1) % Config.ZOOM_STEPS.length;
        float aimTarget = input.ads ? 1f : 0f;
        float aimStep = dt * 7f, aimDiff = aimTarget - p.aimT;
        p.aimT += Math.abs(aimDiff) <= aimStep ? aimDiff : Math.signum(aimDiff) * aimStep;
        // чем сильнее приближение, тем медленнее поворот камеры
        float fovScale = tanHalfFov() / (float) Math.tan(Math.toRadians(Config.BASE_FOV / 2.0));
        // чувствительность плавно переходит от обычной к «с прицелом»
        float sensMul = Settings.sens + (Settings.adsSens - Settings.sens) * p.aimT;
        float sens = Config.LOOK_SENS * sensMul * fovScale;
        // ускорение: чем быстрее свайп, тем сильнее поворот
        if (Settings.accel > 0f) {
            float speed = (float) Math.hypot(ldx, ldy) / dt;               // пикселей в секунду
            float gain = 1f + Settings.accel * Math.min(speed / 2500f, 2f);
            ldx *= gain; ldy *= gain;
        }
        // сглаживание прицела: 1 - выкл, меньше - плавнее (движение не теряется, а растягивается во времени)
        lookBufX += ldx; lookBufY += ldy;
        float k = Settings.smooth >= 0.999f ? 1f : 1f - (float) Math.pow(1f - Settings.smooth, dt * 60f);
        float sdx = lookBufX * k, sdy = lookBufY * k;
        lookBufX -= sdx; lookBufY -= sdy;
        float dy = Settings.invertY ? -sdy : sdy;
        p.yaw += sdx * sens;
        p.pitch = Math.max(-1.35f, Math.min(1.35f, p.pitch - dy * sens));
        // гироскоп
        float gdx, gdy;
        synchronized (input) { gdx = input.gyroDX; gdy = input.gyroDY; input.gyroDX = 0f; input.gyroDY = 0f; }
        if (Settings.gyroMode == Settings.GYRO_ON || (Settings.gyroMode == Settings.GYRO_ADS && input.ads)) {
            float gs = (Settings.gyroSens + (Settings.gyroAdsSens - Settings.gyroSens) * p.aimT) * fovScale;
            gdx *= Settings.gyroInvX ? -gs : gs;
            gdy *= Settings.gyroInvY ? -gs : gs;
            p.yaw += gdx;
            p.pitch = Math.max(-1.35f, Math.min(1.35f, p.pitch - gdy));
        }
        p.hurtT = Math.max(0f, p.hurtT - dt); p.hitT = Math.max(0f, p.hitT - dt);
        p.flashT = Math.max(0f, p.flashT - dt); p.kick = Math.max(0f, p.kick - dt * 7f);
        p.fireCd -= dt;

        float mx = input.moveX, my = input.moveY;
        float mag = Math.min(1f, (float) Math.hypot(mx, my));
        float sy = (float) Math.sin(p.yaw), cy = (float) Math.cos(p.yaw);
        p.moving = mag > 0.1f;
        if (p.moving) {
            float speed = 4.3f * mag * (1f - 0.35f * p.aimT) * (p.prone ? 0.22f : (p.crouched ? 0.52f : 1f));
            float vx = (sy * my + cy * mx) / mag * speed, vz = (-cy * my + sy * mx) / mag * speed;
            tmp[0] = p.x + vx * dt; tmp[1] = p.z + vz * dt;
            map.resolve(tmp, 0.35f);
            p.x = tmp[0]; p.z = tmp[1];
            p.bob += dt * speed * 1.9f;
            float sgn = Math.signum((float) Math.sin(p.bob));
            if (sgn != 0f && sgn != p.stepSign) { p.stepSign = sgn; sfx(SoundBank.STEP, 0.35f, 0.9f + rnd.nextFloat() * 0.2f); }
        }
        int w = p.weapon;
        if (p.reloadT > 0f) {
            p.reloadT -= dt;
            if (p.reloadT <= 0f) {
                int take = Math.min(W_MAG[w] - p.ammo[w], p.reserve[w]);
                p.ammo[w] += take; p.reserve[w] -= take;
            }
        } else {
            if (sw) { p.weapon = 1 - p.weapon; p.fireCd = 0.35f; p.kick = 1f; w = p.weapon; }
            else if (reload && p.ammo[w] < W_MAG[w] && p.reserve[w] > 0) startReload();
        }
        boolean fire = input.fire;
        boolean can = fire && p.fireCd <= 0f && p.reloadT <= 0f && (W_AUTO[w] || !p.firePrev);
        if (can) {
            if (p.ammo[w] > 0) { p.ammo[w]--; p.fireCd = W_CD[w]; playerShoot(); }
            else { p.fireCd = 0.3f; sfx(SoundBank.EMPTY, 0.6f, 1f); if (p.reserve[w] > 0) startReload(); }
        }
        p.firePrev = fire;
    }

    private void startReload() { p.reloadT = W_RELOAD[p.weapon]; sfx(SoundBank.RELOAD, 0.7f, 1f); }

    private void playerShoot() {
        int w = p.weapon;
        sfx(w == 0 ? SoundBank.RIFLE : SoundBank.PISTOL, 1f, 0.97f + rnd.nextFloat() * 0.06f);
        p.flashT = 0.05f; p.kick = 1f;
        p.pitch += 0.012f; p.yaw += (rnd.nextFloat() - .5f) * 0.004f;
        float cp = (float) Math.cos(p.pitch), sp = (float) Math.sin(p.pitch);
        float sy = (float) Math.sin(p.yaw), cy = (float) Math.cos(p.yaw);
        float spr = W_SPREAD[w] * (p.moving ? 1.8f : 1f) * (1f - 0.5f * p.aimT);
        float rx = (rnd.nextFloat() - .5f) * 2f * spr, ry = (rnd.nextFloat() - .5f) * 2f * spr;
        float dx = cp * sy + cy * rx - sp * sy * ry;
        float dy = sp + cp * ry;
        float dz = -cp * cy + sy * rx + sp * cy * ry;
        float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= l; dy /= l; dz /= l;
        float ox = p.x, oy = 1.55f, oz = p.z;
        float bestT = map.raycast(ox, oy, oz, dx, dy, dz, 150f);
        Soldier best = null; boolean head = false;
        for (Soldier s : soldiers) {
            if (s.dead || (s.team == 0 && !Settings.friendlyFire)) continue;
            float t = WorldMap.rayAabb(ox, oy, oz, dx, dy, dz, s.x - .32f, 0f, s.z - .32f, s.x + .32f, 1.85f, s.z + .32f);
            if (t >= 0f && t < bestT) { bestT = t; best = s; head = (oy + dy * t) > 1.5f; }
        }
        if (best != null) {
            p.hitT = 0.18f;
            sfx(SoundBank.TICK, 0.7f, head ? 1.4f : 1f);
            if (damage(best, head ? W_DMG[w] * 3f : W_DMG[w])) kills++;
        } else if (bestT < 149.9f) {
            addBulletMark(ox, oy, oz, dx, dy, dz, bestT);
        }
    }

    private void addBulletMark(float ox, float oy, float oz, float dx, float dy, float dz, float t) {
        float x = ox + dx * t, y = oy + dy * t, z = oz + dz * t;
        float nx = 0f, ny = 1f, nz = 0f, closest = Float.MAX_VALUE;
        for (WorldMap.Box b : map.boxes) {
            if (!b.block) continue;
            float hit = WorldMap.rayAabb(ox, oy, oz, dx, dy, dz, b.x0, b.y0, b.z0, b.x1, b.y1, b.z1);
            if (hit < 0f || Math.abs(hit - t) > 0.025f) continue;
            float[] ds = {Math.abs(x-b.x0), Math.abs(x-b.x1), Math.abs(y-b.y0), Math.abs(y-b.y1), Math.abs(z-b.z0), Math.abs(z-b.z1)};
            for (int i=0;i<6;i++) if (ds[i] < closest) { closest=ds[i]; nx=(i==0?-1:i==1?1:0); ny=(i==2?-1:i==3?1:0); nz=(i==4?-1:i==5?1:0); }
        }
        bulletMarks.add(new BulletMark(x + nx*.008f, y + ny*.008f, z + nz*.008f, nx, ny, nz));
        while (bulletMarks.size() > 120) bulletMarks.remove(0);
    }

    /** true, если боец убит этим попаданием */
    private boolean damage(Soldier s, float d) {
        if (s.dead) return false;
        s.hp -= d; s.hitFlash = 0.15f; s.underFire = Math.max(s.underFire, 2.5f);
        sfx(SoundBank.HIT, 0.5f, 0.9f + rnd.nextFloat() * 0.3f);
        if (s.hp <= 0f) {
            s.dead = true; s.deadT = 0f;
            // Arcade-style physics fall: a sideways impulse, gravity and ground damping.
            s.fallY = 0f; s.fallVy = 1.4f;
            s.fallAngle = 0f;
            s.fallAngularVelocity = (rnd.nextBoolean() ? 1f : -1f) * (4.0f + rnd.nextFloat() * 2.0f);
            s.bloodFade = 1f;
            sfx(SoundBank.DEATH, 0.5f, 0.9f + rnd.nextFloat() * 0.2f);
            return true;
        }
        return false;
    }

    private void damagePlayer(float d) {
        if (!p.alive) return;
        p.hp -= d; p.hurtT = 0.4f;
        sfx(SoundBank.HURT, 0.8f, 1f);
        if (p.hp <= 0f) { p.hp = 0f; p.alive = false; p.deadT = 0f; sfx(SoundBank.DEATH, 0.8f, 0.8f); }
    }

    private static float wrap(float a) {
        while (a > Math.PI) a -= 2 * Math.PI;
        while (a < -Math.PI) a += 2 * Math.PI;
        return a;
    }

    private static float turn(float a, float target, float step) {
        float d = wrap(target - a);
        return Math.abs(d) <= step ? target : a + Math.signum(d) * step;
    }

    private void updateSoldier(Soldier s, float dt) {
        if (s.dead) {
            s.deadT += dt;
            s.fallVy -= 9.8f * dt;
            s.fallY += s.fallVy * dt;
            if (s.fallY < 0f) { s.fallY = 0f; s.fallVy = 0f; }
            s.fallAngle += s.fallAngularVelocity * dt;
            s.fallAngularVelocity *= (float)Math.pow(0.08f, dt);
            s.bloodFade = Math.max(0f, 1f - s.deadT / 25f);
            return;
        }
        s.fireCd -= dt; s.flash -= dt; s.hitFlash -= dt; s.strafeT -= dt;
        s.reactT -= dt; s.avoidT -= dt; s.losT -= dt; s.stateT -= dt; s.underFire -= dt;
        s.coverT -= dt; s.coverRetryT -= dt; s.pathT -= dt; s.lastSeenAge += dt;
        if (s.reloadT > 0f) { s.reloadT -= dt; if (s.reloadT <= 0f) s.ammo = Soldier.MAG; }

        // восприятие: кого видим и кто ближайший враг (несколько раз в секунду)
        if (s.losT <= 0f || (!s.tgtP && s.tgt != null && s.tgt.dead)) {
            s.losT = 0.2f + rnd.nextFloat() * 0.08f;
            perceive(s);
        }
        boolean has = s.tgtP ? p.alive : (s.tgt != null && !s.tgt.dead);
        float tx = 0f, tz = 0f, dist = 0f, desired = s.yaw;
        if (has) {
            tx = s.tgtP ? p.x : s.tgt.x; tz = s.tgtP ? p.z : s.tgt.z;
            float dx = tx - s.x, dz = tz - s.z;
            dist = (float) Math.sqrt(dx * dx + dz * dz);
            desired = (float) Math.atan2(dx, -dz);
        } else s.los = false;
        boolean los = has && s.los;
        boolean engaged = los && dist < 45f;
        mvx = 0f; mvz = 0f;
        boolean aim = false;

        // решение: пора ли в укрытие
        if (s.state != 3 && engaged) {
            boolean noAmmo = s.ammo <= 0 || s.reloadT > 0f;
            boolean threatened = s.underFire > 0f;
            boolean wantCover = noAmmo || (s.hp < 35f && threatened);
            if (!wantCover && s.stateT <= 0f) {
                wantCover = threatened || s.hp < 55f || s.ammo <= 8 || rnd.nextFloat() < 0.3f;
                if (!wantCover) s.stateT = 2f + rnd.nextFloat() * 2f;
            }
            if (wantCover && s.coverRetryT <= 0f) {
                if (findCover(s, tx, tz, dist)) {
                    s.state = 3;
                    s.coverT = 2f + rnd.nextFloat() * 2.5f + Math.max(0f, s.reloadT) + (s.hp < 35f ? 3f : 0f);
                    s.coverT += (float) Math.hypot(s.coverX - s.x, s.coverZ - s.z) / 3.3f;   // время на дорогу
                    s.hasGoal = false; s.pathT = 0f;
                } else {
                    s.coverRetryT = 1.2f;
                    s.stateT = Math.max(s.stateT, 1f);
                }
            }
        }

        if (s.state == 3) {
            // в укрытии: добежать, перезарядиться, переждать, потом выйти и снова драться
            float cdx = s.coverX - s.x, cdz = s.coverZ - s.z;
            if (cdx * cdx + cdz * cdz > 0.5f) followPath(s, s.coverX, s.coverZ, 3.3f);
            aim = los;
            if (s.coverT <= 0f && s.reloadT <= 0f) {
                s.state = 0; s.stateT = 3f + rnd.nextFloat() * 3f; s.hasGoal = false;
            }
        } else if (engaged) {
            aim = true;
            if (s.team == 0 && distToPlayer(s) > 22f) {
                followSlot(s, 3.0f);                        // не уходить далеко от игрока
            } else if (dist > 20f) {
                followPath(s, tx, tz, 2.0f);                // сближаться, огибая препятствия
            } else {
                if (s.strafeT <= 0f) {
                    s.strafeT = 1f + rnd.nextFloat() * 2f; s.strafeDir = rnd.nextBoolean() ? 1f : -1f;
                    s.pause = rnd.nextFloat() < 0.3f;
                }
                float ux = (tx - s.x) / dist, uz = (tz - s.z) / dist;
                float fw = dist < 7f ? -1.5f : 0f;
                float st = s.pause ? 0f : 1.3f * s.strafeDir;
                mvx = ux * fw - uz * st;
                mvz = uz * fw + ux * st;
            }
        } else if (s.team == 0) {
            // союзник без контакта: держится рядом с игроком, а если враг близко - идёт к нему
            if (has && dist < 30f && distToPlayer(s) < 18f) followPath(s, tx, tz, 2.6f);
            else followSlot(s, 3.0f);
        } else if (has) {
            // враг без контакта: идёт туда, где в последний раз видел цель; потом - с обходом с фланга
            float gx = tx, gz = tz;
            if (s.lastSeenAge < 5f) {
                gx = s.lastSeenX; gz = s.lastSeenZ;
                float ldx = gx - s.x, ldz = gz - s.z;
                if (ldx * ldx + ldz * ldz < 4f) s.lastSeenAge = 99f;
            } else if (dist > 28f && s.flank != 0) {
                float ux = (tx - s.x) / dist, uz = (tz - s.z) / dist;
                float lim = Config.MAP_HALF - 3f;
                gx = Math.max(-lim, Math.min(lim, tx - uz * s.flank * 14f));
                gz = Math.max(-lim, Math.min(lim, tz + ux * s.flank * 14f));
            }
            followPath(s, gx, gz, 2.6f);
        }

        float vx = mvx, vz = mvz;
        float ty;
        if (aim && has) ty = desired;
        else if (vx * vx + vz * vz > 0.05f) ty = (float) Math.atan2(vx, -vz);
        else if (s.lastSeenAge < 10f) ty = (float) Math.atan2(s.lastSeenX - s.x, -(s.lastSeenZ - s.z));
        else if (has) ty = desired;
        else ty = s.yaw;
        s.yaw = turn(s.yaw, ty, 5f * dt);

        if (s.avoidT > 0f) {                                // застрял: шаг в сторону
            float rx = (float) Math.cos(s.yaw), rz = (float) Math.sin(s.yaw);
            vx = rx * s.avoidDir * 2.2f; vz = rz * s.avoidDir * 2.2f;
        }
        float sp = (float) Math.sqrt(vx * vx + vz * vz), ox = s.x, oz = s.z;
        tmp[0] = s.x + vx * dt; tmp[1] = s.z + vz * dt;
        map.resolve(tmp, 0.35f);
        s.x = tmp[0]; s.z = tmp[1];
        float moved = (float) Math.hypot(s.x - ox, s.z - oz);
        if (sp > 0.8f && moved < sp * dt * 0.3f) {
            s.stuckT += dt;
            if (s.stuckT > 0.5f) {
                s.stuckT = 0f; s.avoidT = 1.2f; s.avoidDir = rnd.nextBoolean() ? 1f : -1f;
                s.hasGoal = false; s.pathT = 0f;
            }
        } else s.stuckT = Math.max(0f, s.stuckT - dt);
        s.moving = moved / dt > 0.4f;
        s.walkPhase += moved * 3.2f;

        // прицеливание: чем дольше держит цель в поле зрения, тем точнее
        if (los) s.aimT = Math.min(2f, s.aimT + dt * (s.moving ? 0.5f : 1f));
        else s.aimT = Math.max(0f, s.aimT - dt * 2f);

        if (has && s.los && dist < 35f && s.fireCd <= 0f && s.reactT <= 0f && s.ammo > 0 && s.reloadT <= 0f
                && Math.abs(wrap(desired - s.yaw)) < 0.25f) {
            s.fireCd = 0.14f + rnd.nextFloat() * 0.06f;
            if (++s.burst >= 3 + rnd.nextInt(4)) { s.burst = 0; s.fireCd = 0.8f + rnd.nextFloat(); }
            s.flash = 0.06f;
            if (--s.ammo <= 0) { s.reloadT = 2.3f + rnd.nextFloat() * 0.7f; sfx(SoundBank.RELOAD, 0.35f, 1f); }
            if (dist > 25f) sfx(SoundBank.FAR, 0.4f, 1f);
            else sfx(SoundBank.RIFLE, Math.max(0.1f, 0.8f - dist / 40f), 0.95f + rnd.nextFloat() * 0.1f);
            float chance = Math.max(0.06f, Math.min(0.4f, 0.5f - dist * 0.012f));
            chance *= 0.55f + 0.45f * Math.min(1f, s.aimT / 1.2f);
            if (s.tgtP) chance *= 0.6f;
            if (rnd.nextFloat() < chance) {
                if (s.tgtP) damagePlayer(7f + rnd.nextFloat() * 3f);
                else damage(s.tgt, 12f + rnd.nextFloat() * 6f);
            } else if (!s.tgtP && s.tgt != null) {
                s.tgt.underFire = Math.max(s.tgt.underFire, 1.5f);   // пули рядом: цель прижата
            }
        }
    }

    private float distToPlayer(Soldier s) {
        return (float) Math.hypot(s.x - p.x, s.z - p.z);
    }

    private void insertCand(Soldier o, float d2) {
        int i;
        if (cN < 3) i = cN++;
        else if (d2 < cD[2]) i = 2;
        else return;
        while (i > 0 && cD[i - 1] > d2) { cS[i] = cS[i - 1]; cD[i] = cD[i - 1]; i--; }
        cS[i] = o; cD[i] = d2;
    }

    /** Выбирает цель: из трёх ближайших врагов берёт первого, кого видно; иначе - ближайшего (чтобы идти к нему). */
    private void perceive(Soldier s) {
        cN = 0;
        for (Soldier o : soldiers) {
            if (o.dead || o.team == s.team) continue;
            float dx = o.x - s.x, dz = o.z - s.z;
            insertCand(o, dx * dx + dz * dz);
        }
        if (s.team == 1 && p.alive) {
            float dx = p.x - s.x, dz = p.z - s.z;
            insertCand(null, dx * dx + dz * dz);
        }
        if (cN == 0) { s.tgt = null; s.tgtP = false; s.los = false; return; }
        for (int i = 0; i < cN; i++) {
            boolean isP = cS[i] == null;
            float ex = isP ? p.x : cS[i].x, ez = isP ? p.z : cS[i].z;
            float dx = ex - s.x, dz = ez - s.z, d = (float) Math.sqrt(cD[i]);
            if (d > 70f) continue;
            float inv = 1f / Math.max(d, 0.01f);
            if (map.raycast(s.x, 1.4f, s.z, dx * inv, 0f, dz * inv, d) >= d - 0.3f) {
                boolean same = s.tgtP == isP && s.tgt == cS[i];
                if (!same) s.aimT = Math.min(s.aimT, 0.3f);
                if (!s.los) s.reactT = 0.3f + rnd.nextFloat() * 0.5f;
                s.tgt = cS[i]; s.tgtP = isP; s.los = true;
                s.lastSeenX = ex; s.lastSeenZ = ez; s.lastSeenAge = 0f;
                return;
            }
        }
        s.los = false;
        s.tgt = cS[0]; s.tgtP = cS[0] == null;
    }

    /** Ищет рядом клетку, скрытую от угрозы (стена, дерево, высокий ящик). Ближе, дальше от угрозы и без толкучки - лучше. */
    private boolean findCover(Soldier s, float thx, float thz, float distNow) {
        float bestCost = 1e18f, bx = 0f, bz = 0f;
        boolean found = false;
        for (int ox = -12; ox <= 12; ox += 2) {
            for (int oz = -12; oz <= 12; oz += 2) {
                float cx = s.x + ox, cz = s.z + oz;
                float walkD = (float) Math.sqrt(ox * ox + oz * oz);
                if (walkD > 13f || !nav.isWalk(cx, cz)) continue;
                float dx = cx - thx, dz = cz - thz, d = (float) Math.sqrt(dx * dx + dz * dz);
                if (d < 4f || d > 45f) continue;
                float inv = 1f / d;
                if (map.raycast(thx, 1.4f, thz, dx * inv, 0f, dz * inv, d) >= d - 0.25f) continue;   // не скрыто
                boolean crowded = false;
                for (Soldier o : soldiers) {
                    if (o == s || o.dead) continue;
                    float ax = o.state == 3 ? o.coverX : o.x, az = o.state == 3 ? o.coverZ : o.z;
                    if (Math.abs(ax - cx) < 1.3f && Math.abs(az - cz) < 1.3f) { crowded = true; break; }
                }
                if (crowded) continue;
                float cost = walkD + 0.8f * Math.max(0f, distNow - d) + rnd.nextFloat() * 2f;
                if (cost < bestCost) { bestCost = cost; bx = cx; bz = cz; found = true; }
            }
        }
        if (found) { s.coverX = bx; s.coverZ = bz; }
        return found;
    }

    /** Идёт к точке по пути A*; если путь не построился или лимит кадра исчерпан - напрямую. Результат в mvx/mvz. */
    private void followPath(Soldier s, float gx, float gz, float speed) {
        boolean goalMoved = Math.abs(gx - s.goalX) + Math.abs(gz - s.goalZ) > 6f;
        if (!s.hasGoal || goalMoved || s.pathT <= 0f) {
            if (pathBudget > 0) {
                pathBudget--;
                s.wpN = nav.path(s.x, s.z, gx, gz, s.wpx, s.wpz);
                s.wpI = 0;
                s.goalX = gx; s.goalZ = gz; s.hasGoal = true;
                s.pathT = 1f + rnd.nextFloat() * 0.8f;
            } else if (!s.hasGoal) {
                s.wpN = 0; s.wpI = 0;
            }
        }
        while (s.wpI < s.wpN) {
            float wx = s.wpx[s.wpI] - s.x, wz = s.wpz[s.wpI] - s.z;
            if (wx * wx + wz * wz < 0.5f) s.wpI++; else break;
        }
        float px, pz;
        if (s.wpI < s.wpN) { px = s.wpx[s.wpI]; pz = s.wpz[s.wpI]; } else { px = gx; pz = gz; }
        float dx = px - s.x, dz = pz - s.z, d = (float) Math.sqrt(dx * dx + dz * dz);
        if (d < 1e-4f || (s.wpI >= s.wpN && d < 1f)) return;     // уже на месте
        mvx = dx / d * speed; mvz = dz / d * speed;
    }

    /** Место в строю вокруг игрока (в мировых координатах, чтобы строй не вертелся вместе с камерой). */
    private void followSlot(Soldier s, float speed) {
        float a = s.slot * 1.2566f + 0.6283f, r = 5.5f + (s.slot % 2) * 2f;
        float gx = p.x + (float) Math.cos(a) * r, gz = p.z + (float) Math.sin(a) * r;
        float lim = Config.MAP_HALF - 3f;
        gx = Math.max(-lim, Math.min(lim, gx)); gz = Math.max(-lim, Math.min(lim, gz));
        float dx = gx - s.x, dz = gz - s.z;
        if (dx * dx + dz * dz < 2.25f) return;                    // уже на месте
        followPath(s, gx, gz, speed);
    }
}
