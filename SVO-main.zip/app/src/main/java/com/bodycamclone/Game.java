package com.bodycamclone;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

public class Game {
    public static final class Input {
        public volatile float moveX, moveY;
        public volatile boolean fire;
        public float lookDX, lookDY;
        /** Накопленный поворот гироскопа в радианах (вправо / вниз). Заполняет GyroController. */
        public float gyroDX, gyroDY;
        public volatile boolean ads;
        public volatile boolean crouchToggle, proneToggle;
        /** Нажата кнопка прыжка (сбрасывается в Game.update). */
        public volatile boolean jump;
        /** Кнопка гранат: тип, выбранный свайпом / колесом (0 Ф-1, 1 РГД-5, 2 дымовая), -1 - ничего; короткое нажатие - достать / убрать гранату. Сбрасываются в Game.update. */
        public volatile int grenPick = -1;
        public volatile boolean grenTap;
        /** Нажата кнопка аптечки (сбрасывается в Game.update). */
        public volatile boolean medkit;
        /** Кнопки «выглянуть» удерживаются. */
        public volatile boolean leanL, leanR;
        /** Кнопки приседания / «лечь» удерживаются (режим «удержание»). */
        public volatile boolean crouchHeld, proneHeld;
        public boolean reload, restart, zoom, crouch, prone;
        /** Какое оружие выбрано свайпом / колесом (0 АК, 1 пистолет, 2 нож), -1 - ничего. Сбрасывается в Game.update. */
        public volatile int pick = -1;
        /** Нажата кнопка оружия: осмотреть оружие (сбрасывается в Game.update). */
        public volatile boolean inspect;
    }

    public static final class Player {
        public float x, z, yaw, pitch, hp = 100f;
        public boolean alive = true, moving, crouched, prone;
        public float crouchBlend, proneBlend;
        /** Прыжок: высота ног над землёй, вертикальная скорость, «запас» нажатия кнопки (прыжок сработает при посадке), в воздухе ли. */
        public float jumpY, jumpVy, jumpBuf;
        public boolean air;
        /** Выглядывание из-за угла: на сколько метров голова/камера смещена вправо (минус - влево). */
        public float leanOff;
        public float hurtT, hitT, fireCd, reloadT, flashT, kick, bob, deadT, aimT;
        /** 0..1: насколько оружие убрано, потому что игрок упёрся в стену (рисует GameRenderer.drawViewmodel). */
        public float wallBlend;
        /** zoom: 1 - командир держит бинокль в руках (обычного зума больше нет); binoc - плавный переход 0..1. */
        public int weapon, zoom;
        public float binoc;
        /** Гранаты по типам (Ф-1, РГД-5, дымовая), выбранный тип, граната в руке (вместо оружия) и бросок: сколько секунд осталось, вылетела ли уже граната. */
        public int[] gren = new int[3];
        public int grenSel;
        public boolean grenOut, throwDone;
        public float throwT;
        public int grenTotal() { return gren[0] + gren[1] + gren[2]; }
        /** Аптечки (у медика): сколько осталось и сколько секунд ещё длится лечение. */
        public int medkits;
        public float healT;
        public int[] ammo = new int[3], reserve = new int[3];
        /** Смена оружия: сколько секунд осталось (оружие опускается, меняется на середине, поднимается) и на какое меняем (-1 - не меняем). */
        public float swapT; public int swapTo = -1;
        /** Осмотр оружия: сколько секунд осталось. Удар ножом: сколько секунд осталось, был ли уже нанесён урон. */
        public float inspectT, meleeT; public boolean meleeDone;
        boolean firePrev;
        float stepSign = 1f;
    }

    /** Расстояния до стены (м): оружие начинает убираться на WALL_FAR и убрано полностью на WALL_NEAR. */
    static final float WALL_FAR = 1.1f, WALL_NEAR = 0.6f;
    /** Прыжок: начальная скорость (м/с) и гравитация (м/с^2): высота ~1.1 м - можно перепрыгнуть укрытие до 1 м, время в воздухе ~0.83 с. */
    static final float JUMP_V = 5.4f, GRAV = 13f;
    /** Максимальный вынос головы при выглядывании (м). */
    static final float LEAN_MAX = 0.45f;

    /** Смещение камеры/головы игрока из-за наклона по осям x и z (вправо от направления взгляда). */
    public float leanDX() { return p.leanOff * (float) Math.cos(p.yaw); }
    public float leanDZ() { return p.leanOff * (float) Math.sin(p.yaw); }

    public static final String[] W_NAME = {"АК-74", "ПМ", "Нож"};
    static final float[] W_DMG = {35f, 28f, 55f}, W_CD = {0.10f, 0.30f, 0.60f}, W_RELOAD = {2.2f, 1.6f, 1f}, W_SPREAD = {0.012f, 0.008f, 0f};
    static final int[] W_MAG = {30, 8, 0};
    static final boolean[] W_AUTO = {true, false, false};
    public static final int W_RIFLE = 0, W_PISTOL = 1, W_KNIFE = 2;
    /** Смена оружия (с): первая половина - старое опускается, вторая - новое поднимается. Осмотр: оружие / нож. Удар ножом: длительность, момент попадания, дальность (м). */
    public static final float SWAP_TIME = 0.34f, INSPECT_GUN = 2.6f, INSPECT_KNIFE = 2.4f, MELEE_TIME = 0.42f, MELEE_HIT_AT = 0.16f, MELEE_RANGE = 2.1f;

    /** Гранаты на старте и после возрождения: столько, сколько выбрано в «Снаряжении» (но не больше лимита класса). */
    private void resetGrenades() {
        Settings.clampGrenades();
        for (int k = 0; k < 3; k++) p.gren[k] = Settings.gn[k];
        p.grenSel = 0;
        for (int k = 2; k >= 0; k--) if (p.gren[k] > 0) p.grenSel = k;
        p.grenOut = false; p.throwDone = false;
    }

    private void resetWeaponState() {
        p.swapT = 0f; p.swapTo = -1; p.inspectT = 0f; p.meleeT = 0f; p.meleeDone = true; p.ammo[2] = 0; p.reserve[2] = 0;
    }
    public static float[] W_RELOAD_PUBLIC() { return W_RELOAD; }

    public final Input input = new Input();
    public final Player p = new Player();
    public final List<Soldier> soldiers = new ArrayList<>();
    public static final class BulletMark {
        public float x, y, z, nx, ny, nz, life = 45f;
        BulletMark(float x, float y, float z, float nx, float ny, float nz) { this.x=x; this.y=y; this.z=z; this.nx=nx; this.ny=ny; this.nz=nz; }
    }
    public final List<BulletMark> bulletMarks = new ArrayList<>();
    /** Кровь и осколки (рисует GameRenderer). */
    public final Gore gore = new Gore();
    /** Граната в полёте или лежащая на земле (рисует GameRenderer). */
    public static final class Grenade {
        public float x, y, z, vx, vy, vz, fuse, spin, clinkT;
        public boolean rest;
        /** Config.GREN_F1 / GREN_RGD5 / GREN_SMOKE. */
        public int type;
    }
    /** Облако дымовой гранаты: пока живо, боты за ним никого не видят. puffs - заранее разбросанные «клубы» (x, y, z, размер, поворот), их рисует GameRenderer. */
    public static final class Smoke {
        public float x, z, age, life;
        public float[] puffs;
        /** Радиус облака сейчас: за первые 1.5 с разрастается, за последние 3 с рассеивается. */
        public float radius() {
            float grow = Math.min(1f, age / 1.5f), fade = Math.min(1f, (life - age) / 3f);
            return Config.SMOKE_RADIUS * (float) Math.sqrt(Math.max(0f, grow)) * Math.max(0f, fade);
        }
    }
    public final List<Smoke> smokes = new ArrayList<>();
    /** Взрыв: возраст нужен для огненного шара (рисует GameRenderer). */
    public static final class Blast {
        public float x, y, z, age;
    }
    public final List<Grenade> liveGrenades = new ArrayList<>();
    public final List<Blast> blasts = new ArrayList<>();
    /** Тряска камеры и белая вспышка от близкого взрыва (0..1, сами затухают). */
    public float shake, blastFlash;
    public final WorldMap map;
    private final Nav nav;
    /** Не null - игра по сети (без ботов, возрождение вместо волн). */
    public final Net net;
    /** Строка ленты убийств (мультиплеер). */
    public static final class Feed {
        public final String text; public float life = 6f;
        Feed(String t) { text = t; }
    }
    public final List<Feed> feed = new CopyOnWriteArrayList<>();
    /** Сообщение чата (мультиплеер): scope 0 - всем, 1 - команде; ally - отправитель из моей команды; at - игровое время получения. */
    public static final class ChatMsg {
        public final String name, text; public final int scope; public final boolean ally; public final float at;
        ChatMsg(String name, String text, int scope, boolean ally, float at) { this.name = name; this.text = text; this.scope = scope; this.ally = ally; this.at = at; }
    }
    public final List<ChatMsg> chat = new CopyOnWriteArrayList<>();
    private final Map<Integer, Soldier> remotes = new HashMap<>();
    private float netT, protT;
    private int pathBudget, allySlot;
    private float mvx, mvz;
    private final Soldier[] cS = new Soldier[3];
    private final float[] cD = new float[3];
    private int cN;
    /** За кого играет игрок: Config.SIDE_RU / SIDE_UA. */
    public final int side;
    public volatile boolean paused;
    public SoundBank snd;
    public volatile int kills, wave, enemiesLeft, alliesLeft;
    /** Частота кадров отрисовки (считает GameRenderer) и время кадра в мс. */
    public volatile float fps, frameMs;
    public volatile String status = "";
    public volatile boolean statusError;
    public float time;
    /** Надпись на экране («Точка B захвачена») и сколько ещё её показывать. */
    public String toast = "";
    public float toastT;
    /** Блиндаж с припасами: 0 - игрок не в блиндаже, 1 - идёт пополнение, 2 - всё полное, 3 - блиндаж не наш (захвати точку). */
    public volatile int supplyState;
    private float supplyAcc0, supplyAcc1, supplyAcc2, supplyAcc3;
    private final Random rnd = new Random();
    private final float[] tmp = new float[2];
    private boolean crouchHeldPrev, proneHeldPrev;
    private float lookBufX, lookBufY;   // остаток сглаживания прицела
    private float waveTimer = -1f, ambT = 3f;

    public Game(long mapSeed, int side) { this(mapSeed, side, null); }

    public Game(long mapSeed, int side, Net net) {
        this.map = new WorldMap(mapSeed);
        this.nav = new Nav(map);
        this.side = side;
        this.net = net;
        reset();
    }

    /** Текущее вертикальное поле зрения с учётом прицела и зума. */
    public float curFov() {
        return (float) Math.toDegrees(2.0 * Math.atan(tanHalfFov()));
    }

    private float tanHalfFov() {
        float f = Config.BASE_FOV + (Config.ADS_FOV - Config.BASE_FOV) * p.aimT * (1f - p.binoc);
        return (float) Math.tan(Math.toRadians(f / 2.0)) / (1f + (Config.BINOC_ZOOM - 1f) * p.binoc);
    }

    public void reset() {
        soldiers.clear();
        bulletMarks.clear();
        gore.clear();
        liveGrenades.clear(); blasts.clear(); smokes.clear(); shake = 0f; blastFlash = 0f;
        remotes.clear();
        p.x = map.playerSpawn[0]; p.z = map.playerSpawn[1]; p.yaw = 0f; p.pitch = 0f;
        if (net != null) mpSpawn();
        p.jumpY = 0f; p.jumpVy = 0f; p.jumpBuf = 0f; p.air = false; p.leanOff = 0f;
        p.hp = 100f; p.alive = true; p.deadT = 0f; p.weapon = 0; p.reloadT = 0f; p.fireCd = 0f; resetWeaponState();
        p.ammo[0] = W_MAG[0]; p.ammo[1] = W_MAG[1]; p.reserve[0] = 120 + (Settings.ammoBox ? Config.AMMO_BOX_RIFLE : 0); p.reserve[1] = 40 + (Settings.ammoBox ? Config.AMMO_BOX_PISTOL : 0);
        resetGrenades(); p.throwT = 0f; p.medkits = Config.classMedkits(Settings.cls); p.healT = 0f;
        kills = 0; wave = 0; waveTimer = -1f;
        for (WorldMap.Point pt : map.points) { pt.cap = 0f; pt.owner = -1; }
        toastT = 0f; supplyState = 0; supplyAcc0 = 0f; supplyAcc1 = 0f; supplyAcc2 = 0f; supplyAcc3 = 0f;
        p.zoom = 0; p.binoc = 0f; p.aimT = 0f; p.wallBlend = 0f; input.ads = false; lookBufX = 0f; lookBufY = 0f;
        if (net == null) spawnWave();
    }

    /** Точка появления в мультиплеере: команда 0 - у «своей» базы, команда 1 - напротив. */
    private void mpSpawn() {
        List<float[]> pts = net.myTeam == 0 ? map.allySpawns : map.enemySpawns;
        float[] sp = pts.get(rnd.nextInt(pts.size()));
        tmp[0] = sp[0] + (rnd.nextFloat() - .5f) * 2f; tmp[1] = sp[1] + (rnd.nextFloat() - .5f) * 2f;
        map.resolve(tmp, 0.4f);
        p.x = tmp[0]; p.z = tmp[1];
        p.yaw = net.myTeam == 0 ? 0f : (float) Math.PI;
        p.pitch = 0f;
    }

    /** Возрождение после смерти (мультиплеер): полное здоровье и патроны, 2 секунды неуязвимости. */
    private void respawn() {
        p.hp = 100f; p.alive = true; p.deadT = 0f; p.weapon = 0; p.reloadT = 0f; p.fireCd = 0f; resetWeaponState();
        p.ammo[0] = W_MAG[0]; p.ammo[1] = W_MAG[1]; p.reserve[0] = 120 + (Settings.ammoBox ? Config.AMMO_BOX_RIFLE : 0); p.reserve[1] = 40 + (Settings.ammoBox ? Config.AMMO_BOX_PISTOL : 0);
        resetGrenades(); p.throwT = 0f; p.medkits = Config.classMedkits(Settings.cls); p.healT = 0f;
        p.crouched = false; p.prone = false; p.zoom = 0; p.binoc = 0f; p.aimT = 0f; p.hurtT = 0f;
        p.jumpY = 0f; p.jumpVy = 0f; p.jumpBuf = 0f; p.air = false; p.leanOff = 0f;
        input.leanL = false; input.leanR = false;
        input.ads = false;
        protT = 2f;
        mpSpawn();
    }

    private void place(Soldier s) {
        tmp[0] = s.x; tmp[1] = s.z;
        map.resolve(tmp, 0.4f);
        s.x = tmp[0]; s.z = tmp[1];
        soldiers.add(s);
    }

    private void spawnWave() {
        wave++;
        int mine = 0, theirs = 0;
        for (WorldMap.Point pt : map.points) { if (pt.owner == 0) mine++; else if (pt.owner == 1) theirs++; }
        int n = Math.min(3 + wave * 2 + theirs * 2, 16);      // чем больше точек у противника, тем больше врагов
        for (int i = 0; i < n; i++) {
            float[] sp = map.enemySpawns.get(rnd.nextInt(map.enemySpawns.size()));
            Soldier en = new Soldier(1, sp[0] + (rnd.nextFloat() - .5f), sp[1], (float) Math.PI);
            en.flank = rnd.nextInt(3) - 1;
            en.pathT = rnd.nextFloat();
            en.stateT = 1f + rnd.nextFloat() * 3f;
            place(en);
        }
        int alive = 0;
        for (Soldier s : soldiers) if (s.team == 0 && !s.dead) alive++;
        for (int i = alive; i < Config.ALLIES + mine; i++) {   // каждая наша точка даёт ещё одного союзника
            float[] sp = map.allySpawns.get(rnd.nextInt(map.allySpawns.size()));
            Soldier al = new Soldier(0, sp[0], sp[1], 0f);
            al.slot = allySlot++ % 5;
            al.pathT = rnd.nextFloat();
            place(al);
        }
        if (wave > 1 && p.alive) {
            p.hp = Math.min(100f, p.hp + 35f);      // патроны, гранаты и аптечки между волнами не пополняются - только в блиндажах
        }
    }

    private void sfx(int id, float vol, float rate) { if (snd != null) snd.play(id, vol, rate); }

    public void update(float dt) {
        if (dt <= 0f || (paused && net == null)) return;   // по сети игра идёт и в меню паузы
        float ldx, ldy; boolean reload, restart, zoom, crouch, prone, jump, medkitReq, inspect, grenTap; int pick, grenPick;
        synchronized (input) {
            ldx = input.lookDX; ldy = input.lookDY; input.lookDX = 0; input.lookDY = 0;
            reload = input.reload; pick = input.pick; inspect = input.inspect; restart = input.restart; zoom = input.zoom; crouch = input.crouchToggle; prone = input.proneToggle;
            input.crouchToggle = false; input.proneToggle = false;
            jump = input.jump; input.jump = false;
            grenPick = input.grenPick; grenTap = input.grenTap; input.grenPick = -1; input.grenTap = false;
            medkitReq = input.medkit; input.medkit = false;
            input.reload = false; input.pick = -1; input.inspect = false; input.restart = false; input.zoom = false;
        }
        time += dt;
        for (Iterator<BulletMark> marks = bulletMarks.iterator(); marks.hasNext();) { BulletMark mark = marks.next(); mark.life -= dt; if (mark.life <= 0f) marks.remove(); }
        gore.level = Settings.gfxFx;
        gore.update(dt);
        if (p.alive) updatePlayer(dt, ldx, ldy, reload, pick, grenPick, grenTap, inspect, zoom, crouch, prone, jump);
        else {
            p.deadT += dt;
            if (net != null) { if (p.deadT > 4f) respawn(); }
            else if (restart && p.deadT > 1f) { reset(); return; }
        }

        if (medkitReq && p.alive) useMedkit();
        updateGrenades(dt);
        if (net != null) netUpdate(dt);
        updatePoints(dt);
        updateResupply(dt);
        pathBudget = 2;
        for (Soldier s : soldiers) { if (s.remote && !s.dead) updateRemote(s, dt); else updateSoldier(s, dt); }
        int n = soldiers.size();
        for (int i = 0; i < n; i++) {
            Soldier a = soldiers.get(i);
            if (a.dead) continue;
            for (int j = i + 1; j < n; j++) {
                Soldier b = soldiers.get(j);
                if (b.dead) continue;
                float dx = b.x - a.x, dz = b.z - a.z, d2 = dx * dx + dz * dz;
                if (d2 < 0.49f && d2 > 1e-6f) {
                    float d = (float) Math.sqrt(d2), push = (0.7f - d) * 0.5f;
                    a.x -= dx / d * push; a.z -= dz / d * push; b.x += dx / d * push; b.z += dz / d * push;
                }
            }
        }
        // Игрок и бойцы не проходят друг сквозь друга: расстояние между центрами не меньше 0.7 м.
        // Бота выталкиваем наполовину, игрока наполовину; сетевого игрока нельзя подвинуть - его позицию задаёт его телефон, уступаем мы.
        if (p.alive) {
            for (Soldier s : soldiers) {
                if (s.dead) continue;
                float dx = s.x - p.x, dz = s.z - p.z, d2 = dx * dx + dz * dz;
                if (d2 >= 0.49f) continue;
                float d, nx, nz;
                if (d2 > 1e-6f) { d = (float) Math.sqrt(d2); nx = dx / d; nz = dz / d; }
                else { d = 0f; nx = (float) Math.sin(p.yaw); nz = -(float) Math.cos(p.yaw); }
                float need = 0.7f - d, share = s.remote ? 0f : 0.5f;
                s.x += nx * need * share; s.z += nz * need * share;
                p.x -= nx * need * (1f - share); p.z -= nz * need * (1f - share);
                tmp[0] = p.x; tmp[1] = p.z; map.resolve(tmp, 0.35f); p.x = tmp[0]; p.z = tmp[1];
                if (!s.remote) { tmp[0] = s.x; tmp[1] = s.z; map.resolve(tmp, 0.35f); s.x = tmp[0]; s.z = tmp[1]; }
            }
        }
        Iterator<Soldier> it = soldiers.iterator();
        while (it.hasNext()) { Soldier s = it.next(); if (s.dead && s.deadT > 25f && !s.remote) it.remove(); }
        int e = 0, a = 0;
        for (Soldier s : soldiers) if (!s.dead) { if (s.team == 1) e++; else a++; }
        enemiesLeft = e; alliesLeft = a;
        if (net == null && e == 0 && p.alive) {
            if (waveTimer < 0f) waveTimer = 4f;
            waveTimer -= dt;
            if (waveTimer <= 0f) { waveTimer = -1f; spawnWave(); }
        }
        ambT -= dt;
        if (net == null && ambT <= 0f) { ambT = 2f + rnd.nextFloat() * 5f; sfx(SoundBank.FAR, 0.2f + rnd.nextFloat() * 0.2f, 0.9f + rnd.nextFloat() * 0.2f); }
    }

    private void updatePlayer(float dt, float ldx, float ldy, boolean reload, int pick, int grenPick, boolean grenTap, boolean inspect, boolean zoom, boolean crouch, boolean prone, boolean jump) {
        // Что хотим держать в руках: 0..2 - оружие (АК, пистолет, нож), 3..5 - граната типа (цель - 3). -1 - ничего не меняем.
        int want = -1;
        if (pick >= 0 && pick < 3) want = pick;
        else if (grenPick >= 0 && grenPick < 3 && p.gren[grenPick] > 0) want = 3 + grenPick;
        else if (grenTap) want = p.grenOut ? p.weapon : (p.gren[p.grenSel] > 0 ? 3 + p.grenSel : firstGrenade());
        int cur = p.grenOut ? 3 + p.grenSel : p.weapon, eff = p.swapTo >= 0 ? p.swapTo : cur;
        boolean sw = want >= 0 && want != eff;
        // режим «удержание»: переключаем по фронту нажатия / отпускания кнопки
        if (Settings.proneHold) {
            boolean hld = input.proneHeld;
            if (hld != proneHeldPrev) { proneHeldPrev = hld; if (hld != p.prone) prone = true; }
        } else proneHeldPrev = false;
        if (Settings.crouchHold) {
            boolean hld = input.crouchHeld;
            if (hld != crouchHeldPrev) { crouchHeldPrev = hld; if (hld != p.crouched) crouch = true; }
        } else crouchHeldPrev = false;
        if (prone) { p.prone = !p.prone; if (p.prone) p.crouched = false; }
        if (crouch) { p.crouched = !p.crouched; if (p.crouched) p.prone = false; }
        p.crouchBlend += ((p.crouched ? 1f : 0f) - p.crouchBlend) * Math.min(1f, dt * 8f);
        p.proneBlend += ((p.prone ? 1f : 0f) - p.proneBlend) * Math.min(1f, dt * 7f);
        // бинокль: только у командира; нажатие берёт его в руки / убирает. Выстрел, смена оружия или попадание - бинокль опускается.
        if (zoom && Config.hasBinoculars(Settings.cls) && p.healT <= 0f && p.throwT <= 0f) {
            p.zoom = p.zoom > 0 ? 0 : 1;
            if (p.zoom > 0) { input.ads = false; p.reloadT = 0f; }
        } else if (p.zoom > 0 && (sw || input.fire)) p.zoom = 0;
        p.binoc += ((p.zoom > 0 ? 1f : 0f) - p.binoc) * Math.min(1f, dt * 8f);
        // лечение аптечкой идёт, пока длится анимация
        if (p.healT > 0f) {
            float step = Math.min(dt, p.healT);
            p.hp = Math.min(100f, p.hp + Config.MEDKIT_HEAL * step / Config.MEDKIT_TIME);
            p.healT -= dt;
        }
        float aimTarget = (input.ads && p.wallBlend < 0.5f && p.zoom == 0) ? 1f : 0f;   // у стены прицелиться нельзя
        float aimStep = dt * 7f, aimDiff = aimTarget - p.aimT;
        p.aimT += Math.abs(aimDiff) <= aimStep ? aimDiff : Math.signum(aimDiff) * aimStep;
        // чем сильнее приближение, тем медленнее поворот камеры
        float fovScale = tanHalfFov() / (float) Math.tan(Math.toRadians(Config.BASE_FOV / 2.0));
        // чувствительность плавно переходит от обычной к «с прицелом»
        float sensMul = Settings.sens + (Settings.adsSens - Settings.sens) * p.aimT;
        float sens = Config.LOOK_SENS * sensMul * fovScale;
        // ускорение: чем быстрее свайп, тем сильнее поворот
        if (Settings.accel > 0f) {
            float speed = (float) Math.hypot(ldx, ldy) / dt;               // пикселей в секунду
            float gain = 1f + Settings.accel * Math.min(speed / 2500f, 2f);
            ldx *= gain; ldy *= gain;
        }
        // сглаживание прицела: 1 - выкл, меньше - плавнее (движение не теряется, а растягивается во времени)
        lookBufX += ldx; lookBufY += ldy;
        float k = Settings.smooth >= 0.999f ? 1f : 1f - (float) Math.pow(1f - Settings.smooth, dt * 60f);
        float sdx = lookBufX * k, sdy = lookBufY * k;
        lookBufX -= sdx; lookBufY -= sdy;
        float dy = Settings.invertY ? -sdy : sdy;
        p.yaw += sdx * sens;
        p.pitch = Math.max(-1.35f, Math.min(1.35f, p.pitch - dy * sens));
        // гироскоп
        float gdx, gdy;
        synchronized (input) { gdx = input.gyroDX; gdy = input.gyroDY; input.gyroDX = 0f; input.gyroDY = 0f; }
        if (Settings.gyroMode == Settings.GYRO_ON || (Settings.gyroMode == Settings.GYRO_ADS && input.ads)) {
            float gs = (Settings.gyroSens + (Settings.gyroAdsSens - Settings.gyroSens) * p.aimT) * fovScale;
            gdx *= Settings.gyroInvX ? -gs : gs;
            gdy *= Settings.gyroInvY ? -gs : gs;
            p.yaw += gdx;
            p.pitch = Math.max(-1.35f, Math.min(1.35f, p.pitch - gdy));
        }
        p.hurtT = Math.max(0f, p.hurtT - dt); p.hitT = Math.max(0f, p.hitT - dt);
        p.flashT = Math.max(0f, p.flashT - dt); p.kick = Math.max(0f, p.kick - dt * 7f);
        p.fireCd -= dt;

        // --- вертикаль: прыжок, гравитация, посадка на низкое укрытие ---
        if (jump) p.jumpBuf = 0.12f; else p.jumpBuf = Math.max(0f, p.jumpBuf - dt);   // нажали чуть раньше посадки - прыгнем сразу
        float floor = map.floorAt(p.x, p.z, p.jumpY);
        boolean grounded = p.jumpVy <= 0f && p.jumpY <= floor + 0.001f;
        if (p.jumpBuf > 0f && grounded) {
            p.jumpVy = JUMP_V; p.jumpBuf = 0f; grounded = false;
            p.crouched = false; p.prone = false;                       // прыжок выпрямляет бойца
            sfx(SoundBank.STEP, 0.55f, 0.75f);
        }
        if (grounded) { p.jumpY = floor; p.jumpVy = 0f; }
        else {
            float vPrev = p.jumpVy;
            p.jumpVy -= GRAV * dt;
            p.jumpY += p.jumpVy * dt;
            if (p.jumpVy <= 0f && p.jumpY <= floor) {
                p.jumpY = floor; p.jumpVy = 0f;
                if (vPrev < -2f) sfx(SoundBank.STEP, 0.8f, 0.6f);      // приземление
            }
        }
        p.air = p.jumpY > floor + 0.001f;

        // --- выглядывание: голова выносится вбок, но не дальше стены ---
        float leanWant = (input.leanR ? 1f : 0f) - (input.leanL ? 1f : 0f);      // обе кнопки сразу - без наклона
        float leanTarget = 0f;
        if (leanWant != 0f) {
            float lrx = (float) Math.cos(p.yaw) * leanWant, lrz = (float) Math.sin(p.yaw) * leanWant, ok = 0f;
            for (float o = 0.05f; o <= LEAN_MAX + 1e-3f; o += 0.05f) {
                if (map.blocked(p.x + lrx * o, p.z + lrz * o, 0.14f)) break;
                ok = o;
            }
            leanTarget = leanWant * ok * (p.prone ? 0.5f : 1f);
        }
        p.leanOff += (leanTarget - p.leanOff) * Math.min(1f, dt * 10f);

        float mx = input.moveX, my = input.moveY;
        float mag = Math.min(1f, (float) Math.hypot(mx, my));
        float sy = (float) Math.sin(p.yaw), cy = (float) Math.cos(p.yaw);
        p.moving = mag > 0.1f;
        if (p.moving) {
            float speed = 4.3f * mag * (1f - 0.35f * p.aimT) * (1f - 0.45f * p.binoc) * (p.healT > 0f ? 0.6f : 1f) * (p.prone ? 0.22f : (p.crouched ? 0.52f : 1f));
            float vx = (sy * my + cy * mx) / mag * speed, vz = (-cy * my + sy * mx) / mag * speed;
            tmp[0] = p.x + vx * dt; tmp[1] = p.z + vz * dt;
            map.resolve(tmp, 0.35f, p.jumpY);
            p.x = tmp[0]; p.z = tmp[1];
            if (!p.air) {                                              // в воздухе шагов и покачивания камеры нет
                p.bob += dt * speed * 1.9f;
                float sgn = Math.signum((float) Math.sin(p.bob));
                if (sgn != 0f && sgn != p.stepSign) { p.stepSign = sgn; sfx(SoundBank.STEP, 0.35f, 0.9f + rnd.nextFloat() * 0.2f); }
            }
        }
        // Стена перед лицом: три луча (прямо и под углом), берём ближайшую. Оружие плавно убирается вниз и назад.
        {
            float eyeY = 1.55f - p.crouchBlend * 0.48f - p.proneBlend * 0.92f + p.jumpY;
            float cpw = (float) Math.cos(p.pitch), spw = (float) Math.sin(p.pitch);
            float near = WALL_FAR;
            for (int ri = -1; ri <= 1; ri++) {
                float ang = p.yaw + ri * 0.35f;
                float rx = cpw * (float) Math.sin(ang), rz = -cpw * (float) Math.cos(ang);
                for (WorldMap.Box b : map.boxes) {
                    if (!b.collide) continue;   // только настоящие стены и укрытия (перемычки выше головы не в счёт)
                    float t = WorldMap.rayAabb(p.x + leanDX(), eyeY, p.z + leanDZ(), rx, spw, rz, b.x0, b.y0, b.z0, b.x1, b.y1, b.z1);
                    if (t >= 0f && t < near) near = t;
                }
            }
            float target = Math.max(0f, Math.min(1f, (WALL_FAR - near) / (WALL_FAR - WALL_NEAR)));
            if (p.zoom > 0 || p.healT > 0f) target = 1f;      // на время бинокля и лечения оружие убирается вниз
            p.wallBlend += (target - p.wallBlend) * Math.min(1f, dt * 9f);
        }
        // --- смена оружия: старое опускается, на середине меняется, новое поднимается ---
        if (sw && p.throwT <= 0f && p.healT <= 0f) {
            if (p.swapTo < 0) p.swapT = SWAP_TIME;           // начинаем заново; если уже опускаем - просто меняем цель
            p.swapTo = want;
            p.reloadT = 0f; p.inspectT = 0f; p.meleeT = 0f; p.meleeDone = true;
            sfx(SoundBank.CLINK, 0.35f, 0.7f);
        }
        if (p.swapT > 0f) {
            p.swapT -= dt;
            if (p.swapTo >= 0 && p.swapT <= SWAP_TIME * 0.5f) {
                if (p.swapTo >= 3) { p.grenOut = true; p.grenSel = p.swapTo - 3; }
                else { p.weapon = p.swapTo; p.grenOut = false; }
                p.swapTo = -1; p.fireCd = 0.12f; p.kick = 0.4f;
            }
            if (p.swapT <= 0f) { p.swapT = 0f; p.swapTo = -1; }
        }
        int w = p.weapon;
        boolean swapping = p.swapT > 0f;
        if (p.reloadT > 0f) {
            p.reloadT -= dt;
            if (p.reloadT <= 0f) {
                int take = Math.min(W_MAG[w] - p.ammo[w], p.reserve[w]);
                p.ammo[w] += take; p.reserve[w] -= take;
            }
        } else if (!swapping && !p.grenOut) {
            // кнопка оружия: магазин неполон - перезарядка, полон (или патронов в запасе нет) - осмотр
            if ((reload || inspect) && w != W_KNIFE && p.ammo[w] < W_MAG[w] && p.reserve[w] > 0 && p.zoom == 0 && p.healT <= 0f) { p.inspectT = 0f; inspect = false; startReload(); }
        }
        // --- осмотр оружия: кнопка с оружием. Любое действие (выстрел, перезарядка, смена, бросок, лечение, бинокль) прерывает осмотр ---
        if (inspect && !p.grenOut && !swapping && p.reloadT <= 0f && p.zoom == 0 && p.healT <= 0f && p.throwT <= 0f && p.meleeT <= 0f && p.inspectT <= 0f
                && !input.fire && p.wallBlend < 0.5f) {
            p.inspectT = w == W_KNIFE ? INSPECT_KNIFE : INSPECT_GUN;
            input.ads = false;
            sfx(SoundBank.CLINK, 0.3f, 0.55f);
        }
        if (p.inspectT > 0f) {
            p.inspectT -= dt;
            if (input.fire || input.ads || p.reloadT > 0f || p.zoom > 0 || p.healT > 0f || p.throwT > 0f || swapping || p.wallBlend > 0.5f) p.inspectT = 0f;
            else if (p.inspectT < 0f) p.inspectT = 0f;
        }
        // --- удар ножом ---
        if (p.meleeT > 0f) {
            p.meleeT -= dt;
            if (!p.meleeDone && p.meleeT <= MELEE_TIME - MELEE_HIT_AT) { p.meleeDone = true; playerKnife(); }
            if (p.meleeT < 0f) p.meleeT = 0f;
        }
        boolean fire = input.fire;
        if (p.grenOut) {
            // граната в руке: огонь (кнопка или зона стрельбы) бросает её; после броска возвращается оружие
            if (p.throwT <= 0f && p.throwDone) {
                p.grenOut = false; p.throwDone = false;
                p.swapT = SWAP_TIME * 0.5f; p.swapTo = -1; p.fireCd = 0.15f;      // оружие поднимается из-под низа
            } else if (p.throwT <= 0f && fire && !p.firePrev && !swapping && p.gren[p.grenSel] > 0 && p.healT <= 0f && p.zoom == 0) {
                p.throwT = Config.THROW_TIME; p.throwDone = false; input.ads = false;
                sfx(SoundBank.CLINK, 0.3f, 1.4f);
            }
            if (p.throwT > 0f && !p.throwDone && p.throwT <= Config.THROW_TIME - Config.THROW_RELEASE_AT) { p.throwDone = true; throwGrenade(); }
        } else if (w == W_KNIFE) {
            if (fire && p.fireCd <= 0f && p.meleeT <= 0f && !swapping && p.reloadT <= 0f && p.wallBlend < 0.55f && !p.firePrev) {
                p.fireCd = W_CD[w]; p.meleeT = MELEE_TIME; p.meleeDone = false; p.inspectT = 0f; p.kick = 0.6f;
                sfx(SoundBank.THROW, 0.45f, 1.5f);
            }
        } else {
            boolean can = fire && p.fireCd <= 0f && p.reloadT <= 0f && !swapping && p.wallBlend < 0.55f && (W_AUTO[w] || !p.firePrev);
            if (can) {
                if (p.ammo[w] > 0) { p.ammo[w]--; p.fireCd = W_CD[w]; playerShoot(); }
                else { p.fireCd = 0.3f; sfx(SoundBank.EMPTY, 0.6f, 1f); if (p.reserve[w] > 0) startReload(); }
            }
        }
        p.firePrev = fire;
    }

    /** Удар ножом по взгляду: ближайший живой боец в пределах MELEE_RANGE. Стена ближе - только звон. */
    private void playerKnife() {
        float cp = (float) Math.cos(p.pitch), sp = (float) Math.sin(p.pitch);
        float sy = (float) Math.sin(p.yaw), cy = (float) Math.cos(p.yaw);
        float dx = cp * sy, dy = sp, dz = -cp * cy;
        float ox = p.x + leanDX(), oy = 1.55f + p.jumpY - p.crouchBlend * 0.48f - p.proneBlend * 0.92f, oz = p.z + leanDZ();
        float wallT = map.raycast(ox, oy, oz, dx, dy, dz, MELEE_RANGE);
        Soldier best = null; float bestT = Math.min(wallT, MELEE_RANGE);
        for (Soldier s : soldiers) {
            if (s.dead || (s.team == 0 && !Settings.friendlyFire)) continue;
            float lsx = s.lean * 0.2f * (float) Math.cos(s.yaw), lsz = s.lean * 0.2f * (float) Math.sin(s.yaw);
            // ударная зона чуть шире тела: нож «широкий», целиться по пикселям в ближнем бою неудобно
            float t = WorldMap.rayAabb(ox, oy, oz, dx, dy, dz, s.x + lsx - .50f, s.y, s.z + lsz - .50f, s.x + lsx + .50f, s.y + 1.85f, s.z + lsz + .50f);
            if (t >= 0f && t < bestT) { bestT = t; best = s; }
        }
        if (best != null) {
            p.hitT = 0.18f;
            best.hitDx = dx; best.hitDz = dz; best.hitAt = time;
            float hx = ox + dx * bestT, hy = oy + dy * bestT, hz = oz + dz * bestT;
            gore.spray(hx, hy, hz, dx, dy, dz, 8);
            sfx(SoundBank.HIT, 0.9f, 0.7f);
            if (best.remote) { net.sendHit(best.netId, W_DMG[W_KNIFE]); best.hitFlash = 0.15f; }
            else if (damage(best, W_DMG[W_KNIFE])) kills++;
        } else if (wallT < MELEE_RANGE) {
            sfx(SoundBank.CLINK, 0.7f, 0.8f);
        }
    }

    /** Аптечка (только у медика): лечит на месте, пока идёт анимация; тратится одна штука. Пополняется только в блиндаже. */
    private void useMedkit() {
        if (p.medkits <= 0 || p.healT > 0f || p.throwT > 0f || p.hp >= 100f) return;
        p.medkits--;
        p.healT = Config.MEDKIT_TIME;
        p.zoom = 0; input.ads = false; p.reloadT = 0f;
        sfx(SoundBank.EMPTY, 0.5f, 0.6f);
    }

    // ------------------------------------------------------------------ гранаты

    /** Первый тип гранат, который у игрока ещё есть: 3 + тип (как цель смены оружия), -1 - гранат нет. */
    private int firstGrenade() {
        for (int k = 0; k < Config.GREN_TYPES; k++) if (p.gren[k] > 0) return 3 + k;
        return -1;
    }

    /** Бросок гранаты выбранного типа по взгляду, чуть вверх (дугой). */
    private void throwGrenade() {
        int type = p.grenSel;
        if (p.gren[type] <= 0) return;
        p.zoom = 0;
        p.gren[type]--;
        p.kick = 1f;
        float cp = (float) Math.cos(p.pitch), sp = (float) Math.sin(p.pitch);
        float sy = (float) Math.sin(p.yaw), cy = (float) Math.cos(p.yaw);
        float ox = p.x + leanDX(), oz = p.z + leanDZ();
        float oy = 1.55f - p.crouchBlend * 0.48f - p.proneBlend * 0.92f + p.jumpY;
        float dx = cp * sy, dy = sp + 0.2f, dz = -cp * cy;
        float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= l; dy /= l; dz /= l;
        float t = map.raycast(ox, oy, oz, dx, dy, dz, 0.6f);          // граната не должна появиться внутри стены
        float off = Math.max(0.05f, Math.min(0.5f, t - 0.12f));
        Grenade g = new Grenade();
        g.x = ox + dx * off; g.y = Math.max(0.08f, oy + dy * off - 0.1f); g.z = oz + dz * off;
        float speed = Config.GRENADE_SPEED * (p.prone ? 0.6f : 1f);
        g.vx = dx * speed; g.vy = dy * speed; g.vz = dz * speed;
        g.type = type; g.fuse = Config.GREN_FUSE[type];
        g.spin = rnd.nextFloat() * 6f;
        liveGrenades.add(g);
        sfx(SoundBank.THROW, 0.8f, 0.95f + rnd.nextFloat() * 0.1f);
    }

    private void updateGrenades(float dt) {
        p.throwT = Math.max(0f, p.throwT - dt);
        for (int i = smokes.size() - 1; i >= 0; i--) {
            Smoke sm = smokes.get(i);
            sm.age += dt;
            if (sm.age >= sm.life) smokes.remove(i);
        }
        shake = Math.max(0f, shake - dt * 2.2f);
        blastFlash = Math.max(0f, blastFlash - dt * 2.5f);
        for (int i = blasts.size() - 1; i >= 0; i--) {
            Blast b = blasts.get(i);
            b.age += dt;
            if (b.age > 1.2f) blasts.remove(i);
        }
        for (int i = liveGrenades.size() - 1; i >= 0; i--) {
            Grenade g = liveGrenades.get(i);
            g.fuse -= dt; g.clinkT -= dt;
            if (!g.rest) {
                g.spin += dt * 14f;
                int steps = Math.max(1, (int) Math.ceil(dt / 0.012f));
                float h = dt / steps;
                for (int k = 0; k < steps && !g.rest; k++) stepGrenade(g, h);
            }
            if (g.fuse <= 0f) { liveGrenades.remove(i); explode(g); }
        }
    }

    /** Точка внутри любого стоящего на пути объекта (с запасом на радиус гранаты). Земля - отдельно, y = 0. */
    private boolean grenadeInSolid(float x, float y, float z) {
        final float r = 0.06f;
        for (WorldMap.Box b : map.boxes) {
            if (!b.block) continue;
            if (x > b.x0 - r && x < b.x1 + r && y > b.y0 - r && y < b.y1 + r && z > b.z0 - r && z < b.z1 + r) return true;
        }
        return false;
    }

    private void clink(Grenade g, float v) {
        if (Math.abs(v) > 2.5f && g.clinkT <= 0f) {
            g.clinkT = 0.15f;
            sfx(SoundBank.CLINK, Math.min(0.7f, Math.abs(v) / 12f), 0.9f + rnd.nextFloat() * 0.3f);
        }
    }

    /** Один шаг физики: гравитация, отскок от стен, ящиков и земли, трение; когда почти остановилась - лежит до взрыва. */
    private void stepGrenade(Grenade g, float h) {
        g.vy -= 9.8f * h;
        boolean landed = false;
        float nx = g.x + g.vx * h;
        if (grenadeInSolid(nx, g.y, g.z)) { clink(g, g.vx); g.vx = -g.vx * 0.45f; g.vz *= 0.85f; } else g.x = nx;
        float nz = g.z + g.vz * h;
        if (grenadeInSolid(g.x, g.y, nz)) { clink(g, g.vz); g.vz = -g.vz * 0.45f; g.vx *= 0.85f; } else g.z = nz;
        float ny = g.y + g.vy * h;
        if (ny <= 0.06f) {
            if (g.vy < 0f) clink(g, g.vy);
            ny = 0.06f; g.vy = -g.vy * 0.35f; landed = true;
        } else if (grenadeInSolid(g.x, ny, g.z)) {
            clink(g, g.vy);
            if (g.vy < 0f) landed = true;
            g.vy = -g.vy * 0.3f; ny = g.y;
        }
        g.y = ny;
        if (landed) {
            float f = (float) Math.pow(0.04, h);                  // трение о землю
            g.vx *= f; g.vz *= f;
            if (Math.abs(g.vy) < 0.7f) g.vy = 0f;
        }
        float lim = map.half - 0.3f;
        g.x = Math.max(-lim, Math.min(lim, g.x)); g.z = Math.max(-lim, Math.min(lim, g.z));
        if (landed && g.vy == 0f && g.vx * g.vx + g.vz * g.vz < 0.09f) { g.rest = true; g.vx = 0f; g.vz = 0f; }
    }

    /** Урон от взрыва по цели на расстоянии d: убывает к краю радиуса; стена между гранатой и целью гасит осколки. */
    private float blastDamage(float gx, float gy, float gz, float d, float dx, float dy, float dz, int type) {
        float dmg = Config.GREN_DMG[type] * (1f - d / Config.GREN_RADIUS[type]);
        if (d > 0.5f) {
            float t = map.raycast(gx, gy + 0.1f, gz, dx / d, dy / d, dz / d, d);
            if (t < d - 0.35f) return 0f;
        }
        return dmg < 4f ? 0f : dmg;
    }

    /** Закрывает ли дым линию между двумя точками на земле (боты не видят сквозь облако). */
    private boolean smokeBlocks(float ax, float az, float bx, float bz) {
        for (Smoke sm : smokes) {
            float r = sm.radius() * 0.85f;
            if (r < 0.8f) continue;
            float dx = bx - ax, dz = bz - az, l2 = dx * dx + dz * dz;
            float t = l2 < 1e-4f ? 0f : Math.max(0f, Math.min(1f, ((sm.x - ax) * dx + (sm.z - az) * dz) / l2));
            float cx = ax + dx * t - sm.x, cz = az + dz * t - sm.z;
            if (cx * cx + cz * cz < r * r) return true;
        }
        return false;
    }

    /** Дымовая: облако на месте, шипение; боты за ним слепнут. */
    private void smokeBurst(Grenade g) {
        Smoke sm = new Smoke();
        sm.x = g.x; sm.z = g.z; sm.age = 0f; sm.life = Config.SMOKE_TIME;
        int n = Settings.gfxFx == 0 ? 22 : (Settings.gfxFx == 1 ? 30 : 38);
        sm.puffs = new float[n * 5];
        for (int i = 0; i < n; i++) {
            float a = rnd.nextFloat() * 6.2832f, rr = (float) Math.sqrt(rnd.nextFloat());
            float hr = 1f - 0.45f * (float) Math.pow(rnd.nextFloat(), 0.5f);          // купол: выше - уже
            sm.puffs[i * 5] = (float) Math.cos(a) * rr * hr;
            sm.puffs[i * 5 + 1] = 0.25f + rnd.nextFloat() * 0.75f * hr;
            sm.puffs[i * 5 + 2] = (float) Math.sin(a) * rr * hr;
            sm.puffs[i * 5 + 3] = 1.7f + rnd.nextFloat() * 1.1f;
            sm.puffs[i * 5 + 4] = rnd.nextFloat() * 360f;
        }
        smokes.add(sm);
        sfx(SoundBank.SMOKE, 0.8f, 0.95f + rnd.nextFloat() * 0.1f);
    }

    private void explode(Grenade g) {
        if (g.type == Config.GREN_SMOKE) { smokeBurst(g); return; }
        final float R = Config.GREN_RADIUS[g.type];
        float by = Math.max(0.2f, g.y);
        Blast bl = new Blast();
        bl.x = g.x; bl.y = by; bl.z = g.z;
        blasts.add(bl);
        gore.blast(g.x, by, g.z);
        float pdx = p.x - g.x, pdz = p.z - g.z;
        float dp = (float) Math.sqrt(pdx * pdx + pdz * pdz);
        sfx(SoundBank.EXPLODE, Math.max(0.25f, 1f - dp / 70f), 0.92f + rnd.nextFloat() * 0.16f);
        if (dp < 30f) shake = Math.max(shake, 1f - dp / 30f);
        if (dp < 10f) blastFlash = Math.max(blastFlash, 1f - dp / 10f);
        for (Soldier s : soldiers) {
            if (s.dead) continue;
            float chestY = s.y + 1.0f;
            float dx = s.x - g.x, dy = chestY - by, dz = s.z - g.z;
            float d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (!s.remote && d < 14f) s.underFire = Math.max(s.underFire, 2.5f);   // взрыв рядом - бойцы уходят в укрытие
            if (d > R) continue;
            if (s.team == 0 && !Settings.friendlyFire) continue;
            float dmg = blastDamage(g.x, by, g.z, d, dx, dy, dz, g.type);
            if (dmg <= 0f) continue;
            float hl = (float) Math.sqrt(dx * dx + dz * dz);
            float hx = hl > 1e-3f ? dx / hl : 0f, hz = hl > 1e-3f ? dz / hl : 1f;
            s.hitDx = hx; s.hitDz = hz; s.hitAt = time;                  // для выбора анимации смерти
            gore.spray(s.x, chestY, s.z, hx, 0.5f, hz, 8);
            if (s.remote) { net.sendHit(s.netId, dmg); s.hitFlash = 0.15f; }
            else if (damage(s, dmg) && s.team == 1) kills++;
        }
        if (p.alive && !(net != null && protT > 0f)) {
            float chestY = 1.2f - p.crouchBlend * 0.4f - p.proneBlend * 0.8f + p.jumpY;
            float dx = p.x - g.x, dy = chestY - by, dz = p.z - g.z;
            float d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (d <= R) {
                float dmg = blastDamage(g.x, by, g.z, d, dx, dy, dz, g.type);
                if (dmg > 0f) damagePlayer(dmg * 0.7f);
            }
        }
    }

    private void startReload() { p.reloadT = W_RELOAD[p.weapon]; sfx(SoundBank.RELOAD, 0.7f, 1f); }

    private void playerShoot() {
        int w = p.weapon;
        if (net != null) net.sendFire();
        sfx(w == 0 ? SoundBank.RIFLE : SoundBank.PISTOL, 1f, 0.97f + rnd.nextFloat() * 0.06f);
        p.flashT = 0.05f; p.kick = 1f;
        p.pitch += 0.012f; p.yaw += (rnd.nextFloat() - .5f) * 0.004f;
        float cp = (float) Math.cos(p.pitch), sp = (float) Math.sin(p.pitch);
        float sy = (float) Math.sin(p.yaw), cy = (float) Math.cos(p.yaw);
        float spr = W_SPREAD[w] * (p.moving ? 1.8f : 1f) * (1f - 0.5f * p.aimT);
        float rx = (rnd.nextFloat() - .5f) * 2f * spr, ry = (rnd.nextFloat() - .5f) * 2f * spr;
        float dx = cp * sy + cy * rx - sp * sy * ry;
        float dy = sp + cp * ry;
        float dz = -cp * cy + sy * rx + sp * cy * ry;
        float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= l; dy /= l; dz /= l;
        float ox = p.x + leanDX(), oy = 1.55f + p.jumpY, oz = p.z + leanDZ();
        float bestT = map.raycast(ox, oy, oz, dx, dy, dz, 150f);
        Soldier best = null; boolean head = false;
        for (Soldier s : soldiers) {
            if (s.dead || (s.team == 0 && !Settings.friendlyFire)) continue;
            float lsx = s.lean * 0.2f * (float) Math.cos(s.yaw), lsz = s.lean * 0.2f * (float) Math.sin(s.yaw);   // наклон сдвигает бойца вбок
            float t = WorldMap.rayAabb(ox, oy, oz, dx, dy, dz, s.x + lsx - .32f, s.y, s.z + lsz - .32f, s.x + lsx + .32f, s.y + 1.85f, s.z + lsz + .32f);
            if (t >= 0f && t < bestT) { bestT = t; best = s; head = (oy + dy * t) > 1.5f + s.y; }
        }
        // Трупы: по ним тоже можно стрелять (голова и тело по скелету), если пуля долетает раньше стены и живых
        Soldier cBest = null; boolean cHead = false; float cT = bestT;
        for (Soldier s : soldiers) {
            if (!s.dead || !s.bodyKnown) continue;
            float th = raySphere(ox, oy, oz, dx, dy, dz, s.headWX, s.headWY, s.headWZ, 0.15f);
            float tb = -1f;
            float bx = s.hipWX - s.headWX, by = s.hipWY - s.headWY, bz = s.hipWZ - s.headWZ;
            for (int k = 1; k <= 7; k++) {                       // от головы вдоль туловища и дальше вдоль ног
                float u = k * 0.17f;
                float t = raySphere(ox, oy, oz, dx, dy, dz, s.headWX + bx * u, s.headWY + by * u, s.headWZ + bz * u, k <= 3 ? 0.25f : 0.16f);
                if (t >= 0f && (tb < 0f || t < tb)) tb = t;
            }
            float t = th >= 0f && (tb < 0f || th <= tb + 0.2f) ? th : tb;
            if (t >= 0f && t < cT) { cT = t; cBest = s; cHead = t == th; }
        }
        if (cBest != null) {
            corpseHit(cBest, cHead, ox + dx * cT, oy + dy * cT, oz + dz * cT, dx, dy, dz);
        } else if (best != null) {
            p.hitT = 0.18f;
            best.hitDx = dx; best.hitDz = dz; best.hitAt = time;     // для выбора анимации смерти
            sfx(SoundBank.TICK, 0.7f, head ? 1.4f : 1f);
            gore.spray(ox + dx * bestT, oy + dy * bestT, oz + dz * bestT, dx, dy, dz, head ? 10 : 6);
            if (best.remote) { net.sendHit(best.netId, head ? W_DMG[w] * 3f : W_DMG[w]); best.hitFlash = 0.15f; if (head) best.headHitT = time; }
            else if (damage(best, head ? W_DMG[w] * 3f : W_DMG[w])) {
                kills++;
                if (head) blowHead(best, dx, dy, dz);
            }
        } else if (bestT < 149.9f) {
            addBulletMark(ox, oy, oz, dx, dy, dz, bestT);
        }
    }

    private static float raySphere(float ox, float oy, float oz, float dx, float dy, float dz, float cx, float cy, float cz, float r) {
        float lx = cx - ox, ly = cy - oy, lz = cz - oz;
        float tc = lx * dx + ly * dy + lz * dz;
        if (tc < 0f) return -1f;
        float d2 = lx * lx + ly * ly + lz * lz - tc * tc;
        if (d2 > r * r) return -1f;
        return tc - (float) Math.sqrt(r * r - d2);
    }

    /** Пуля попала в труп: кровь и куски мяса, рана на теле; четвёртое попадание в лицо разносит голову. */
    private void corpseHit(Soldier s, boolean head, float hx, float hy, float hz, float dx, float dy, float dz) {
        s.corpseHits++;
        s.bloodFade = 1f;
        if (s.deadT > 20f) s.deadT = 20f;                        // труп не пропадает, пока по нему стреляют
        sfx(SoundBank.HIT, 0.55f, head ? 0.75f : 0.65f + rnd.nextFloat() * 0.1f);
        gore.spray(hx, hy, hz, dx, dy, dz, head ? 10 : 6);
        gore.meat(hx, hy, hz, dx, dy, dz, head ? 4 : 2);
        if (s.woundQ.size() < 40) s.woundQ.add(new float[]{hx, hy, hz, head ? 1f : 0f, rnd.nextFloat()});
        if (head) {
            s.faceHits++;
            if (s.faceHits >= 4 && !s.headGone) {
                s.headGone = true; s.spurtT = 0f; s.spurtUntil = time + 2.5f;
                gore.headBurst(s.headWX, s.headWY, s.headWZ, dx, dy, dz);
            }
        } else if (s.corpseHits % 5 == 0) {
            gore.meat(hx, hy, hz, dx, dy, dz, 6);                // тело раздирает
        }
    }

    /** Выстрел в голову убил бойца: голова разлетается, на её месте остаётся обрубок шеи. */
    private void blowHead(Soldier s, float dx, float dy, float dz) {
        if (s.headGone) return;
        s.headGone = true; s.spurtT = 0f;
        gore.headBurst(s.x, 1.62f, s.z, dx, dy, dz);
    }

    private void addBulletMark(float ox, float oy, float oz, float dx, float dy, float dz, float t) {
        float x = ox + dx * t, y = oy + dy * t, z = oz + dz * t;
        float nx = 0f, ny = 1f, nz = 0f, closest = Float.MAX_VALUE;
        for (WorldMap.Box b : map.boxes) {
            if (!b.block) continue;
            float hit = WorldMap.rayAabb(ox, oy, oz, dx, dy, dz, b.x0, b.y0, b.z0, b.x1, b.y1, b.z1);
            if (hit < 0f || Math.abs(hit - t) > 0.025f) continue;
            float[] ds = {Math.abs(x-b.x0), Math.abs(x-b.x1), Math.abs(y-b.y0), Math.abs(y-b.y1), Math.abs(z-b.z0), Math.abs(z-b.z1)};
            for (int i=0;i<6;i++) if (ds[i] < closest) { closest=ds[i]; nx=(i==0?-1:i==1?1:0); ny=(i==2?-1:i==3?1:0); nz=(i==4?-1:i==5?1:0); }
        }
        bulletMarks.add(new BulletMark(x + nx*.008f, y + ny*.008f, z + nz*.008f, nx, ny, nz));
        int markCap = new int[]{30, 70, 120}[Math.max(0, Math.min(2, Settings.gfxFx))];
        while (bulletMarks.size() > markCap) bulletMarks.remove(0);
    }

    /** true, если боец убит этим попаданием */
    private boolean damage(Soldier s, float d) {
        if (s.dead) return false;
        s.hp -= d; s.hitFlash = 0.15f; s.underFire = Math.max(s.underFire, 2.5f);
        sfx(SoundBank.HIT, 0.5f, 0.9f + rnd.nextFloat() * 0.3f);
        if (s.hp <= 0f) {
            s.dead = true; s.deadT = 0f;
            // Arcade-style physics fall: a sideways impulse, gravity and ground damping.
            s.fallY = 0f; s.fallVy = 1.4f;
            s.fallAngle = 0f;
            s.fallAngularVelocity = (rnd.nextBoolean() ? 1f : -1f) * (4.0f + rnd.nextFloat() * 2.0f);
            s.bloodFade = 1f;
            sfx(SoundBank.DEATH, 0.5f, 0.9f + rnd.nextFloat() * 0.2f);
            return true;
        }
        return false;
    }

    private void damagePlayer(float d) {
        if (!p.alive) return;
        p.hp -= d; p.hurtT = 0.4f; p.zoom = 0;
        sfx(SoundBank.HURT, 0.8f, 1f);
        if (p.hp <= 0f) { p.hp = 0f; p.alive = false; p.deadT = 0f; input.leanL = false; input.leanR = false; sfx(SoundBank.DEATH, 0.8f, 0.8f); }
    }


    // ------------------------------------------------------------------ мультиплеер

    private static float pf(String s) { try { return Float.parseFloat(s); } catch (Exception e) { return 0f; } }
    private static int pi(String s) { try { return Integer.parseInt(s); } catch (Exception e) { return -1; } }

    private String nameOf(int id) {
        Net.PInfo pl = net.roster.get(id);
        return pl != null ? pl.name : "?";
    }

    /** Разбирает входящие сообщения, шлёт своё состояние 15 раз в секунду. */
    private void netUpdate(float dt) {
        if (net.closed) return;
        String[] m;
        while ((m = net.inbox.poll()) != null) handleNet(m);
        Net.PInfo me = net.roster.get(net.myId);
        if (me != null) kills = me.kills;
        protT = Math.max(0f, protT - dt);
        for (Feed f : feed) { f.life -= dt; if (f.life <= 0f) feed.remove(f); }
        netT -= dt;
        if (netT <= 0f) {
            netT = 1f / 15f;
            int fl = (p.moving ? 1 : 0) | (p.alive ? 2 : 0) | (p.crouched ? 4 : 0) | (p.prone ? 8 : 0)
                    | (Math.max(0, Math.min(31, Math.round(p.jumpY * 20f))) << 4)      // высота прыжка в 5 сантиметрах
                    | ((Math.max(-3, Math.min(3, Math.round(p.leanOff / LEAN_MAX * 3f))) + 4) << 9);   // наклон: 1..7, 4 - прямо
            net.sendState(p.x, p.z, p.yaw, fl);
        }
    }

    private Soldier remoteFor(int id) {
        if (id == net.myId) return null;
        Soldier s = remotes.get(id);
        if (s != null) return s;
        Net.PInfo pl = net.roster.get(id);
        if (pl == null) return null;
        s = new Soldier(pl.team == net.myTeam ? 0 : 1, 0f, 0f, 0f);
        s.remote = true; s.netId = id;
        remotes.put(id, s);
        soldiers.add(s);
        return s;
    }

    private void handleNet(String[] m) {
        try {
            switch (m[0]) {
                case "S": {
                    Soldier s = remoteFor(pi(m[1]));
                    if (s == null) break;
                    float x = pf(m[2]), z = pf(m[3]), yaw = pf(m[4]);
                    int fl = pi(m[5]);
                    boolean alive = (fl & 2) != 0;
                    s.tx = x; s.tz = z; s.tyaw = yaw; s.netMoving = (fl & 1) != 0;
                    s.crouch = (fl & 4) != 0; s.prone = (fl & 8) != 0;
                    s.ty = ((fl >> 4) & 31) / 20f;
                    int lv = (fl >> 9) & 7;
                    s.tlean = lv == 0 ? 0f : (lv - 4) / 3f;
                    if (!s.seen) { s.seen = true; s.x = x; s.z = z; s.yaw = yaw; }
                    if (s.dead && alive) {                         // возродился
                        s.dead = false; s.hp = 100f; s.deadT = 0f;
                        s.headGone = false; s.headHitT = -99f; s.clearCorpse();
                        s.fallY = 0f; s.fallVy = 0f; s.fallAngle = 0f; s.fallAngularVelocity = 0f; s.bloodFade = 1f;
                        s.x = x; s.z = z; s.yaw = yaw; s.y = s.ty;
                    }
                    break;
                }
                case "F": {
                    Soldier s = remoteFor(pi(m[1]));
                    if (s == null || s.dead) break;
                    s.flash = 0.06f;
                    float dist = (float) Math.hypot(s.x - p.x, s.z - p.z);
                    if (dist > 25f) sfx(SoundBank.FAR, 0.4f, 1f);
                    else sfx(SoundBank.RIFLE, Math.max(0.1f, 0.8f - dist / 40f), 0.95f + rnd.nextFloat() * 0.1f);
                    break;
                }
                case "H":
                    if (pi(m[2]) == net.myId) netHit(pi(m[1]), pf(m[3]));
                    break;
                case "K": {
                    int killer = pi(m[1]), victim = pi(m[2]);
                    Soldier v = remotes.get(victim);
                    if (v != null && !v.dead) markDead(v);
                    feed.add(new Feed(killer == victim ? nameOf(victim) + " погиб" : nameOf(killer) + " убил " + nameOf(victim)));
                    while (feed.size() > 5) feed.remove(0);
                    break;
                }
                case "C": {
                    if (m.length < 4) break;
                    int from = pi(m[1]);
                    Net.PInfo sp = net.roster.get(from);
                    chat.add(new ChatMsg(sp != null ? sp.name : "?", m[3], pi(m[2]) == 1 ? 1 : 0, sp == null || sp.team == net.myTeam, time));
                    while (chat.size() > 100) chat.remove(0);
                    break;
                }
                case "BYE": {
                    Soldier s = remotes.remove(pi(m[1]));
                    if (s != null) soldiers.remove(s);
                    break;
                }
                default: break;
            }
        } catch (RuntimeException ignored) {
            // битое сообщение - пропускаем
        }
    }

    /** По мне попал игрок shooter. Если это смерть - сообщаем хосту, он засчитает убийство. */
    private void netHit(int shooter, float dmg) {
        if (!p.alive || protT > 0f) return;
        damagePlayer(dmg);
        if (!p.alive) net.sendKill(shooter);
    }

    private void markDead(Soldier s) {
        if (time - s.headHitT < 0.7f) blowHead(s, s.x - p.x, 0f, s.z - p.z);   // мой выстрел в голову сетевому бойцу
        if (time - s.hitAt > 1f) { s.hitDx = 0f; s.hitDz = 0f; }               // убил не я - направление неизвестно
        s.dead = true; s.deadT = 0f; s.hp = 0f; s.y = 0f; s.ty = 0f; s.lean = 0f; s.tlean = 0f;
        s.fallY = 0f; s.fallVy = 1.4f; s.fallAngle = 0f;
        s.fallAngularVelocity = (rnd.nextBoolean() ? 1f : -1f) * (4.0f + rnd.nextFloat() * 2.0f);
        s.bloodFade = 1f;
        sfx(SoundBank.DEATH, 0.5f, 0.9f + rnd.nextFloat() * 0.2f);
    }

    /** Плавно подтягивает сетевого игрока к последней присланной позиции. */
    private void updateRemote(Soldier s, float dt) {
        s.fireCd -= dt; s.flash -= dt; s.hitFlash -= dt;
        float ox = s.x, oz = s.z;
        if (Math.hypot(s.tx - s.x, s.tz - s.z) > 8f) { s.x = s.tx; s.z = s.tz; }
        float k = Math.min(1f, dt * 14f);
        s.x += (s.tx - s.x) * k; s.z += (s.tz - s.z) * k;
        s.y += (s.ty - s.y) * k;
        s.lean += (s.tlean - s.lean) * k;
        s.yaw += wrap(s.tyaw - s.yaw) * k;
        float moved = (float) Math.hypot(s.x - ox, s.z - oz);
        s.moving = moved / dt > 0.5f;
        s.walkPhase += moved * 3.2f;
    }

    private static float wrap(float a) {
        while (a > Math.PI) a -= 2 * Math.PI;
        while (a < -Math.PI) a += 2 * Math.PI;
        return a;
    }

    private static float turn(float a, float target, float step) {
        float d = wrap(target - a);
        return Math.abs(d) <= step ? target : a + Math.signum(d) * step;
    }

    private void updateSoldier(Soldier s, float dt) {
        if (s.dead) {
            s.deadT += dt;
            s.fallVy -= 9.8f * dt;
            s.fallY += s.fallVy * dt;
            if (s.fallY < 0f) { s.fallY = 0f; s.fallVy = 0f; }
            s.fallAngle += s.fallAngularVelocity * dt;
            s.fallAngularVelocity *= (float)Math.pow(0.08f, dt);
            s.bloodFade = Math.max(0f, 1f - s.deadT / 25f);
            return;
        }
        s.fireCd -= dt; s.flash -= dt; s.hitFlash -= dt; s.strafeT -= dt;
        s.reactT -= dt; s.avoidT -= dt; s.losT -= dt; s.stateT -= dt; s.underFire -= dt;
        s.coverT -= dt; s.coverRetryT -= dt; s.pathT -= dt; s.lastSeenAge += dt; s.objT -= dt;
        if (s.reloadT > 0f) { s.reloadT -= dt; if (s.reloadT <= 0f) s.ammo = Soldier.MAG; }

        // восприятие: кого видим и кто ближайший враг (несколько раз в секунду)
        if (s.losT <= 0f || (!s.tgtP && s.tgt != null && s.tgt.dead)) {
            s.losT = 0.2f + rnd.nextFloat() * 0.08f;
            perceive(s);
        }
        boolean has = s.tgtP ? p.alive : (s.tgt != null && !s.tgt.dead);
        float tx = 0f, tz = 0f, dist = 0f, desired = s.yaw;
        if (has) {
            tx = s.tgtP ? p.x : s.tgt.x; tz = s.tgtP ? p.z : s.tgt.z;
            float dx = tx - s.x, dz = tz - s.z;
            dist = (float) Math.sqrt(dx * dx + dz * dz);
            desired = (float) Math.atan2(dx, -dz);
        } else s.los = false;
        boolean los = has && s.los;
        boolean engaged = los && dist < 45f;
        mvx = 0f; mvz = 0f;
        boolean aim = false;

        // решение: пора ли в укрытие
        if (s.state != 3 && engaged) {
            boolean noAmmo = s.ammo <= 0 || s.reloadT > 0f;
            boolean threatened = s.underFire > 0f;
            boolean wantCover = noAmmo || (s.hp < 35f && threatened);
            if (!wantCover && s.stateT <= 0f) {
                wantCover = threatened || s.hp < 55f || s.ammo <= 8 || rnd.nextFloat() < 0.3f;
                if (!wantCover) s.stateT = 2f + rnd.nextFloat() * 2f;
            }
            if (wantCover && s.coverRetryT <= 0f) {
                if (findCover(s, tx, tz, dist)) {
                    s.state = 3;
                    s.coverT = 2f + rnd.nextFloat() * 2.5f + Math.max(0f, s.reloadT) + (s.hp < 35f ? 3f : 0f);
                    s.coverT += (float) Math.hypot(s.coverX - s.x, s.coverZ - s.z) / 3.3f;   // время на дорогу
                    s.hasGoal = false; s.pathT = 0f;
                } else {
                    s.coverRetryT = 1.2f;
                    s.stateT = Math.max(s.stateT, 1f);
                }
            }
        }

        if (s.state == 3) {
            // в укрытии: добежать, перезарядиться, переждать, потом выйти и снова драться
            float cdx = s.coverX - s.x, cdz = s.coverZ - s.z;
            if (cdx * cdx + cdz * cdz > 0.5f) followPath(s, s.coverX, s.coverZ, 3.3f);
            aim = los;
            if (s.coverT <= 0f && s.reloadT <= 0f) {
                s.state = 0; s.stateT = 3f + rnd.nextFloat() * 3f; s.hasGoal = false;
            }
        } else if (engaged) {
            aim = true;
            if (s.team == 0 && distToPlayer(s) > 22f) {
                followSlot(s, 3.0f);                        // не уходить далеко от игрока
            } else if (dist > 20f) {
                followPath(s, tx, tz, 2.0f);                // сближаться, огибая препятствия
            } else {
                if (s.strafeT <= 0f) {
                    s.strafeT = 1f + rnd.nextFloat() * 2f; s.strafeDir = rnd.nextBoolean() ? 1f : -1f;
                    s.pause = rnd.nextFloat() < 0.3f;
                }
                float ux = (tx - s.x) / dist, uz = (tz - s.z) / dist;
                float fw = dist < 7f ? -1.5f : 0f;
                float st = s.pause ? 0f : 1.3f * s.strafeDir;
                mvx = ux * fw - uz * st;
                mvz = uz * fw + ux * st;
            }
        } else if (s.team == 0) {
            // союзник без контакта: держится рядом с игроком, а если враг близко - идёт к нему
            if (has && dist < 30f && distToPlayer(s) < 18f) followPath(s, tx, tz, 2.6f);
            else followSlot(s, 3.0f);
        } else if (s.team == 1 && (!has || (s.lastSeenAge >= 5f && dist > 26f))) {
            // противник далеко от игрока: идёт захватывать точку и держит её (дерётся, когда игрок рядом)
            objectiveMove(s);
        } else if (has) {
            // враг без контакта: идёт туда, где в последний раз видел цель; потом - с обходом с фланга
            float gx = tx, gz = tz;
            if (s.lastSeenAge < 5f) {
                gx = s.lastSeenX; gz = s.lastSeenZ;
                float ldx = gx - s.x, ldz = gz - s.z;
                if (ldx * ldx + ldz * ldz < 4f) s.lastSeenAge = 99f;
            } else if (dist > 28f && s.flank != 0) {
                float ux = (tx - s.x) / dist, uz = (tz - s.z) / dist;
                float lim = map.half - 3f;
                gx = Math.max(-lim, Math.min(lim, tx - uz * s.flank * 14f));
                gz = Math.max(-lim, Math.min(lim, tz + ux * s.flank * 14f));
            }
            followPath(s, gx, gz, 2.6f);
        }

        float vx = mvx, vz = mvz;
        float ty;
        if (aim && has) ty = desired;
        else if (vx * vx + vz * vz > 0.05f) ty = (float) Math.atan2(vx, -vz);
        else if (s.lastSeenAge < 10f) ty = (float) Math.atan2(s.lastSeenX - s.x, -(s.lastSeenZ - s.z));
        else if (has) ty = desired;
        else ty = s.yaw;
        s.yaw = turn(s.yaw, ty, 5f * dt);

        if (s.avoidT > 0f) {                                // застрял: шаг в сторону
            float rx = (float) Math.cos(s.yaw), rz = (float) Math.sin(s.yaw);
            vx = rx * s.avoidDir * 2.2f; vz = rz * s.avoidDir * 2.2f;
        }
        float sp = (float) Math.sqrt(vx * vx + vz * vz), ox = s.x, oz = s.z;
        tmp[0] = s.x + vx * dt; tmp[1] = s.z + vz * dt;
        map.resolve(tmp, 0.35f);
        s.x = tmp[0]; s.z = tmp[1];
        float moved = (float) Math.hypot(s.x - ox, s.z - oz);
        if (sp > 0.8f && moved < sp * dt * 0.3f) {
            s.stuckT += dt;
            if (s.stuckT > 0.5f) {
                s.stuckT = 0f; s.avoidT = 1.2f; s.avoidDir = rnd.nextBoolean() ? 1f : -1f;
                s.hasGoal = false; s.pathT = 0f;
            }
        } else s.stuckT = Math.max(0f, s.stuckT - dt);
        s.moving = moved / dt > 0.4f;
        s.walkPhase += moved * 3.2f;

        // прицеливание: чем дольше держит цель в поле зрения, тем точнее
        if (los) s.aimT = Math.min(2f, s.aimT + dt * (s.moving ? 0.5f : 1f));
        else s.aimT = Math.max(0f, s.aimT - dt * 2f);

        if (has && s.los && dist < 35f && s.fireCd <= 0f && s.reactT <= 0f && s.ammo > 0 && s.reloadT <= 0f
                && Math.abs(wrap(desired - s.yaw)) < 0.25f) {
            s.fireCd = 0.14f + rnd.nextFloat() * 0.06f;
            if (++s.burst >= 3 + rnd.nextInt(4)) { s.burst = 0; s.fireCd = 0.8f + rnd.nextFloat(); }
            s.flash = 0.06f;
            if (--s.ammo <= 0) { s.reloadT = 2.3f + rnd.nextFloat() * 0.7f; sfx(SoundBank.RELOAD, 0.35f, 1f); }
            if (dist > 25f) sfx(SoundBank.FAR, 0.4f, 1f);
            else sfx(SoundBank.RIFLE, Math.max(0.1f, 0.8f - dist / 40f), 0.95f + rnd.nextFloat() * 0.1f);
            float chance = Math.max(0.06f, Math.min(0.4f, 0.5f - dist * 0.012f));
            chance *= 0.55f + 0.45f * Math.min(1f, s.aimT / 1.2f);
            if (s.tgtP) chance *= 0.6f;
            if (rnd.nextFloat() < chance) {
                if (s.tgtP) damagePlayer(7f + rnd.nextFloat() * 3f);
                else {
                    s.tgt.hitDx = s.tgt.x - s.x; s.tgt.hitDz = s.tgt.z - s.z; s.tgt.hitAt = time;
                    damage(s.tgt, 12f + rnd.nextFloat() * 6f);
                    gore.spray(s.tgt.x, 1.2f, s.tgt.z, s.tgt.x - s.x, 0f, s.tgt.z - s.z, 3);
                }
            } else if (!s.tgtP && s.tgt != null) {
                s.tgt.underFire = Math.max(s.tgt.underFire, 1.5f);   // пули рядом: цель прижата
            }
        }
    }

    private float distToPlayer(Soldier s) {
        return (float) Math.hypot(s.x - p.x, s.z - p.z);
    }

    private void insertCand(Soldier o, float d2) {
        int i;
        if (cN < 3) i = cN++;
        else if (d2 < cD[2]) i = 2;
        else return;
        while (i > 0 && cD[i - 1] > d2) { cS[i] = cS[i - 1]; cD[i] = cD[i - 1]; i--; }
        cS[i] = o; cD[i] = d2;
    }

    /** Выбирает цель: из трёх ближайших врагов берёт первого, кого видно; иначе - ближайшего (чтобы идти к нему). */
    private void perceive(Soldier s) {
        cN = 0;
        for (Soldier o : soldiers) {
            if (o.dead || o.team == s.team) continue;
            float dx = o.x - s.x, dz = o.z - s.z;
            insertCand(o, dx * dx + dz * dz);
        }
        if (s.team == 1 && p.alive) {
            float dx = p.x - s.x, dz = p.z - s.z;
            insertCand(null, dx * dx + dz * dz);
        }
        if (cN == 0) { s.tgt = null; s.tgtP = false; s.los = false; return; }
        for (int i = 0; i < cN; i++) {
            boolean isP = cS[i] == null;
            float ex = isP ? p.x + leanDX() : cS[i].x, ez = isP ? p.z + leanDZ() : cS[i].z;
            float dx = ex - s.x, dz = ez - s.z, d = (float) Math.sqrt(cD[i]);
            if (d > 70f) continue;
            float inv = 1f / Math.max(d, 0.01f);
            if (map.raycast(s.x, 1.4f, s.z, dx * inv, 0f, dz * inv, d) >= d - 0.3f && !smokeBlocks(s.x, s.z, ex, ez)) {
                boolean same = s.tgtP == isP && s.tgt == cS[i];
                if (!same) s.aimT = Math.min(s.aimT, 0.3f);
                if (!s.los) s.reactT = 0.3f + rnd.nextFloat() * 0.5f;
                s.tgt = cS[i]; s.tgtP = isP; s.los = true;
                s.lastSeenX = ex; s.lastSeenZ = ez; s.lastSeenAge = 0f;
                return;
            }
        }
        s.los = false;
        s.tgt = cS[0]; s.tgtP = cS[0] == null;
    }

    /** Ищет рядом клетку, скрытую от угрозы (стена, дерево, высокий ящик). Ближе, дальше от угрозы и без толкучки - лучше. */
    private boolean findCover(Soldier s, float thx, float thz, float distNow) {
        float bestCost = 1e18f, bx = 0f, bz = 0f;
        boolean found = false;
        for (int ox = -12; ox <= 12; ox += 2) {
            for (int oz = -12; oz <= 12; oz += 2) {
                float cx = s.x + ox, cz = s.z + oz;
                float walkD = (float) Math.sqrt(ox * ox + oz * oz);
                if (walkD > 13f || !nav.isWalk(cx, cz)) continue;
                float dx = cx - thx, dz = cz - thz, d = (float) Math.sqrt(dx * dx + dz * dz);
                if (d < 4f || d > 45f) continue;
                float inv = 1f / d;
                if (map.raycast(thx, 1.4f, thz, dx * inv, 0f, dz * inv, d) >= d - 0.25f) continue;   // не скрыто
                boolean crowded = false;
                for (Soldier o : soldiers) {
                    if (o == s || o.dead) continue;
                    float ax = o.state == 3 ? o.coverX : o.x, az = o.state == 3 ? o.coverZ : o.z;
                    if (Math.abs(ax - cx) < 1.3f && Math.abs(az - cz) < 1.3f) { crowded = true; break; }
                }
                if (crowded) continue;
                float cost = walkD + 0.8f * Math.max(0f, distNow - d) + rnd.nextFloat() * 2f;
                if (cost < bestCost) { bestCost = cost; bx = cx; bz = cz; found = true; }
            }
        }
        if (found) { s.coverX = bx; s.coverZ = bz; }
        return found;
    }

    /** Идёт к точке по пути A*; если путь не построился или лимит кадра исчерпан - напрямую. Результат в mvx/mvz. */
    private void followPath(Soldier s, float gx, float gz, float speed) {
        boolean goalMoved = Math.abs(gx - s.goalX) + Math.abs(gz - s.goalZ) > 6f;
        if (!s.hasGoal || goalMoved || s.pathT <= 0f) {
            if (pathBudget > 0) {
                pathBudget--;
                s.wpN = nav.path(s.x, s.z, gx, gz, s.wpx, s.wpz);
                s.wpI = 0;
                s.goalX = gx; s.goalZ = gz; s.hasGoal = true;
                s.pathT = 1f + rnd.nextFloat() * 0.8f;
            } else if (!s.hasGoal) {
                s.wpN = 0; s.wpI = 0;
            }
        }
        while (s.wpI < s.wpN) {
            float wx = s.wpx[s.wpI] - s.x, wz = s.wpz[s.wpI] - s.z;
            if (wx * wx + wz * wz < 0.5f) s.wpI++; else break;
        }
        float px, pz;
        if (s.wpI < s.wpN) { px = s.wpx[s.wpI]; pz = s.wpz[s.wpI]; } else { px = gx; pz = gz; }
        float dx = px - s.x, dz = pz - s.z, d = (float) Math.sqrt(dx * dx + dz * dz);
        if (d < 1e-4f || (s.wpI >= s.wpN && d < 1f)) return;     // уже на месте
        mvx = dx / d * speed; mvz = dz / d * speed;
    }

    // ---------- точки захвата и блиндажи ----------

    /** Захват: у точки (радиус 8 м) считаем живых бойцов обеих команд; у кого больше - тот давит прогресс. Нужно 100% для смены хозяина. */
    private void updatePoints(float dt) {
        if (toastT > 0f) toastT -= dt;
        final float r2 = WorldMap.Point.RADIUS * WorldMap.Point.RADIUS;
        for (WorldMap.Point pt : map.points) {
            int a0 = 0, a1 = 0;
            if (p.alive) { float dx = p.x - pt.x, dz = p.z - pt.z; if (dx * dx + dz * dz < r2) a0++; }
            for (Soldier s : soldiers) {
                if (s.dead) continue;
                float dx = s.x - pt.x, dz = s.z - pt.z;
                if (dx * dx + dz * dz < r2) { if (s.team == 0) a0++; else a1++; }
            }
            int diff = a0 - a1;
            if (diff != 0) {
                float rate = (0.09f + 0.04f * (Math.min(4, Math.abs(diff)) - 1)) * dt;
                pt.cap = Math.max(-1f, Math.min(1f, pt.cap + (diff > 0 ? rate : -rate)));
            }
            int old = pt.owner;
            if (pt.cap >= 0.999f) pt.owner = 0;
            else if (pt.cap <= -0.999f) pt.owner = 1;
            else if (pt.owner == 0 && pt.cap <= 0f) pt.owner = -1;
            else if (pt.owner == 1 && pt.cap >= 0f) pt.owner = -1;
            if (pt.owner != old) {
                toast = "Точка " + pt.letter() + (pt.owner == 0 ? " захвачена" : pt.owner == 1 ? " потеряна" : " больше не под контролем");
                toastT = 3.5f;
                if (net != null) feed.add(new Feed(toast));
            }
        }
    }

    /** Свой блиндаж (на своей базе или на захваченной точке): внутри пополняются патроны и здоровье. */
    private void updateResupply(float dt) {
        supplyState = 0;
        if (!p.alive) return;
        for (WorldMap.Bunker b : map.bunkers) {
            if (!b.contains(p.x, p.z)) continue;
            int myTeam = net != null ? net.myTeam : 0;
            boolean mine = b.baseTeam >= 0 ? b.baseTeam == myTeam : map.points.get(b.point).owner == 0;
            if (!mine) { supplyState = 3; return; }
            int maxR = 180 + (Settings.ammoBox ? Config.AMMO_BOX_RIFLE : 0), maxP = 48 + (Settings.ammoBox ? Config.AMMO_BOX_PISTOL : 0);
            boolean did = false;
            if (p.reserve[0] < maxR) {
                supplyAcc0 += 45f * dt; int add = (int) supplyAcc0;
                if (add > 0) { p.reserve[0] = Math.min(maxR, p.reserve[0] + add); supplyAcc0 -= add; }
                did = true;
            }
            if (p.reserve[1] < maxP) {
                supplyAcc1 += 12f * dt; int add = (int) supplyAcc1;
                if (add > 0) { p.reserve[1] = Math.min(maxP, p.reserve[1] + add); supplyAcc1 -= add; }
                did = true;
            }
            int gk = -1;                                              // какого типа не хватает до набора из «Снаряжения»
            for (int k = 0; k < Config.GREN_TYPES; k++) if (p.gren[k] < Settings.gn[k]) { gk = k; break; }
            if (gk >= 0 && p.grenTotal() < Config.classGrenades(Settings.cls)) {
                supplyAcc2 += 0.4f * dt;
                if (supplyAcc2 >= 1f) { supplyAcc2 -= 1f; p.gren[gk]++; }
                did = true;
            }
            int maxM = Config.classMedkits(Settings.cls);
            if (p.medkits < maxM) {
                supplyAcc3 += 0.3f * dt;
                if (supplyAcc3 >= 1f) { supplyAcc3 -= 1f; p.medkits++; }
                did = true;
            }
            if (p.hp < 100f) { p.hp = Math.min(100f, p.hp + 18f * dt); did = true; }
            supplyState = did ? 1 : 2;
            return;
        }
    }

    /** Куда идёт противник без контакта: к «своей» точке по флангу (A/B/C по s.flank), а если она уже его - к ближайшей не его; удерживает её внутри блиндажа. */
    private void objectiveMove(Soldier s) {
        if (map.points.isEmpty()) return;
        if (s.objective < 0 || s.objT <= 0f) {
            int pref = Math.max(0, Math.min(map.points.size() - 1, s.flank + 1));
            int best = -1;
            if (map.points.get(pref).owner != 1) best = pref;
            else {
                float bd = 1e18f;
                for (WorldMap.Point pt : map.points) {
                    if (pt.owner == 1) continue;
                    float d = (pt.x - s.x) * (pt.x - s.x) + (pt.z - s.z) * (pt.z - s.z);
                    if (d < bd) { bd = d; best = pt.id; }
                }
            }
            if (best < 0) best = pref;                       // все точки уже его: остаётся охранять
            s.objective = best;
            s.objT = 8f + rnd.nextFloat() * 6f;
        }
        WorldMap.Point pt = map.points.get(s.objective);
        int h = Math.floorMod(System.identityHashCode(s), 5);
        float gx = pt.x + (h - 2) * 1.1f, gz = pt.z + ((h * 3) % 5 - 2) * 0.5f;     // каждый встаёт на своё место внутри блиндажа
        float dx = gx - s.x, dz = gz - s.z;
        if (dx * dx + dz * dz > 1.5f) followPath(s, gx, gz, 2.6f);
    }

    /** Место в строю вокруг игрока (в мировых координатах, чтобы строй не вертелся вместе с камерой). */
    private void followSlot(Soldier s, float speed) {
        float a = s.slot * 1.2566f + 0.6283f, r = 5.5f + (s.slot % 2) * 2f;
        float gx = p.x + (float) Math.cos(a) * r, gz = p.z + (float) Math.sin(a) * r;
        float lim = map.half - 3f;
        gx = Math.max(-lim, Math.min(lim, gx)); gz = Math.max(-lim, Math.min(lim, gz));
        float dx = gx - s.x, dz = gz - s.z;
        if (dx * dx + dz * dz < 2.25f) return;                    // уже на месте
        followPath(s, gx, gz, speed);
    }
}
