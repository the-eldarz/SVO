package com.bodycamclone;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Журнал для разработчика: сюда пишут загрузка моделей и анимаций, ошибки и вылеты. Показывается в главном меню по кнопке «Логи»,
 * а не поверх игры. Хранится в памяти и в файле (files/devlog.txt), поэтому после вылета игры записи остаются.
 * Потокобезопасен: пишут и поток отрисовки, и поток интерфейса.
 */
public final class DevLog {
    private DevLog() {}

    private static final int MAX_LINES = 4000, KEEP_ON_START = 1500;
    private static final List<String> lines = new ArrayList<>();
    private static final SimpleDateFormat TIME = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);
    private static Writer out;
    private static File file;

    /** Открывает файл журнала и подгружает хвост прошлого запуска. Вызывать один раз при старте приложения. */
    public static synchronized void init(Context c) {
        if (file != null) return;
        file = new File(c.getApplicationContext().getFilesDir(), "devlog.txt");
        List<String> old = new ArrayList<>();
        try {
            if (file.exists()) {
                try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"))) {
                    String s;
                    while ((s = r.readLine()) != null) {
                        old.add(s);
                        if (old.size() > KEEP_ON_START) old.remove(0);
                    }
                }
            }
        } catch (IOException ignored) { }
        List<String> mem = new ArrayList<>(lines);          // что успели записать до init
        lines.clear();
        lines.addAll(old);
        if (!old.isEmpty()) lines.add("──────── прошлый запуск выше, новый ниже ────────");
        lines.addAll(mem);
        try {
            out = new OutputStreamWriter(new FileOutputStream(file, false), "UTF-8");
            for (String s : lines) { out.write(s); out.write('\n'); }
            out.flush();
        } catch (IOException e) { out = null; }
        i("Запуск", new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.US).format(new Date()) + ", Android " + Build.VERSION.RELEASE
                + " (API " + Build.VERSION.SDK_INT + "), " + Build.MANUFACTURER + " " + Build.MODEL);
    }

    public static void i(String tag, String msg) { add('I', tag, msg); }
    public static void w(String tag, String msg) { add('W', tag, msg); }
    public static void e(String tag, String msg) { add('E', tag, msg); }

    public static void e(String tag, String msg, Throwable t) {
        StringBuilder sb = new StringBuilder(msg).append(": ").append(t);
        int n = 0;
        for (StackTraceElement el : t.getStackTrace()) { sb.append("\n      at ").append(el); if (++n >= 12) break; }
        Throwable cause = t.getCause();
        if (cause != null) sb.append("\n      причина: ").append(cause);
        add('E', tag, sb.toString());
    }

    private static synchronized void add(char level, String tag, String msg) {
        String head = TIME.format(new Date()) + " " + level + " [" + tag + "] ";
        for (String part : msg.split("\n")) {
            String line = head + part;
            head = "                      ";            // продолжение многострочной записи
            lines.add(line);
            if (out != null) {
                try { out.write(line); out.write('\n'); } catch (IOException ignored) { }
            }
        }
        while (lines.size() > MAX_LINES) lines.remove(0);
        if (out != null) { try { out.flush(); } catch (IOException ignored) { } }
        if (level == 'E') Log.e("Bodycam", "[" + tag + "] " + msg);
        else if (level == 'W') Log.w("Bodycam", "[" + tag + "] " + msg);
        else Log.i("Bodycam", "[" + tag + "] " + msg);
    }

    /** Копия строк журнала. problemsOnly - только предупреждения и ошибки (и их продолжения). */
    public static synchronized List<String> snapshot(boolean problemsOnly) {
        if (!problemsOnly) return new ArrayList<>(lines);
        List<String> res = new ArrayList<>();
        boolean keep = false;
        for (String s : lines) {
            boolean head = s.length() > 14 && s.charAt(12) == ' ' && (s.charAt(13) == 'I' || s.charAt(13) == 'W' || s.charAt(13) == 'E') && s.charAt(14) == ' ';
            if (head) keep = s.charAt(13) != 'I';
            if (keep) res.add(s);
        }
        return res;
    }

    public static synchronized String dump(boolean problemsOnly) {
        StringBuilder sb = new StringBuilder();
        for (String s : snapshot(problemsOnly)) sb.append(s).append('\n');
        return sb.toString();
    }

    public static synchronized void clear() {
        lines.clear();
        try {
            if (out != null) out.close();
            if (file != null) out = new OutputStreamWriter(new FileOutputStream(file, false), "UTF-8");
        } catch (IOException e) { out = null; }
        i("Лог", "журнал очищен");
    }
}
