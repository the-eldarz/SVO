package com.bodycamclone;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Брызги крови и осколки при попаданиях. Все частицы - маленькие кубики: летят по баллистике, падают на землю,
 * часть оставляет пятна. Обновляется из Game.update, рисуется в GameRenderer.drawGore (один поток, блокировок нет).
 */
public final class Gore {
    public static final class P {
        public float x, y, z, vx, vy, vz, life, size, r, g, b;
        /** Осколок (кость/мясо): отскакивает от земли и дольше живёт; капля при ударе об землю исчезает. */
        public boolean chunk;
        /** Гравитация (м/с^2; минус - летит вверх) и дым: растёт вверх, замедляется и тает. */
        public float grav = 9.8f;
        public boolean smoke;
    }

    public static final class Splat {
        public float x, z, size, life;
    }

    private static final int[] MAX_PARTS_BY = {100, 200, 320}, MAX_SPLATS_BY = {16, 40, 70};
    /** Детализация эффектов 0..2 (низкое..высокое): сколько капель и пятен крови остаётся. Задаётся из Game.update. */
    public int level = 2;
    private int thin;
    public final List<P> parts = new ArrayList<>();
    public final List<Splat> splats = new ArrayList<>();
    private final Random rnd = new Random();

    public void clear() { parts.clear(); splats.clear(); }

    private P add(float x, float y, float z, float vx, float vy, float vz, float size, float life, float r, float g, float b, boolean chunk) {
        if (parts.size() >= MAX_PARTS_BY[level]) parts.remove(0);
        P p = new P();
        p.x = x; p.y = y; p.z = z; p.vx = vx; p.vy = vy; p.vz = vz;
        p.size = size; p.life = life; p.r = r; p.g = g; p.b = b; p.chunk = chunk;
        parts.add(p);
        return p;
    }

    private float rr() { return rnd.nextFloat() * 2f - 1f; }

    private void blood(float x, float y, float z, float vx, float vy, float vz, float size) {
        if (level < 2 && (++thin % (level == 0 ? 3 : 2)) != 0) return;     // низкое - каждая третья капля, среднее - каждая вторая
        float k = 0.75f + rnd.nextFloat() * 0.5f;
        add(x, y, z, vx, vy, vz, size, 0.7f + rnd.nextFloat() * 0.7f, 0.50f * k, 0.02f, 0.02f, false);
    }

    /** Брызги из точки попадания: больше капель по ходу пули (выходное отверстие), несколько назад. */
    public void spray(float x, float y, float z, float dx, float dy, float dz, int n) {
        float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1e-5f) { dx = 0f; dy = 1f; dz = 0f; l = 1f; }
        dx /= l; dy /= l; dz /= l;
        for (int i = 0; i < n; i++) {
            float dir = i % 3 == 2 ? -0.6f : 1f;                  // каждая третья капля летит назад к стрелку
            float sp = 1.5f + rnd.nextFloat() * 3.2f;
            blood(x, y, z,
                    (dx * dir + rr() * 0.55f) * sp,
                    (dy * dir + rr() * 0.55f + 0.25f) * sp,
                    (dz * dir + rr() * 0.55f) * sp,
                    0.018f + rnd.nextFloat() * 0.02f);
        }
    }

    /** Фонтанчик из шеи после потери головы: капли вверх с небольшим разбросом. */
    public void spurt(float x, float y, float z) {
        blood(x, y, z, rr() * 0.7f, 1.8f + rnd.nextFloat() * 1.6f, rr() * 0.7f, 0.02f + rnd.nextFloat() * 0.02f);
    }

    /** Голову разносит: туман из капель, осколки кости и тёмные куски, всё по ходу пули и вверх. */
    public void headBurst(float x, float y, float z, float dx, float dy, float dz) {
        float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1e-5f) { dx = 0f; dy = 0f; dz = 1f; l = 1f; }
        dx /= l; dy /= l; dz /= l;
        for (int i = 0; i < 26; i++) {
            float sp = 1.5f + rnd.nextFloat() * 5f;
            blood(x + rr() * 0.05f, y + rr() * 0.06f, z + rr() * 0.05f,
                    (dx * 0.8f + rr() * 0.8f) * sp, (dy * 0.8f + rr() * 0.7f + 0.5f) * sp, (dz * 0.8f + rr() * 0.8f) * sp,
                    0.02f + rnd.nextFloat() * 0.03f);
        }
        for (int i = 0; i < 9; i++) {
            float sp = 2f + rnd.nextFloat() * 4f;
            boolean bone = i % 3 == 0;
            float k = 0.85f + rnd.nextFloat() * 0.3f;
            float s = 0.035f + rnd.nextFloat() * 0.04f;
            add(x, y, z, (dx * 0.7f + rr() * 0.9f) * sp, (dy * 0.5f + rnd.nextFloat() * 1.1f + 0.4f) * sp, (dz * 0.7f + rr() * 0.9f) * sp,
                    s, 1.8f + rnd.nextFloat() * 1.2f,
                    bone ? 0.78f * k : 0.34f * k, bone ? 0.72f * k : 0.03f, bone ? 0.62f * k : 0.03f, true);
        }
    }

    /** Куски мяса и кости из тела (по трупу): летят по ходу пули и вверх, отскакивают от земли. */
    public void meat(float x, float y, float z, float dx, float dy, float dz, int n) {
        float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1e-5f) { dx = 0f; dy = 1f; dz = 0f; l = 1f; }
        dx /= l; dy /= l; dz /= l;
        if (level == 0) n = Math.max(1, n / 2);
        for (int i = 0; i < n; i++) {
            float sp = 1.5f + rnd.nextFloat() * 3.5f;
            boolean bone = i % 4 == 0;
            float k = 0.8f + rnd.nextFloat() * 0.4f;
            add(x, y, z, (dx * 0.5f + rr() * 0.9f) * sp, (dy * 0.4f + rnd.nextFloat() * 1.0f + 0.3f) * sp, (dz * 0.5f + rr() * 0.9f) * sp,
                    0.03f + rnd.nextFloat() * 0.035f, 1.6f + rnd.nextFloat() * 1.2f,
                    bone ? 0.78f * k : 0.42f * k, bone ? 0.72f * k : 0.04f, bone ? 0.62f * k : 0.04f, true);
        }
    }

    /** Взрыв гранаты: комья земли, горящие искры и дым (дым поднимается вверх). */
    public void blast(float x, float y, float z) {
        int n = level == 0 ? 12 : (level == 1 ? 22 : 34);
        for (int i = 0; i < n; i++) {
            float sp = 3f + rnd.nextFloat() * 9f;
            float a = rnd.nextFloat() * 6.2832f, up = 0.3f + rnd.nextFloat() * 0.9f;
            float cx = (float) Math.cos(a), cz = (float) Math.sin(a), k = rnd.nextFloat();
            if (i % 3 == 0) {
                add(x, y, z, cx * sp * 0.6f, up * sp, cz * sp * 0.6f, 0.05f + k * 0.07f, 1.4f + rnd.nextFloat(), 0.30f, 0.22f, 0.12f, true);
            } else if (i % 3 == 1) {
                add(x, y, z, cx * sp * 0.8f, up * sp * 0.8f, cz * sp * 0.8f, 0.03f, 0.4f + rnd.nextFloat() * 0.3f, 1f, 0.6f, 0.15f, true);
            } else {
                P q = add(x + rr() * 0.3f, y, z + rr() * 0.3f, rr() * 1.5f, 0.8f + rnd.nextFloat() * 1.6f, rr() * 1.5f,
                        0.25f + k * 0.25f, 1.6f + rnd.nextFloat() * 1.2f, 0.28f, 0.28f, 0.30f, true);
                q.grav = -1.2f; q.smoke = true;
            }
        }
    }

    private void splat(float x, float z, float size) {
        if (splats.size() >= MAX_SPLATS_BY[level]) splats.remove(0);
        Splat s = new Splat();
        s.x = x; s.z = z; s.size = size; s.life = 25f;
        splats.add(s);
    }

    public void update(float dt) {
        for (int i = parts.size() - 1; i >= 0; i--) {
            P p = parts.get(i);
            p.life -= dt;
            if (p.life <= 0f) { parts.remove(i); continue; }
            p.vy -= p.grav * dt;
            if (p.smoke) { float f = (float) Math.pow(0.35, dt); p.vx *= f; p.vz *= f; if (p.vy > 1.6f) p.vy = 1.6f; }
            p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
            float floor = p.size * 0.5f;
            if (p.y <= floor) {
                if (p.chunk) {
                    p.y = floor;
                    if (p.vy < -0.8f) { p.vy = -p.vy * 0.3f; p.vx *= 0.6f; p.vz *= 0.6f; }
                    else { p.vy = 0f; p.vx *= 0.8f; p.vz *= 0.8f; }
                } else {
                    if (rnd.nextFloat() < 0.5f) splat(p.x, p.z, 0.05f + rnd.nextFloat() * 0.09f);
                    parts.remove(i);
                }
            }
        }
        for (int i = splats.size() - 1; i >= 0; i--) {
            Splat s = splats.get(i);
            s.life -= dt;
            if (s.life <= 0f) splats.remove(i);
        }
    }
}
