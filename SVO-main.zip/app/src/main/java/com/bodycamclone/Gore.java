package com.bodycamclone;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Брызги крови и осколки при попаданиях. Все частицы - маленькие кубики: летят по баллистике, падают на землю,
 * часть оставляет пятна. Обновляется из Game.update, рисуется в GameRenderer.drawGore (один поток, блокировок нет).
 */
public final class Gore {
    public static final class P {
        public float x, y, z, vx, vy, vz, life, size, r, g, b;
        /** Осколок (кость/мясо): отскакивает от земли и дольше живёт; капля при ударе об землю исчезает. */
        public boolean chunk;
    }

    public static final class Splat {
        public float x, z, size, life;
    }

    private static final int[] MAX_PARTS_BY = {100, 200, 320}, MAX_SPLATS_BY = {16, 40, 70};
    /** Детализация эффектов 0..2 (низкое..высокое): сколько капель и пятен крови остаётся. Задаётся из Game.update. */
    public int level = 2;
    private int thin;
    public final List<P> parts = new ArrayList<>();
    public final List<Splat> splats = new ArrayList<>();
    private final Random rnd = new Random();

    public void clear() { parts.clear(); splats.clear(); }

    private P add(float x, float y, float z, float vx, float vy, float vz, float size, float life, float r, float g, float b, boolean chunk) {
        if (parts.size() >= MAX_PARTS_BY[level]) parts.remove(0);
        P p = new P();
        p.x = x; p.y = y; p.z = z; p.vx = vx; p.vy = vy; p.vz = vz;
        p.size = size; p.life = life; p.r = r; p.g = g; p.b = b; p.chunk = chunk;
        parts.add(p);
        return p;
    }

    private float rr() { return rnd.nextFloat() * 2f - 1f; }

    private void blood(float x, float y, float z, float vx, float vy, float vz, float size) {
        if (level < 2 && (++thin % (level == 0 ? 3 : 2)) != 0) return;     // низкое - каждая третья капля, среднее - каждая вторая
        float k = 0.75f + rnd.nextFloat() * 0.5f;
        add(x, y, z, vx, vy, vz, size, 0.7f + rnd.nextFloat() * 0.7f, 0.50f * k, 0.02f, 0.02f, false);
    }

    /** Брызги из точки попадания: больше капель по ходу пули (выходное отверстие), несколько назад. */
    public void spray(float x, float y, float z, float dx, float dy, float dz, int n) {
        float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1e-5f) { dx = 0f; dy = 1f; dz = 0f; l = 1f; }
        dx /= l; dy /= l; dz /= l;
        for (int i = 0; i < n; i++) {
            float dir = i % 3 == 2 ? -0.6f : 1f;                  // каждая третья капля летит назад к стрелку
            float sp = 1.5f + rnd.nextFloat() * 3.2f;
            blood(x, y, z,
                    (dx * dir + rr() * 0.55f) * sp,
                    (dy * dir + rr() * 0.55f + 0.25f) * sp,
                    (dz * dir + rr() * 0.55f) * sp,
                    0.018f + rnd.nextFloat() * 0.02f);
        }
    }

    /** Фонтанчик из шеи после потери головы: капли вверх с небольшим разбросом. */
    public void spurt(float x, float y, float z) {
        blood(x, y, z, rr() * 0.7f, 1.8f + rnd.nextFloat() * 1.6f, rr() * 0.7f, 0.02f + rnd.nextFloat() * 0.02f);
    }

    /** Голову разносит: туман из капель, осколки кости и тёмные куски, всё по ходу пули и вверх. */
    public void headBurst(float x, float y, float z, float dx, float dy, float dz) {
        float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1e-5f) { dx = 0f; dy = 0f; dz = 1f; l = 1f; }
        dx /= l; dy /= l; dz /= l;
        for (int i = 0; i < 26; i++) {
            float sp = 1.5f + rnd.nextFloat() * 5f;
            blood(x + rr() * 0.05f, y + rr() * 0.06f, z + rr() * 0.05f,
                    (dx * 0.8f + rr() * 0.8f) * sp, (dy * 0.8f + rr() * 0.7f + 0.5f) * sp, (dz * 0.8f + rr() * 0.8f) * sp,
                    0.02f + rnd.nextFloat() * 0.03f);
        }
        for (int i = 0; i < 9; i++) {
            float sp = 2f + rnd.nextFloat() * 4f;
            boolean bone = i % 3 == 0;
            float k = 0.85f + rnd.nextFloat() * 0.3f;
            float s = 0.035f + rnd.nextFloat() * 0.04f;
            add(x, y, z, (dx * 0.7f + rr() * 0.9f) * sp, (dy * 0.5f + rnd.nextFloat() * 1.1f + 0.4f) * sp, (dz * 0.7f + rr() * 0.9f) * sp,
                    s, 1.8f + rnd.nextFloat() * 1.2f,
                    bone ? 0.78f * k : 0.34f * k, bone ? 0.72f * k : 0.03f, bone ? 0.62f * k : 0.03f, true);
        }
    }

    private void splat(float x, float z, float size) {
        if (splats.size() >= MAX_SPLATS_BY[level]) splats.remove(0);
        Splat s = new Splat();
        s.x = x; s.z = z; s.size = size; s.life = 25f;
        splats.add(s);
    }

    public void update(float dt) {
        for (int i = parts.size() - 1; i >= 0; i--) {
            P p = parts.get(i);
            p.life -= dt;
            if (p.life <= 0f) { parts.remove(i); continue; }
            p.vy -= 9.8f * dt;
            p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
            float floor = p.size * 0.5f;
            if (p.y <= floor) {
                if (p.chunk) {
                    p.y = floor;
                    if (p.vy < -0.8f) { p.vy = -p.vy * 0.3f; p.vx *= 0.6f; p.vz *= 0.6f; }
                    else { p.vy = 0f; p.vx *= 0.8f; p.vz *= 0.8f; }
                } else {
                    if (rnd.nextFloat() < 0.5f) splat(p.x, p.z, 0.05f + rnd.nextFloat() * 0.09f);
                    parts.remove(i);
                }
            }
        }
        for (int i = splats.size() - 1; i >= 0; i--) {
            Splat s = splats.get(i);
            s.life -= dt;
            if (s.life <= 0f) splats.remove(i);
        }
    }
}
