package com.bodycamclone;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/**
 * Экран «Кастомизация»: перетаскивай кнопки, джойстик и зону стрельбы пальцем.
 * Нажатие на элемент выбирает его, и MainActivity показывает панель его настроек (как в Standoff).
 * Жёлтая рамка - зона стрельбы: за рамку - двигать, за квадрат в правом нижнем углу - менять размер.
 */
public class ButtonEditorView extends View {
    public static final int SEL_NONE = -3, SEL_JOY = -2, SEL_ZONE = -1;

    public interface OnSelect { void onSelect(int sel); }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private final boolean dim;
    private int sel = SEL_NONE;
    private OnSelect listener;
    private boolean dragging, resizingZone;
    private float gx, gy;
    private final Game.Player sample = new Game.Player();

    public ButtonEditorView(Context c, boolean dimBackground) {
        super(c);
        dim = dimBackground;
        d = c.getResources().getDisplayMetrics().density;
        sample.ammo[0] = 30; sample.reserve[0] = 90; sample.gren[0] = 2; sample.gren[1] = 1;
    }

    public void setOnSelect(OnSelect l) { listener = l; }

    private void select(int s) {
        if (s == sel) return;
        sel = s;
        if (listener != null) listener.onSelect(s);
    }

    /** Кнопки − / + сверху: размер выбранной кнопки или джойстика. */
    public void resize(float delta) {
        if (sel >= 0) Settings.sc[sel] = Settings.clamp(Settings.sc[sel] + delta, 0.6f, 1.6f);
        else if (sel == SEL_JOY) Settings.joyScale = Settings.clamp(Settings.joyScale + delta, 0.6f, 1.6f);
        else return;
        invalidate();
        if (listener != null) listener.onSelect(sel);      // обновить ползунки в панели
    }

    public void refresh() { invalidate(); }

    /** Снять выбор без вызова панели (после «Сброс»). */
    public void clearSelection() { sel = SEL_NONE; invalidate(); }

    private float zl() { return Settings.zx * getWidth(); }
    private float zt() { return Settings.zy * getHeight(); }
    private float zr() { return (Settings.zx + Settings.zw) * getWidth(); }
    private float zb() { return (Settings.zy + Settings.zh) * getHeight(); }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setColor(dim ? 0xCC000000 : 0xFF3A3C48);
        c.drawRect(0, 0, w, h, p);

        // зона стрельбы: обычная - цвет и прозрачность как у кнопок, красная - когда вместо неё выбраны кнопки
        boolean zoneOn = Settings.fireMode != Settings.FIRE_BTN_ONLY;
        int zFill = zoneOn ? 0x99303440 : 0x88A02A38;
        int zEdge = zoneOn ? 0xE6C9CCD6 : 0xFFEE3A4C;
        int zText = zoneOn ? 0xE6C9CCD6 : 0xFFEE3A4C;
        p.setStyle(Paint.Style.FILL);
        p.setColor(zFill);
        c.drawRect(zl(), zt(), zr(), zb(), p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth((sel == SEL_ZONE ? 3.5f : 2.5f) * d);
        p.setColor(sel == SEL_ZONE ? 0xFFF0C419 : zEdge);      // жёлтая рамка - только выделение, как у кнопок
        c.drawRect(zl(), zt(), zr(), zb(), p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(zEdge);
        float hs = 11 * d;
        c.drawRect(zr() - hs * 2, zb() - hs * 2, zr(), zb(), p);          // ручка изменения размера
        p.setColor(0xFF2A2C36); p.setStrokeWidth(2 * d);
        p.setStyle(Paint.Style.STROKE);
        c.drawLine(zr() - hs * 1.6f, zb() - hs * 0.4f, zr() - hs * 0.4f, zb() - hs * 1.6f, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(zText); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(13 * d);
        c.drawText(zoneOn ? "ЗОНА СТРЕЛЬБЫ" : "ЗОНА СТРЕЛЬБЫ (выключена)", (zl() + zr()) / 2f, (zt() + zb()) / 2f, p);

        // область, где «свободный» джойстик берёт палец
        if (Settings.joyMode == Settings.JOY_FREE) {
            float x0 = Settings.joyRight ? w * 0.6f : 8 * d, x1 = Settings.joyRight ? w - 8 * d : w * 0.4f;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2 * d); p.setColor(0x33FFFFFF);
            c.drawRect(x0, h * 0.45f, x1, h - 8 * d, p);
            p.setStyle(Paint.Style.FILL); p.setColor(0x66FFFFFF);
            c.drawText("зона джойстика (движение)", (x0 + x1) / 2f, h * 0.75f, p);
        }
        p.setStyle(Paint.Style.FILL); p.setColor(0x66FFFFFF);
        c.drawText("остальной экран - камера", w * 0.5f, h - 40 * d, p);

        // джойстик
        float jx = Settings.joyCx(w, d), jy = Settings.joyCy(h, d), jr = Settings.joyRad(d);
        ControlsUi.drawJoystick(c, p, jx, jy, jr, 0f, 0f, false, Settings.joyAlpha);
        if (sel == SEL_JOY) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3 * d); p.setColor(0xFFF0C419);
            c.drawCircle(jx, jy, jr, p);
        }

        for (int i = 0; i < Settings.COUNT; i++) {
            float cx = Settings.cx(i, w, d), cy = Settings.cy(i, h, d);
            float fade = Settings.hidden(i) ? 0.35f : 1f;
            ControlsUi.drawButton(c, p, i, cx, cy, d, false, false, fade, sample);
            if (i == sel) {
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3 * d); p.setColor(0xFFF0C419);
                float hw = Settings.hw(i, d) + 3 * d, hh = Settings.hh(i, d) + 3 * d;
                if (Settings.isRect(i)) c.drawRoundRect(cx - hw, cy - hh, cx + hw, cy + hh, 9 * d, 9 * d, p);
                else c.drawCircle(cx, cy, hw, p);
            }
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFE8EDE4); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(14 * d);
        if (sel >= 0) c.drawText("Выбрано: " + Settings.LABEL[sel] + "   размер " + Math.round(Settings.sc[sel] * 100) + "%", w * 0.7f, 22 * d + h * 0.5f, p);
        p.setTextAlign(Paint.Align.LEFT);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int w = getWidth(), h = getHeight();
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                dragging = false; resizingZone = false;
                // ручка зоны - самая верхняя
                if (x >= zr() - 26 * d && x <= zr() + 14 * d && y >= zb() - 26 * d && y <= zb() + 14 * d) {
                    select(SEL_ZONE); resizingZone = true; invalidate(); return true;
                }
                int best = -1;
                float bestRatio = 1.2f;
                for (int i = 0; i < Settings.COUNT; i++) {
                    float ratio = Settings.ratio(i, x, y, w, h, d);
                    if (ratio < bestRatio) { bestRatio = ratio; best = i; }
                }
                float jx = Settings.joyCx(w, d), jy = Settings.joyCy(h, d), jr = Settings.joyRad(d);
                if (best >= 0) {
                    select(best); dragging = true;
                    gx = x - Settings.cx(best, w, d); gy = y - Settings.cy(best, h, d);
                } else if (Math.hypot(x - jx, y - jy) <= jr * 1.1f) {
                    select(SEL_JOY); dragging = true;
                    gx = x - jx; gy = y - jy;
                } else if (x >= zl() && x <= zr() && y >= zt() && y <= zb()) {
                    select(SEL_ZONE); dragging = true;
                    gx = x - zl(); gy = y - zt();
                } else {
                    select(SEL_NONE);        // нажали в пустое место - панель скрывается
                }
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                if (resizingZone) {
                    Settings.zw = Math.max(0.12f, Math.min(1f - Settings.zx, x / w - Settings.zx));
                    Settings.zh = Math.max(0.15f, Math.min(1f - Settings.zy, y / h - Settings.zy));
                    invalidate();
                } else if (dragging && sel == SEL_ZONE) {
                    Settings.zx = (x - gx) / w; Settings.zy = (y - gy) / h;
                    Settings.clampZone();
                    invalidate();
                } else if (dragging && sel == SEL_JOY) {
                    float jr = Settings.joyRad(d);
                    float cx = Math.max(jr, Math.min(w - jr, x - gx)), cy = Math.max(jr, Math.min(h - jr, y - gy));
                    Settings.joyX = (Settings.joyRight ? w - cx : cx) / d;
                    Settings.joyY = (h - cy) / d;
                    invalidate();
                } else if (dragging && sel >= 0) {
                    float hw = Settings.hw(sel, d), hh = Settings.hh(sel, d);
                    float cx = Math.max(hw, Math.min(w - hw, x - gx)), cy = Math.max(hh, Math.min(h - hh, y - gy));
                    Settings.ox[sel] = (w - cx) / d;
                    Settings.oy[sel] = (h - cy) / d;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false; resizingZone = false;
                return true;
        }
        return true;
    }
}
