package com.bodycamclone;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/** Экран «Расположение кнопок»: перетаскивай кнопки пальцем, размер меняют кнопки − / + сверху. */
public class ButtonEditorView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private final boolean dim;
    private int sel = 0;
    private boolean dragging;
    private float gx, gy;

    public ButtonEditorView(Context c, boolean dimBackground) {
        super(c);
        dim = dimBackground;
        d = c.getResources().getDisplayMetrics().density;
    }

    public void resize(float delta) {
        Settings.sc[sel] = Math.max(0.6f, Math.min(1.6f, Settings.sc[sel] + delta));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setColor(dim ? 0xCC000000 : 0xFF0E1214);
        c.drawRect(0, 0, w, h, p);

        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2 * d); p.setColor(0x33FFFFFF);
        c.drawRect(8 * d, 8 * d, w * 0.4f, h - 8 * d, p);
        p.setStyle(Paint.Style.FILL); p.setColor(0x55FFFFFF);
        p.setTextAlign(Paint.Align.CENTER); p.setTextSize(13 * d);
        c.drawText("зона джойстика (движение)", w * 0.2f, h / 2f, p);
        c.drawText("остальной экран - камера", w * 0.7f, h * 0.16f, p);

        for (int i = 0; i < Settings.COUNT; i++) {
            float cx = Settings.cx(i, w, d), cy = Settings.cy(i, h, d), r = Settings.rad(i, d);
            boolean s = i == sel;
            p.setStyle(Paint.Style.FILL); p.setColor(s ? 0xAA9CC48F : 0x66FFFFFF);
            c.drawCircle(cx, cy, r, p);
            if (s) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3 * d); p.setColor(0xFFE8F5E0); c.drawCircle(cx, cy, r, p); }
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFFFFF);
            p.setTextSize(13 * d * Math.max(0.8f, Settings.sc[i]));
            c.drawText(Settings.LABEL[i], cx, cy + 4 * d, p);
        }
        p.setColor(0xFFE8EDE4); p.setTextSize(14 * d);
        c.drawText("Выбрано: " + Settings.LABEL[sel] + "   размер " + Math.round(Settings.sc[sel] * 100) + "%", w / 2f, h - 18 * d, p);
        p.setTextAlign(Paint.Align.LEFT);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int w = getWidth(), h = getHeight();
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                int best = -1;
                float bestRatio = 1.2f;
                for (int i = 0; i < Settings.COUNT; i++) {
                    float dx = x - Settings.cx(i, w, d), dy = y - Settings.cy(i, h, d);
                    float ratio = (float) Math.hypot(dx, dy) / Settings.rad(i, d);
                    if (ratio < bestRatio) { bestRatio = ratio; best = i; }
                }
                dragging = best >= 0;
                if (dragging) {
                    sel = best;
                    gx = x - Settings.cx(sel, w, d); gy = y - Settings.cy(sel, h, d);
                    invalidate();
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                if (dragging) {
                    float r = Settings.rad(sel, d);
                    float cx = Math.max(r, Math.min(w - r, x - gx)), cy = Math.max(r, Math.min(h - r, y - gy));
                    Settings.ox[sel] = (w - cx) / d;
                    Settings.oy[sel] = (h - cy) / d;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                return true;
        }
        return true;
    }
}
