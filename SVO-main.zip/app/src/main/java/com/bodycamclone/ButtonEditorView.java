package com.bodycamclone;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/**
 * Экран «Кастомизация»: перетаскивай кнопки пальцем, размер выбранной кнопки меняют − / + сверху.
 * Жёлтая рамка - зона стрельбы: тащи за рамку, чтобы подвинуть, и за квадрат в правом нижнем углу, чтобы изменить размер.
 */
public class ButtonEditorView extends View {
    private static final int SEL_ZONE = -1;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private final boolean dim;
    private int sel = 0;
    private boolean dragging, resizingZone;
    private float gx, gy;
    private final Game.Player sample = new Game.Player();

    public ButtonEditorView(Context c, boolean dimBackground) {
        super(c);
        dim = dimBackground;
        d = c.getResources().getDisplayMetrics().density;
        sample.ammo[0] = 30; sample.reserve[0] = 90;
    }

    public void resize(float delta) {
        if (sel < 0) return;
        Settings.sc[sel] = Math.max(0.6f, Math.min(1.6f, Settings.sc[sel] + delta));
        invalidate();
    }

    /** Режим стрельбы изменился снаружи (кнопки сверху). */
    public void refresh() { invalidate(); }

    private float zl() { return Settings.zx * getWidth(); }
    private float zt() { return Settings.zy * getHeight(); }
    private float zr() { return (Settings.zx + Settings.zw) * getWidth(); }
    private float zb() { return (Settings.zy + Settings.zh) * getHeight(); }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setColor(dim ? 0xCC000000 : 0xFF3A3C48);
        c.drawRect(0, 0, w, h, p);

        // зона стрельбы
        boolean zoneOn = Settings.fireMode != Settings.FIRE_BTN_ONLY;
        int yel = zoneOn ? 0xFFF0C419 : 0x66F0C419;
        p.setColor(zoneOn ? 0x44F0C419 : 0x14F0C419);
        c.drawRect(zl(), zt(), zr(), zb(), p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth((sel == SEL_ZONE ? 3.5f : 2.5f) * d); p.setColor(yel);
        c.drawRect(zl(), zt(), zr(), zb(), p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(zoneOn ? 0xFFF0C419 : 0x88F0C419);
        float hs = 11 * d;
        c.drawRect(zr() - hs * 2, zb() - hs * 2, zr(), zb(), p);          // ручка изменения размера
        p.setColor(0xFF2A2C36); p.setStrokeWidth(2 * d);
        p.setStyle(Paint.Style.STROKE);
        c.drawLine(zr() - hs * 1.6f, zb() - hs * 0.4f, zr() - hs * 0.4f, zb() - hs * 1.6f, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(zoneOn ? 0xFFFFE27A : 0x88FFE27A); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(13 * d);
        c.drawText(zoneOn ? "ЗОНА СТРЕЛЬБЫ" : "ЗОНА СТРЕЛЬБЫ (выключена)", (zl() + zr()) / 2f, (zt() + zb()) / 2f, p);

        // область джойстика
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2 * d); p.setColor(0x33FFFFFF);
        c.drawRect(8 * d, h * 0.45f, w * 0.4f, h - 8 * d, p);
        p.setStyle(Paint.Style.FILL); p.setColor(0x66FFFFFF);
        c.drawText("зона джойстика (движение)", w * 0.2f, h * 0.75f, p);
        c.drawText("остальной экран - камера", w * 0.5f, h - 40 * d, p);
        p.setColor(0x55303440); c.drawCircle(96 * d, h - 96 * d, 56 * d, p);

        for (int i = 0; i < Settings.COUNT; i++) {
            float cx = Settings.cx(i, w, d), cy = Settings.cy(i, h, d);
            float fade = Settings.hidden(i) ? 0.35f : 1f;
            ControlsUi.drawButton(c, p, i, cx, cy, d, false, false, fade, sample);
            if (i == sel) {
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.5f * d); p.setColor(0xFFFFE27A);
                float hw = Settings.hw(i, d) + 4 * d, hh = Settings.hh(i, d) + 4 * d;
                if (Settings.isRect(i)) c.drawRoundRect(cx - hw, cy - hh, cx + hw, cy + hh, 9 * d, 9 * d, p);
                else c.drawCircle(cx, cy, hw, p);
                p.setStyle(Paint.Style.FILL);
            }
        }
        p.setColor(0xFFE8EDE4); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(14 * d);
        String info = sel >= 0 ? "Выбрано: " + Settings.LABEL[sel] + "   размер " + Math.round(Settings.sc[sel] * 100) + "%"
                : "Зона стрельбы: " + Math.round(Settings.zw * 100) + "% × " + Math.round(Settings.zh * 100) + "% экрана";
        c.drawText(info, w * 0.7f, h - 14 * d, p);
        p.setTextAlign(Paint.Align.LEFT);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int w = getWidth(), h = getHeight();
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                dragging = false; resizingZone = false;
                // ручка зоны - самая верхняя
                if (x >= zr() - 26 * d && x <= zr() + 14 * d && y >= zb() - 26 * d && y <= zb() + 14 * d) {
                    sel = SEL_ZONE; resizingZone = true; invalidate(); return true;
                }
                int best = -1;
                float bestRatio = 1.2f;
                for (int i = 0; i < Settings.COUNT; i++) {
                    float ratio = Settings.ratio(i, x, y, w, h, d);
                    if (ratio < bestRatio) { bestRatio = ratio; best = i; }
                }
                if (best >= 0) {
                    sel = best; dragging = true;
                    gx = x - Settings.cx(sel, w, d); gy = y - Settings.cy(sel, h, d);
                } else if (x >= zl() && x <= zr() && y >= zt() && y <= zb()) {
                    sel = SEL_ZONE; dragging = true;
                    gx = x - zl(); gy = y - zt();
                }
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                if (resizingZone) {
                    Settings.zw = Math.max(0.12f, Math.min(1f - Settings.zx, x / w - Settings.zx));
                    Settings.zh = Math.max(0.15f, Math.min(1f - Settings.zy, y / h - Settings.zy));
                    invalidate();
                } else if (dragging && sel == SEL_ZONE) {
                    Settings.zx = (x - gx) / w; Settings.zy = (y - gy) / h;
                    Settings.clampZone();
                    invalidate();
                } else if (dragging && sel >= 0) {
                    float hw = Settings.hw(sel, d), hh = Settings.hh(sel, d);
                    float cx = Math.max(hw, Math.min(w - hw, x - gx)), cy = Math.max(hh, Math.min(h - hh, y - gy));
                    Settings.ox[sel] = (w - cx) / d;
                    Settings.oy[sel] = (h - cy) / d;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false; resizingZone = false;
                return true;
        }
        return true;
    }
}
